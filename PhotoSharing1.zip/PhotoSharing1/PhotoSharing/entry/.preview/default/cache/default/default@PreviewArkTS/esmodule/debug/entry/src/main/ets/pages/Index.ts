if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    images?: ImageItem[];
    isLoading?: boolean;
    isRefreshing?: boolean;
}
import router from "@ohos:router";
import type { ImageItem } from '../models/Image';
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__images = new ObservedPropertyObjectPU([], this, "images");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.images !== undefined) {
            this.images = params.images;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__images.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__images.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __images: ObservedPropertyObjectPU<ImageItem[]>;
    get images() {
        return this.__images.get();
    }
    set images(newValue: ImageItem[]) {
        this.__images.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    aboutToAppear() {
        this.loadImages();
    }
    /**
     * 加载图片数据
     */
    async loadImages() {
        this.isLoading = true;
        try {
            const response = await ApiService.getRandomImages(8);
            if (response.code === 1) {
                this.images = response.data || [];
            }
        }
        catch (error) {
            console.error('加载图片失败:', error);
        }
        finally {
            this.isLoading = false;
        }
    }
    /**
     * 刷新图片
     */
    async refreshImages() {
        this.isRefreshing = true;
        await this.loadImages();
        this.isRefreshing = false;
    }
    /**
     * 跳转到登录页面
     */
    navigateToLogin() {
        router.pushUrl({ url: 'pages/LoginPage' });
    }
    /**
     * 跳转到上传页面
     */
    navigateToUpload() {
        router.pushUrl({ url: 'pages/UploadPage' });
    }
    /**
     * 跳转到个人中心
     */
    navigateToProfile() {
        router.pushUrl({ url: 'pages/ProfilePage' });
    }
    /**
     * 点赞/取消点赞
     */
    async toggleLike(image: ImageItem) {
        try {
            const response = await ApiService.toggleLike(image.imageId);
            if (response.code === 1) {
                // 更新本地状态
                const index = this.images.findIndex((img: ImageItem) => img.imageId === image.imageId);
                if (index !== -1) {
                    this.images[index].isLiked = !this.images[index].isLiked;
                    this.images[index].likeCount = (this.images[index].likeCount || 0) + (this.images[index].isLiked ? 1 : -1);
                }
            }
        }
        catch (error) {
            console.error('点赞失败:', error);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(87:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Index.ets(89:7)", "entry");
            // 顶部导航栏
            Row.width('100%');
            // 顶部导航栏
            Row.height(56);
            // 顶部导航栏
            Row.padding({ left: 16, right: 16 });
            // 顶部导航栏
            Row.backgroundColor(Color.Transparent);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('图片分享');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(90:9)", "entry");
            Text.fontSize(20);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/Index.ets(95:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 15 });
            Row.debugLine("entry/src/main/ets/pages/Index.ets(97:9)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📤');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(98:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(Color.Black);
            Text.onClick(() => this.navigateToUpload());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('👤');
            Text.debugLine("entry/src/main/ets/pages/Index.ets(103:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(Color.Black);
            Text.onClick(() => this.navigateToProfile());
        }, Text);
        Text.pop();
        Row.pop();
        // 顶部导航栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 图片网格
            if (this.isLoading && this.images.length === 0) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 加载中状态
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(117:9)", "entry");
                        // 加载中状态
                        Column.justifyContent(FlexAlign.Center);
                        // 加载中状态
                        Column.width('100%');
                        // 加载中状态
                        Column.height('100%');
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/Index.ets(118:11)", "entry");
                        LoadingProgress.width(50);
                        LoadingProgress.height(50);
                        LoadingProgress.color(Color.White);
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('加载中...');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(123:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Color.Black);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    // 加载中状态
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 图片列表
                        Refresh.create({ refreshing: this.isRefreshing });
                        Refresh.debugLine("entry/src/main/ets/pages/Index.ets(133:9)", "entry");
                        // 图片列表
                        Refresh.onRefreshing(() => {
                            this.refreshImages();
                        });
                    }, Refresh);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Grid.create();
                        Grid.debugLine("entry/src/main/ets/pages/Index.ets(134:11)", "entry");
                        Grid.columnsTemplate('1fr 1fr');
                        Grid.rowsGap(12);
                        Grid.columnsGap(12);
                        Grid.padding(16);
                        Grid.onScrollIndex(() => {
                            // 可以在这里实现分页加载
                        });
                    }, Grid);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const image = _item;
                            {
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    GridItem.create(() => { }, false);
                                    GridItem.debugLine("entry/src/main/ets/pages/Index.ets(136:15)", "entry");
                                };
                                const observedDeepRender = () => {
                                    this.observeComponentCreation2(itemCreation2, GridItem);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/Index.ets(137:17)", "entry");
                                        Column.width('100%');
                                        Column.backgroundColor(Colors.White10);
                                        Column.borderRadius(12);
                                        Column.padding(8);
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 图片
                                        Image.create(image.imageUrl);
                                        Image.debugLine("entry/src/main/ets/pages/Index.ets(139:19)", "entry");
                                        // 图片
                                        Image.width('100%');
                                        // 图片
                                        Image.height(200);
                                        // 图片
                                        Image.borderRadius(12);
                                        // 图片
                                        Image.objectFit(ImageFit.Cover);
                                        // 图片
                                        Image.onClick(() => {
                                            // 点击图片可以查看大图
                                        });
                                    }, Image);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 图片信息
                                        Column.create({ space: 8 });
                                        Column.debugLine("entry/src/main/ets/pages/Index.ets(149:19)", "entry");
                                        // 图片信息
                                        Column.width('100%');
                                        // 图片信息
                                        Column.padding({ top: 8, left: 8, right: 8, bottom: 8 });
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(image.imageName);
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(150:21)", "entry");
                                        Text.fontSize(14);
                                        Text.fontWeight(FontWeight.Medium);
                                        Text.fontColor(Color.Black);
                                        Text.maxLines(1);
                                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/Index.ets(157:21)", "entry");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(image.username || '匿名用户');
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(158:23)", "entry");
                                        Text.fontSize(12);
                                        Text.fontColor(Colors.Black60);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/Index.ets(162:23)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create({ space: 4 });
                                        Row.debugLine("entry/src/main/ets/pages/Index.ets(164:23)", "entry");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(this.images[index].isLiked ? '❤️' : '🤍');
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(165:25)", "entry");
                                        Text.fontSize(16);
                                        Text.onClick(() => this.toggleLike(image));
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create((image.likeCount || 0).toString());
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(169:25)", "entry");
                                        Text.fontSize(12);
                                        Text.fontColor(Colors.Black60);
                                    }, Text);
                                    Text.pop();
                                    Row.pop();
                                    Row.pop();
                                    // 图片信息
                                    Column.pop();
                                    Column.pop();
                                    GridItem.pop();
                                };
                                observedDeepRender();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.images, forEachItemGenFunction, undefined, true, false);
                    }, ForEach);
                    ForEach.pop();
                    Grid.pop();
                    // 图片列表
                    Refresh.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
