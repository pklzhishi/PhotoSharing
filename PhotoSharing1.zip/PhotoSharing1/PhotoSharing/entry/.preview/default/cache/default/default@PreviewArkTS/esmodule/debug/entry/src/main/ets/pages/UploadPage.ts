if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface UploadPage_Params {
    selectedImagePath?: string;
    imageName?: string;
    isUploading?: boolean;
    previewImage?: image.PixelMap | null;
}
import router from "@ohos:router";
import picker from "@ohos:file.picker";
import promptAction from "@ohos:promptAction";
import fs from "@ohos:file.fs";
import image from "@ohos:multimedia.image";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
class UploadPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__selectedImagePath = new ObservedPropertySimplePU('', this, "selectedImagePath");
        this.__imageName = new ObservedPropertySimplePU('', this, "imageName");
        this.__isUploading = new ObservedPropertySimplePU(false, this, "isUploading");
        this.__previewImage = new ObservedPropertyObjectPU(null, this, "previewImage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: UploadPage_Params) {
        if (params.selectedImagePath !== undefined) {
            this.selectedImagePath = params.selectedImagePath;
        }
        if (params.imageName !== undefined) {
            this.imageName = params.imageName;
        }
        if (params.isUploading !== undefined) {
            this.isUploading = params.isUploading;
        }
        if (params.previewImage !== undefined) {
            this.previewImage = params.previewImage;
        }
    }
    updateStateVars(params: UploadPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedImagePath.purgeDependencyOnElmtId(rmElmtId);
        this.__imageName.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploading.purgeDependencyOnElmtId(rmElmtId);
        this.__previewImage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectedImagePath.aboutToBeDeleted();
        this.__imageName.aboutToBeDeleted();
        this.__isUploading.aboutToBeDeleted();
        this.__previewImage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __selectedImagePath: ObservedPropertySimplePU<string>;
    get selectedImagePath() {
        return this.__selectedImagePath.get();
    }
    set selectedImagePath(newValue: string) {
        this.__selectedImagePath.set(newValue);
    }
    private __imageName: ObservedPropertySimplePU<string>;
    get imageName() {
        return this.__imageName.get();
    }
    set imageName(newValue: string) {
        this.__imageName.set(newValue);
    }
    private __isUploading: ObservedPropertySimplePU<boolean>;
    get isUploading() {
        return this.__isUploading.get();
    }
    set isUploading(newValue: boolean) {
        this.__isUploading.set(newValue);
    }
    private __previewImage: ObservedPropertyObjectPU<image.PixelMap | null>;
    get previewImage() {
        return this.__previewImage.get();
    }
    set previewImage(newValue: image.PixelMap | null) {
        this.__previewImage.set(newValue);
    }
    /**
     * 选择图片
     */
    async selectImage() {
        try {
            const photoSelectOptions = new picker.PhotoSelectOptions();
            photoSelectOptions.MIMEType = picker.PhotoViewMIMETypes.IMAGE_TYPE;
            photoSelectOptions.maxSelectNumber = 1;
            const photoPicker = new picker.PhotoViewPicker();
            const photoSelectResult = await photoPicker.select(photoSelectOptions);
            if (photoSelectResult.photoUris && photoSelectResult.photoUris.length > 0) {
                this.selectedImagePath = photoSelectResult.photoUris[0];
                this.loadPreviewImage();
                // 如果没有设置图片名称，使用默认名称
                if (!this.imageName) {
                    const timestamp = new Date().getTime();
                    this.imageName = `图片_${timestamp}`;
                }
            }
        }
        catch (error) { // 去掉类型标注
            console.error('选择图片失败:', error);
            promptAction.showToast({ message: '选择图片失败' });
        }
    }
    /**
     * 加载预览图片
     */
    async loadPreviewImage() {
        if (!this.selectedImagePath)
            return;
        try {
            const file = fs.openSync(this.selectedImagePath, fs.OpenMode.READ_ONLY);
            const imageSource = image.createImageSource(file.fd);
            this.previewImage = await imageSource.createPixelMap();
            fs.closeSync(file);
        }
        catch (error) { // 去掉类型标注
            console.error('加载预览图片失败:', error);
        }
    }
    /**
     * 上传图片
     */
    async uploadImage() {
        if (!this.selectedImagePath) {
            promptAction.showToast({ message: '请先选择图片' });
            return;
        }
        if (!this.imageName.trim()) {
            promptAction.showToast({ message: '请输入图片名称' });
            return;
        }
        this.isUploading = true;
        try {
            // 检查文件大小（限制为 10MB）
            const file = fs.openSync(this.selectedImagePath, fs.OpenMode.READ_ONLY);
            const stat = fs.statSync(file.fd);
            const maxSize = 10 * 1024 * 1024; // 10MB
            if (stat.size > maxSize) {
                fs.closeSync(file);
                promptAction.showToast({ message: '图片文件过大，请选择小于10MB的图片' });
                return;
            }
            fs.closeSync(file);
            console.log('开始上传图片，文件名:', this.imageName.trim());
            console.log('文件路径:', this.selectedImagePath);
            // 使用新的multipart/form-data上传方式
            const response = await ApiService.uploadImageFile(this.imageName.trim(), this.selectedImagePath);
            console.log('上传响应:', response);
            if (response.code === 1) {
                promptAction.showToast({ message: '上传成功' });
                // 清空表单
                this.selectedImagePath = '';
                this.imageName = '';
                this.previewImage = null;
                // 返回主页
                router.back();
            }
            else {
                console.error('上传失败，响应码:', response.code, '错误信息:', response.msg);
                promptAction.showToast({ message: response.msg || '上传失败' });
            }
        }
        catch (error) {
            console.error('上传异常:', error);
            if (error instanceof Error) {
                promptAction.showToast({ message: `上传失败: ${error.message}` });
            }
            else {
                promptAction.showToast({ message: '上传失败，请检查网络连接' });
            }
        }
        finally {
            this.isUploading = false;
        }
    }
    /**
     * 返回
     */
    goBack() {
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(133:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/UploadPage.ets(135:7)", "entry");
            // 顶部导航栏
            Row.width('100%');
            // 顶部导航栏
            Row.height(56);
            // 顶部导航栏
            Row.padding({ left: 16, right: 16 });
            // 顶部导航栏
            Row.backgroundColor(Color.Transparent);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('←');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(136:9)", "entry");
            Text.fontSize(24);
            Text.fontColor(Color.Black);
            Text.onClick(() => this.goBack());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('上传图片');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(141:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
            Text.margin({ left: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/UploadPage.ets(147:9)", "entry");
        }, Blank);
        Blank.pop();
        // 顶部导航栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 上传表单
            Column.create({ space: 24 });
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(155:7)", "entry");
            // 上传表单
            Column.width('100%');
            // 上传表单
            Column.padding({ left: 24, right: 24, top: 24 });
            // 上传表单
            Column.layoutWeight(1);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片选择区域
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(157:9)", "entry");
            // 图片选择区域
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('选择图片');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(158:11)", "entry");
            Text.fontSize(16);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.previewImage) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 显示预览图片
                        Image.create(this.previewImage);
                        Image.debugLine("entry/src/main/ets/pages/UploadPage.ets(166:13)", "entry");
                        // 显示预览图片
                        Image.width('100%');
                        // 显示预览图片
                        Image.height(200);
                        // 显示预览图片
                        Image.borderRadius(12);
                        // 显示预览图片
                        Image.objectFit(ImageFit.Cover);
                        // 显示预览图片
                        Image.backgroundColor(Colors.White20);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 图片选择按钮
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(174:13)", "entry");
                        // 图片选择按钮
                        Column.width('100%');
                        // 图片选择按钮
                        Column.height(200);
                        // 图片选择按钮
                        Column.borderRadius(12);
                        // 图片选择按钮
                        Column.backgroundColor(Colors.White10);
                        // 图片选择按钮
                        Column.border({
                            width: 2,
                            color: Colors.White20,
                            style: BorderStyle.Dashed
                        });
                        // 图片选择按钮
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📷');
                        Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(175:15)", "entry");
                        Text.fontSize(48);
                        Text.opacity(0.6);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('点击选择图片');
                        Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(179:15)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Colors.Black60);
                        Text.margin({ top: 8 });
                    }, Text);
                    Text.pop();
                    // 图片选择按钮
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.previewImage ? '重新选择' : '选择图片');
            Button.debugLine("entry/src/main/ets/pages/UploadPage.ets(196:11)", "entry");
            Button.width('100%');
            Button.height(40);
            Button.backgroundColor(Colors.White20);
            Button.borderRadius(8);
            Button.fontSize(14);
            Button.fontColor(Color.Black);
            Button.onClick(() => this.selectImage());
        }, Button);
        Button.pop();
        // 图片选择区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片名称输入
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(208:9)", "entry");
            // 图片名称输入
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('图片名称');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(209:11)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入图片名称' });
            TextInput.debugLine("entry/src/main/ets/pages/UploadPage.ets(215:11)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.onChange((value: string) => {
                this.imageName = value;
            });
        }, TextInput);
        // 图片名称输入
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 上传按钮
            Button.createWithLabel(this.isUploading ? '上传中...' : '上传图片');
            Button.debugLine("entry/src/main/ets/pages/UploadPage.ets(230:9)", "entry");
            // 上传按钮
            Button.width('100%');
            // 上传按钮
            Button.height(48);
            // 上传按钮
            Button.backgroundColor('#4CAF50');
            // 上传按钮
            Button.borderRadius(8);
            // 上传按钮
            Button.fontSize(16);
            // 上传按钮
            Button.fontWeight(FontWeight.Medium);
            // 上传按钮
            Button.fontColor(Color.White);
            // 上传按钮
            Button.enabled(!this.isUploading && this.selectedImagePath !== '');
            // 上传按钮
            Button.onClick(() => this.uploadImage());
            // 上传按钮
            Button.margin({ top: 20 });
        }, Button);
        // 上传按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 提示信息
            Text.create('支持 JPG、PNG 格式，建议大小不超过 10MB');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(243:9)", "entry");
            // 提示信息
            Text.fontSize(12);
            // 提示信息
            Text.fontColor(Colors.Black60);
            // 提示信息
            Text.textAlign(TextAlign.Center);
            // 提示信息
            Text.margin({ top: 16 });
        }, Text);
        // 提示信息
        Text.pop();
        // 上传表单
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "UploadPage";
    }
}
registerNamedRoute(() => new UploadPage(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/UploadPage", pageFullPath: "entry/src/main/ets/pages/UploadPage", integratedHsp: "false", moduleType: "followWithHap" });
