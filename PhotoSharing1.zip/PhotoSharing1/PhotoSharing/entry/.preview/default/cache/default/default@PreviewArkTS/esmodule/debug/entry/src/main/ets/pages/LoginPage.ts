if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    userAccount?: string;
    password?: string;
    isLoading?: boolean;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import type { LoginRequest } from '../models/User';
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
import { HttpService } from "@normalized:N&&&entry/src/main/ets/services/HttpService&";
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__userAccount = new ObservedPropertySimplePU('', this, "userAccount");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.userAccount !== undefined) {
            this.userAccount = params.userAccount;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
    }
    updateStateVars(params: LoginPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__userAccount.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__userAccount.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __userAccount: ObservedPropertySimplePU<string>;
    get userAccount() {
        return this.__userAccount.get();
    }
    set userAccount(newValue: string) {
        this.__userAccount.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    /** 登录处理 */
    async login() {
        if (!this.userAccount.trim()) {
            promptAction.showToast({ message: '请输入账号' });
            return;
        }
        if (!this.password.trim()) {
            promptAction.showToast({ message: '请输入密码' });
            return;
        }
        this.isLoading = true;
        try {
            const request: LoginRequest = {
                userAccount: this.userAccount.trim(),
                password: this.password.trim()
            };
            const response = await ApiService.login(request);
            if (response.code === 1 && response.data && response.data.token) {
                promptAction.showToast({ message: '登录成功' });
                // 保存用户信息和token
                HttpService.saveToken(response.data.token);
                // 返回主页
                router.back();
            }
            else {
                promptAction.showToast({ message: response.msg || '登录失败' });
            }
        }
        catch (error) {
            console.error('登录失败:', error);
            promptAction.showToast({ message: '登录失败，请检查网络连接' });
        }
        finally {
            this.isLoading = false;
        }
    }
    /** 跳转到注册页面 */
    navigateToRegister() {
        router.pushUrl({ url: 'pages/RegisterPage' });
    }
    // navigateToIndex() {
    //   router.pushUrl( {url: 'pages/Index'} )
    // }
    /** 返回上一页 */
    goBack() {
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(70:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(72:7)", "entry");
            // 顶部导航栏
            Row.width('100%');
            // 顶部导航栏
            Row.height(56);
            // 顶部导航栏
            Row.padding({ left: 16, right: 16 });
            // 顶部导航栏
            Row.backgroundColor(Color.Transparent);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('←');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(73:9)", "entry");
            Text.fontSize(24);
            Text.fontColor(Color.Black);
            Text.onClick(() => this.goBack());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('登录');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(78:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
            Text.margin({ left: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/LoginPage.ets(84:9)", "entry");
        }, Blank);
        Blank.pop();
        // 顶部导航栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 登录表单
            Column.create({ space: 24 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(92:7)", "entry");
            // 登录表单
            Column.width('100%');
            // 登录表单
            Column.padding({ left: 32, right: 32 });
            // 登录表单
            Column.layoutWeight(1);
            // 登录表单
            Column.justifyContent(FlexAlign.Center);
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // Logo区域
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(94:9)", "entry");
            // Logo区域
            Column.margin({ top: 60, bottom: 40 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('📱');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(95:11)", "entry");
            Text.fontSize(80);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('图片分享');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(98:11)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('分享美好瞬间，记录精彩生活');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(103:11)", "entry");
            Text.fontSize(14);
            Text.fontColor(Colors.Black60);
        }, Text);
        Text.pop();
        // Logo区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 输入表单
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(110:9)", "entry");
            // 输入表单
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 账号输入框
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(112:11)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('账号');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(113:13)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入账号' });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(119:13)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.onChange((value: string) => {
                this.userAccount = value;
            });
        }, TextInput);
        // 账号输入框
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 密码输入框
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(133:11)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('密码');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(134:13)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入密码' });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(140:13)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.type(InputType.Password);
            TextInput.onChange((value: string) => {
                this.password = value;
            });
        }, TextInput);
        // 密码输入框
        Column.pop();
        // 输入表单
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 登录按钮
            Button.createWithLabel(this.isLoading ? '登录中...' : '登录');
            Button.debugLine("entry/src/main/ets/pages/LoginPage.ets(157:9)", "entry");
            // 登录按钮
            Button.width('100%');
            // 登录按钮
            Button.height(48);
            // 登录按钮
            Button.backgroundColor('#4CAF50');
            // 登录按钮
            Button.borderRadius(8);
            // 登录按钮
            Button.fontSize(16);
            // 登录按钮
            Button.fontWeight(FontWeight.Medium);
            // 登录按钮
            Button.fontColor(Color.Black);
            // 登录按钮
            Button.enabled(!this.isLoading);
            // 登录按钮
            Button.onClick(() => this.login());
        }, Button);
        // 登录按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 注册链接
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(169:9)", "entry");
            // 注册链接
            Row.margin({ top: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('还没有账号？');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(170:11)", "entry");
            Text.fontSize(14);
            Text.fontColor(Colors.Black60);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('立即注册');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(174:11)", "entry");
            Text.fontSize(14);
            Text.fontColor('#4CAF50');
            Text.fontWeight(FontWeight.Medium);
            Text.onClick(() => this.navigateToRegister());
        }, Text);
        Text.pop();
        // 注册链接
        Row.pop();
        // 登录表单
        Column.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LoginPage";
    }
}
registerNamedRoute(() => new LoginPage(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/LoginPage", pageFullPath: "entry/src/main/ets/pages/LoginPage", integratedHsp: "false", moduleType: "followWithHap" });
