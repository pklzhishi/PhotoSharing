if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProfilePage_Params {
    myImages?: ImageItem[];
    imageCount?: number;
    isLoading?: boolean;
    currentPage?: number;
    hasMore?: boolean;
    isLoggedIn?: boolean;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import type { ImageItem, PageRequest, PageResponse } from '../models/Image';
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
class ProfilePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__myImages = new ObservedPropertyObjectPU([], this, "myImages");
        this.__imageCount = new ObservedPropertySimplePU(0, this, "imageCount");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__currentPage = new ObservedPropertySimplePU(1, this, "currentPage");
        this.__hasMore = new ObservedPropertySimplePU(true, this, "hasMore");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProfilePage_Params) {
        if (params.myImages !== undefined) {
            this.myImages = params.myImages;
        }
        if (params.imageCount !== undefined) {
            this.imageCount = params.imageCount;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.hasMore !== undefined) {
            this.hasMore = params.hasMore;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
    }
    updateStateVars(params: ProfilePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__myImages.purgeDependencyOnElmtId(rmElmtId);
        this.__imageCount.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__hasMore.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__myImages.aboutToBeDeleted();
        this.__imageCount.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__hasMore.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __myImages: ObservedPropertyObjectPU<ImageItem[]>;
    get myImages() {
        return this.__myImages.get();
    }
    set myImages(newValue: ImageItem[]) {
        this.__myImages.set(newValue);
    }
    private __imageCount: ObservedPropertySimplePU<number>;
    get imageCount() {
        return this.__imageCount.get();
    }
    set imageCount(newValue: number) {
        this.__imageCount.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<number>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: number) {
        this.__currentPage.set(newValue);
    }
    private __hasMore: ObservedPropertySimplePU<boolean>;
    get hasMore() {
        return this.__hasMore.get();
    }
    set hasMore(newValue: boolean) {
        this.__hasMore.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    aboutToAppear() {
        this.loadUserInfo();
        this.loadMyImages(true);
    }
    /**
     * 加载用户信息
     */
    async loadUserInfo() {
        try {
            const response = await ApiService.getMyImageCount();
            if (response.code === 1) {
                this.imageCount = response.data || 0;
                this.isLoggedIn = true;
            }
        }
        catch (error) {
            console.error('加载用户信息失败:', error);
            this.isLoggedIn = false;
        }
    }
    /**
     * 加载我的图片
     */
    async loadMyImages(refresh: boolean = false) {
        if (refresh) {
            this.currentPage = 1;
            this.myImages = [];
            this.hasMore = true;
        }
        this.isLoading = true;
        try {
            const request: PageRequest = {
                page: this.currentPage,
                size: 8
            };
            const response = await ApiService.getMyImages(request);
            if (response.code === 1) {
                const pageData = response.data as PageResponse<ImageItem>;
                if (refresh) {
                    this.myImages = pageData.records || [];
                }
                else {
                    this.myImages = [...this.myImages, ...(pageData.records || [])];
                }
                this.hasMore = this.currentPage < pageData.pages;
            }
        }
        catch (error) {
            console.error('加载我的图片失败:', error);
        }
        finally {
            this.isLoading = false;
        }
    }
    /**
     * 加载更多
     */
    loadMore() {
        if (this.hasMore && !this.isLoading) {
            this.currentPage++;
            this.loadMyImages();
        }
    }
    /**
     * 跳转到登录页�?
     */
    navigateToLogin() {
        router.pushUrl({ url: 'pages/LoginPage' });
    }
    /**
     * 跳转到上传页�?
     */
    navigateToUpload() {
        router.pushUrl({ url: 'pages/UploadPage' });
    }
    /**
     * 返回
     */
    goBack() {
        router.back();
    }
    /**
     * 退出登�?
     */
    logout() {
        promptAction.showDialog({
            title: '确认退出',
            message: '确定要退出登录吗?',
            buttons: [
                { text: '取消', color: '#999999' },
                { text: '确定', color: '#FF4444' }
            ]
        }).then((result) => {
            if (result.index === 1) {
                // 清除本地存储的用户信�?
                // HttpService.clearToken();
                this.isLoggedIn = false;
                this.myImages = [];
                this.imageCount = 0;
                promptAction.showToast({ message: '已退出登录' });
            }
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(130:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航�?
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(132:7)", "entry");
            // 顶部导航�?
            Row.width('100%');
            // 顶部导航�?
            Row.height(56);
            // 顶部导航�?
            Row.padding({ left: 16, right: 16 });
            // 顶部导航�?
            Row.backgroundColor(Color.Transparent);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('←');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(133:9)", "entry");
            Text.fontSize(24);
            Text.fontColor(Color.Black);
            Text.onClick(() => this.goBack());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('个人中心');
            Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(138:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
            Text.margin({ left: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ProfilePage.ets(144:9)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('退出');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(147:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor('#FF4444');
                        Text.onClick(() => this.logout());
                    }, Text);
                    Text.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        // 顶部导航�?
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 未登录状�?
                        Column.create({ space: 24 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(160:9)", "entry");
                        // 未登录状�?
                        Column.justifyContent(FlexAlign.Center);
                        // 未登录状�?
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户头像
                        Text.create('👤');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(162:13)", "entry");
                        // 用户头像
                        Text.fontSize(80);
                        // 用户头像
                        Text.margin({ top: 60 });
                    }, Text);
                    // 用户头像
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('未登录');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(166:11)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Color.Black);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('登录后查看你的作品和收藏');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(171:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('立即登录');
                        Button.debugLine("entry/src/main/ets/pages/ProfilePage.ets(175:11)", "entry");
                        Button.width(200);
                        Button.height(40);
                        Button.backgroundColor('#4CAF50');
                        Button.borderRadius(20);
                        Button.fontSize(16);
                        Button.fontColor(Color.Black);
                        Button.onClick(() => this.navigateToLogin());
                        Button.margin({ top: 24 });
                    }, Button);
                    Button.pop();
                    // 未登录状�?
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 已登录状态
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(189:9)", "entry");
                        // 已登录状态
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户信息区域
                        Column.create({ space: 16 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(191:11)", "entry");
                        // 用户信息区域
                        Column.width('100%');
                        // 用户信息区域
                        Column.padding({ left: 16, right: 16, top: 16 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户头像和基本信息
                        Row.create({ space: 16 });
                        Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(193:13)", "entry");
                        // 用户头像和基本信息
                        Row.width('100%');
                        // 用户头像和基本信息
                        Row.padding(16);
                        // 用户头像和基本信息
                        Row.backgroundColor(Colors.White10);
                        // 用户头像和基本信息
                        Row.borderRadius(12);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('👤');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(194:15)", "entry");
                        Text.fontSize(60);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 4 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(197:15)", "entry");
                        Column.alignItems(HorizontalAlign.Start);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('我的作品');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(198:17)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Color.Black);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.imageCount} 张图片`);
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(203:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ProfilePage.ets(209:15)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('上传');
                        Button.debugLine("entry/src/main/ets/pages/ProfilePage.ets(211:15)", "entry");
                        Button.width(60);
                        Button.height(32);
                        Button.backgroundColor('#4CAF50');
                        Button.borderRadius(16);
                        Button.fontSize(12);
                        Button.fontColor(Color.Black);
                        Button.onClick(() => this.navigateToUpload());
                    }, Button);
                    Button.pop();
                    // 用户头像和基本信息
                    Row.pop();
                    // 用户信息区域
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 我的作品列表
                        if (this.myImages.length === 0 && !this.isLoading) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 空状�?
                                    Column.create({ space: 16 });
                                    Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(231:13)", "entry");
                                    // 空状�?
                                    Column.justifyContent(FlexAlign.Center);
                                    // 空状�?
                                    Column.layoutWeight(1);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('📭');
                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(232:15)", "entry");
                                    Text.fontSize(80);
                                    Text.opacity(0.6);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('还没有作品');
                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(236:17)", "entry");
                                    Text.fontSize(16);
                                    Text.fontColor(Colors.Black60);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('快去上传你的第一张图片吧');
                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(240:17)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Colors.Black40);
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('上传图片');
                                    Button.debugLine("entry/src/main/ets/pages/ProfilePage.ets(244:15)", "entry");
                                    Button.width(120);
                                    Button.height(36);
                                    Button.backgroundColor('#4CAF50');
                                    Button.borderRadius(18);
                                    Button.fontSize(14);
                                    Button.fontColor(Color.Black);
                                    Button.onClick(() => this.navigateToUpload());
                                }, Button);
                                Button.pop();
                                // 空状�?
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 图片网格
                                    Grid.create();
                                    Grid.debugLine("entry/src/main/ets/pages/ProfilePage.ets(257:13)", "entry");
                                    // 图片网格
                                    Grid.columnsTemplate('1fr 1fr');
                                    // 图片网格
                                    Grid.rowsGap(12);
                                    // 图片网格
                                    Grid.columnsGap(12);
                                    // 图片网格
                                    Grid.padding(16);
                                    // 图片网格
                                    Grid.layoutWeight(1);
                                    // 图片网格
                                    Grid.onScrollIndex(() => {
                                        this.loadMore();
                                    });
                                }, Grid);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = _item => {
                                        const image = _item;
                                        {
                                            const itemCreation2 = (elmtId, isInitialRender) => {
                                                GridItem.create(() => { }, false);
                                                GridItem.debugLine("entry/src/main/ets/pages/ProfilePage.ets(259:17)", "entry");
                                            };
                                            const observedDeepRender = () => {
                                                this.observeComponentCreation2(itemCreation2, GridItem);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Column.create();
                                                    Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(260:19)", "entry");
                                                    Column.width('100%');
                                                    Column.backgroundColor(Colors.White10);
                                                    Column.borderRadius(8);
                                                    Column.padding(8);
                                                }, Column);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Image.create(image.imageUrl);
                                                    Image.debugLine("entry/src/main/ets/pages/ProfilePage.ets(261:21)", "entry");
                                                    Image.width('100%');
                                                    Image.height(120);
                                                    Image.borderRadius(8);
                                                    Image.objectFit(ImageFit.Cover);
                                                }, Image);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create(image.imageName);
                                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(267:21)", "entry");
                                                    Text.fontSize(12);
                                                    Text.fontColor(Color.White);
                                                    Text.maxLines(1);
                                                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                                    Text.margin({ top: 4 });
                                                }, Text);
                                                Text.pop();
                                                Column.pop();
                                                GridItem.pop();
                                            };
                                            observedDeepRender();
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.myImages, forEachItemGenFunction);
                                }, ForEach);
                                ForEach.pop();
                                // 图片网格
                                Grid.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    // 加载更多指示�?
                                    if (this.isLoading) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Row.create();
                                                Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(292:15)", "entry");
                                                Row.justifyContent(FlexAlign.Center);
                                                Row.width('100%');
                                                Row.height(40);
                                            }, Row);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                LoadingProgress.create();
                                                LoadingProgress.debugLine("entry/src/main/ets/pages/ProfilePage.ets(293:17)", "entry");
                                                LoadingProgress.width(20);
                                                LoadingProgress.height(20);
                                                LoadingProgress.color(Color.White);
                                            }, LoadingProgress);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('加载中...');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(298:17)", "entry");
                                                Text.fontSize(12);
                                                Text.fontColor(Colors.Black60);
                                                Text.margin({ left: 8 });
                                            }, Text);
                                            Text.pop();
                                            Row.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    // 已登录状态
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ProfilePage";
    }
}
registerNamedRoute(() => new ProfilePage(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/ProfilePage", pageFullPath: "entry/src/main/ets/pages/ProfilePage", integratedHsp: "false", moduleType: "followWithHap" });
