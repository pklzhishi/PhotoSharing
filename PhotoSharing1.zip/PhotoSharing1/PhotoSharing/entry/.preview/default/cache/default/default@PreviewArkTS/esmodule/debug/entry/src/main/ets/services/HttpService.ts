import http from "@ohos:net.http";
import fs from "@ohos:file.fs";
import preferences from "@ohos:data.preferences";
import type { ApiResponse } from '../models/User';
import type common from "@ohos:app.ability.common";
/** HTTP请求选项接口 */
interface HttpRequestOptions {
    method: http.RequestMethod;
    header: Record<string, string>;
    extraData?: string;
    connectTimeout?: number;
    readTimeout?: number;
}
/** HTTP请求服务 */
export class HttpService {
    private static readonly BASE_URL = 'http://115.29.241.234:8000';
    private static readonly TIMEOUT = 5000; // 减少超时时间到5秒
    private static tokenValue: string | null = null;
    private static preferencesStore: preferences.Preferences | null = null;
    private static context: common.Context | null = null;
    /** 设置应用上下文 */
    static setContext(context: common.Context): void {
        HttpService.context = context;
    }
    /** 发送GET请求 */
    static async get<T>(url: string, headers?: Record<string, string>): Promise<ApiResponse<T>> {
        return HttpService.request<T>('GET', url, null, headers);
    }
    /** 发送POST请求 */
    static async post<T, B extends object | null>(url: string, data?: B, headers?: Record<string, string>): Promise<ApiResponse<T>> {
        return HttpService.request<T>('POST', url, data, headers);
    }
    /** 发送PUT请求 */
    static async put<T, B extends object>(url: string, data?: B, headers?: Record<string, string>): Promise<ApiResponse<T>> {
        return HttpService.request<T>('PUT', url, data, headers);
    }
    /** 发送DELETE请求 */
    static async delete<T>(url: string, headers?: Record<string, string>): Promise<ApiResponse<T>> {
        return HttpService.request<T>('DELETE', url, null, headers);
    }
    /** 通用请求方法 */
    private static async request<T>(method: string, url: string, data?: object | null, headers?: Record<string, string>): Promise<ApiResponse<T>> {
        return new Promise(async (resolve, reject) => {
            const httpRequest = http.createHttp();
            const requestUrl = url.startsWith('http') ? url : `${HttpService.BASE_URL}${url}`;
            const requestHeaders: Record<string, string> = {
                'Content-Type': 'application/json'
            };
            if (headers) {
                Object.keys(headers).forEach(key => {
                    requestHeaders[key] = headers[key];
                });
            }
            const token = await HttpService.getToken();
            console.log('当前token:', token);
            if (token) {
                requestHeaders['token'] = token;
                console.log('已添加token到请求头');
            }
            else {
                console.log('没有token，请求将不包含认证信息');
            }
            const options: HttpRequestOptions = {
                method: method as http.RequestMethod,
                header: requestHeaders,
                extraData: data ? JSON.stringify(data) : '',
                connectTimeout: HttpService.TIMEOUT,
                readTimeout: HttpService.TIMEOUT
            };
            // 添加超时保护
            const timeoutId = setTimeout(() => {
                console.error('请求超时，强制取消');
                httpRequest.destroy();
                reject(new Error('请求超时'));
            }, HttpService.TIMEOUT + 1000); // 比实际超时时间多1秒
            httpRequest.request(requestUrl, options).then((response: http.HttpResponse) => {
                clearTimeout(timeoutId);
                console.log(`HTTP请求响应: ${response.responseCode}, URL: ${requestUrl}`);
                if (response.responseCode === 200) {
                    try {
                        const result = JSON.parse(response.result as string) as ApiResponse<T>;
                        console.log('请求成功:', result);
                        resolve(result);
                    }
                    catch (error) {
                        console.error('JSON解析失败:', response.result);
                        reject(new Error('JSON解析失败'));
                    }
                }
                else {
                    console.error(`HTTP错误: ${response.responseCode}, 响应: ${response.result}`);
                    reject(new Error(`HTTP错误: ${response.responseCode}`));
                }
            }).catch((error: Error) => {
                clearTimeout(timeoutId);
                console.error('网络请求失败:', error.message);
                reject(error);
            }).finally(() => {
                clearTimeout(timeoutId);
                httpRequest.destroy();
            });
        });
    }
    /** 文件上传方法 */
    static async uploadFile<T>(url: string, filePath: string, fileName: string, headers?: Record<string, string>): Promise<ApiResponse<T>> {
        return new Promise(async (resolve, reject) => {
            const httpRequest = http.createHttp();
            try {
                console.log('文件路径:', filePath);
                console.log('文件名:', fileName);
                // 检查文件是否存在
                const file = fs.openSync(filePath, fs.OpenMode.READ_ONLY);
                const stat = fs.statSync(file.fd);
                console.log('文件大小:', stat.size, '字节');
                fs.closeSync(file);
                // 构建multipart/form-data请求体
                const boundary = '----WebKitFormBoundary' + Math.random().toString(16).substring(2);
                const formDataBody = HttpService.buildFileMultipartFormData(boundary, filePath, fileName);
                const requestUrl = url.startsWith('http') ? url : `${HttpService.BASE_URL}${url}`;
                const requestHeaders: Record<string, string> = {
                    'Content-Type': `multipart/form-data; boundary=${boundary}`
                };
                if (headers) {
                    Object.keys(headers).forEach(key => {
                        requestHeaders[key] = headers[key];
                    });
                }
                const token = await HttpService.getToken();
                if (token) {
                    requestHeaders['token'] = token;
                }
                // 添加Cookie头部
                requestHeaders['Cookie'] = '62C3252E1BA3A06A895FF08A44B31DD6';
                console.log('请求头:', requestHeaders);
                console.log('请求URL:', requestUrl);
                const options: HttpRequestOptions = {
                    method: http.RequestMethod.POST,
                    header: requestHeaders,
                    extraData: formDataBody,
                    connectTimeout: HttpService.TIMEOUT,
                    readTimeout: HttpService.TIMEOUT
                };
                httpRequest.request(requestUrl, options).then((response: http.HttpResponse) => {
                    console.log(`文件上传响应: ${response.responseCode}, URL: ${requestUrl}`);
                    if (response.responseCode === 200) {
                        try {
                            const result = JSON.parse(response.result as string) as ApiResponse<T>;
                            console.log('文件上传成功:', result);
                            resolve(result);
                        }
                        catch (error) {
                            console.error('文件上传JSON解析失败:', response.result);
                            reject(new Error('JSON解析失败'));
                        }
                    }
                    else {
                        console.error(`文件上传HTTP错误: ${response.responseCode}, 响应: ${response.result}`);
                        reject(new Error(`HTTP错误: ${response.responseCode}`));
                    }
                }).catch((error: Error) => {
                    console.error('文件上传网络请求失败:', error.message);
                    reject(error);
                }).finally(() => {
                    httpRequest.destroy();
                });
            }
            catch (error) {
                console.error('文件处理失败:', error);
                reject(new Error('文件处理失败'));
            }
        });
    }
    /** 构建文件multipart/form-data请求体 */
    private static buildFileMultipartFormData(boundary: string, filePath: string, fileName: string): string {
        try {
            // 读取文件内容
            const file = fs.openSync(filePath, fs.OpenMode.READ_ONLY);
            const stat = fs.statSync(file.fd);
            const buffer = new ArrayBuffer(stat.size);
            fs.readSync(file.fd, buffer);
            fs.closeSync(file);
            // 将文件内容转换为base64
            const uint8Array = new Uint8Array(buffer);
            const base64 = HttpService.arrayBufferToBase64(uint8Array);
            // 获取文件扩展名并确定MIME类型
            const fileExtension = fileName.toLowerCase().split('.').pop() || '';
            const mimeType = HttpService.getMimeType(fileExtension);
            console.log('文件扩展名:', fileExtension);
            console.log('MIME类型:', mimeType);
            // 构建multipart/form-data格式
            let body = '';
            // 添加multipartFile字段（文件内容）
            body += `--${boundary}\r\n`;
            body += `Content-Disposition: form-data; name="multipartFile"; filename="${fileName}"\r\n`;
            body += `Content-Type: ${mimeType}\r\n\r\n`;
            body += base64;
            body += `\r\n`;
            // 添加imageName字段
            body += `--${boundary}\r\n`;
            body += `Content-Disposition: form-data; name="imageName"\r\n\r\n`;
            body += fileName;
            body += `\r\n`;
            // 结束边界
            body += `--${boundary}--\r\n`;
            return body;
        }
        catch (error) {
            console.error('构建文件multipart/form-data失败:', error);
            throw new Error('文件读取失败');
        }
    }
    /** 根据文件扩展名获取MIME类型 */
    private static getMimeType(extension: string): string {
        const mimeTypes: Record<string, string> = {
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif',
            'bmp': 'image/bmp',
            'webp': 'image/webp'
        };
        return mimeTypes[extension] || 'image/jpeg';
    }
    /** 将ArrayBuffer转换为Base64 */
    private static arrayBufferToBase64(buffer: Uint8Array): string {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        const result: string[] = [];
        let i = 0;
        while (i < buffer.length) {
            const a = buffer[i++];
            const b = i < buffer.length ? buffer[i++] : 0;
            const c = i < buffer.length ? buffer[i++] : 0;
            const bitmap = (a << 16) | (b << 8) | c;
            result.push(chars.charAt((bitmap >> 18) & 63));
            result.push(chars.charAt((bitmap >> 12) & 63));
            result.push(i - 2 < buffer.length ? chars.charAt((bitmap >> 6) & 63) : '=');
            result.push(i - 1 < buffer.length ? chars.charAt(bitmap & 63) : '=');
        }
        return result.join('');
    }
    /** 获取存储的token */
    static async getToken(): Promise<string | null> {
        // 先检查内存中的token
        if (HttpService.tokenValue) {
            console.log('从内存获取token:', HttpService.tokenValue);
            return HttpService.tokenValue;
        }
        // 从持久化存储中获取token
        try {
            if (HttpService.context) {
                // 修复：正确等待Promise并处理返回值
                const preferencesStore = await preferences.getPreferences(HttpService.context as common.UIAbilityContext, 'user_preferences');
                const token = await preferencesStore.get('user_token', '') as string;
                if (token) {
                    HttpService.tokenValue = token;
                    console.log('从持久化存储获取token:', token);
                    return token;
                }
            }
        }
        catch (error) {
            console.error('获取token失败:', error);
        }
        console.log('没有找到token');
        return null;
    }
    /** 保存token到本地存储 */
    static async saveToken(token: string): Promise<void> {
        console.log('保存token:', token);
        HttpService.tokenValue = token;
        // 尝试保存到持久化存储
        try {
            if (HttpService.context) {
                // 修复：正确等待Promise并处理返回值
                const preferencesStore = await preferences.getPreferences(HttpService.context as common.UIAbilityContext, 'user_preferences');
                await preferencesStore.put('user_token', token);
                await preferencesStore.flush();
                console.log('token已保存到持久化存储');
            }
        }
        catch (error) {
            console.error('保存token到持久化存储失败:', error);
            console.log('继续使用内存存储');
        }
    }
    /** 清除token */
    static async clearToken(): Promise<void> {
        HttpService.tokenValue = null;
        // 从持久化存储中清除token
        try {
            if (HttpService.context) {
                // 修复：正确等待Promise并处理返回值
                const preferencesStore = await preferences.getPreferences(HttpService.context as common.UIAbilityContext, 'user_preferences');
                await preferencesStore.delete('user_token');
                await preferencesStore.flush();
                console.log('token已从持久化存储清除');
            }
        }
        catch (error) {
            console.error('清除token失败:', error);
        }
    }
}
