# 图片分享应用

一个基于HarmonyOS的图片分享应用，用户可以上传、浏览、点赞和评论图片。

## 功能特性

### 主要功能
- **图片浏览**: 随机展示平台上的图片，支持下拉刷新
- **用户认证**: 用户注册、登录功能
- **图片上传**: 支持从相册选择图片并上传到平台
- **点赞功能**: 对喜欢的图片进行点赞/取消点赞
- **个人中心**: 查看个人发布的作品数量，管理自己的图片
- **评论系统**: 对图片发表评论（接口已提供，UI待完善）

### 界面设计
- **渐变背景**: 使用浅绿色渐变背景，营造清新的视觉效果
- **现代化UI**: 采用卡片式设计，圆角和阴影效果
- **响应式布局**: 适配不同屏幕尺寸的设备

## 项目结构

```
entry/src/main/ets/
├── models/              # 数据模型
│   ├── User.ets        # 用户相关数据模型
│   ├── Image.ets       # 图片相关数据模型
│   └── Comment.ets     # 评论相关数据模型
├── services/           # API服务层
│   ├── HttpService.ets # HTTP请求封装
│   └── ApiService.ets  # API接口调用
└── pages/              # 页面组件
    ├── Index.ets       # 主页（图片浏览）
    ├── LoginPage.ets   # 登录页面
    ├── RegisterPage.ets# 注册页面
    ├── UploadPage.ets  # 图片上传页面
    └── ProfilePage.ets # 个人中心页面
```

## 技术栈

- **开发语言**: ArkTS
- **UI框架**: HarmonyOS ArkUI
- **网络请求**: @ohos.net.http
- **图片处理**: @ohos.multimedia.image
- **文件选择**: @ohos.file.picker
- **路由导航**: @ohos.router

## 配置说明

### 1. 后端接口配置
在 `services/HttpService.ets` 中修改 `BASE_URL` 为你的后端服务地址：

```typescript
private static readonly BASE_URL = 'http://your-backend-url';
```

### 2. 网络权限
确保在 `module.json5` 中配置了网络权限：

```json
{
  "requestPermissions": [
    {
      "name": "ohos.permission.INTERNET"
    }
  ]
}
```

### 3. 图标资源
应用中使用了一些图标资源，你需要在 `resources/base/media/` 目录下添加以下图标：
- `ic_upload` - 上传图标
- `ic_profile` - 个人中心图标
- `ic_back` - 返回图标
- `ic_heart` - 点赞图标（未选中）
- `ic_heart_filled` - 点赞图标（已选中）
- `ic_add_image` - 添加图片图标
- `ic_app_logo` - 应用Logo
- `ic_default_avatar` - 默认头像
- `ic_empty` - 空状态图标

## API接口说明

应用已对接以下后端接口：

### 用户相关
- `POST /api/user/register` - 用户注册
- `POST /api/user/login` - 用户登录

### 图片相关
- `POST /api/image/imageUpload` - 上传图片
- `POST /api/image/getImageRandomly` - 随机获取图片
- `POST /api/image/getMyImage` - 获取我的发布
- `GET /api/image/getMyImageNumber` - 获取个人发布作品数

### 交互相关
- `POST /api/userLike/changeUserLike` - 点赞/取消点赞
- `POST /api/comments/postComments` - 发表评论
- `POST /api/comments/deleteComments` - 删除评论

## 使用说明

### 开发环境
1. 安装DevEco Studio 4.0或更高版本
2. 配置HarmonyOS SDK
3. 连接HarmonyOS设备或启动模拟器

### 运行项目
1. 克隆项目到本地
2. 在DevEco Studio中打开项目
3. 配置后端接口地址
4. 添加必要的图标资源
5. 运行到设备或模拟器

### 主要操作流程
1. **首次使用**: 注册账号 → 登录
2. **浏览图片**: 在主页面查看随机图片，下拉刷新获取新图片
3. **上传图片**: 点击上传按钮 → 选择图片 → 填写图片名称 → 上传
4. **点赞互动**: 点击图片上的心形图标进行点赞
5. **个人中心**: 查看个人作品数量和管理已发布的图片

## 注意事项

1. **网络配置**: 确保设备能够访问后端服务
2. **权限申请**: 首次上传图片时需要授权访问相册权限
3. **图片格式**: 支持JPG、PNG格式，建议大小不超过10MB
4. **Token管理**: 目前token管理为简化实现，实际项目中需要完善本地存储

## 后续优化建议

1. **完善评论功能**: 添加评论列表展示和交互
2. **图片详情页**: 实现点击图片查看大图和详细信息
3. **搜索功能**: 添加图片搜索和分类功能
4. **缓存优化**: 实现图片缓存和离线浏览
5. **用户体验**: 添加加载动画、错误处理等
6. **数据持久化**: 完善用户信息的本地存储

## 许可证

MIT License
