import { HttpService } from "@normalized:N&&&entry/src/main/ets/services/HttpService&";
import type { LoginRequest, RegisterRequest, ApiResponse, LoginSuccessData, UserInfo, UserBasicInfo } from '../models/User';
import type { ImageItem, PageRequest, PageResponse } from '../models/Image';
import type { PostCommentRequest, Comment } from '../models/Comment';
import { RegisterRequestData, LoginRequestData, PageRequestData, ToggleLikeRequestData, PostCommentRequestData, DeleteCommentRequestData, EmptyRequestData, SearchImageRequestData, GetImageInformationRequestData, ChangeBookmarkRequestData, GetCommentsListRequestData, DeleteImageRequestData } from "@normalized:N&&&entry/src/main/ets/models/ApiRequest&";
/** API服务类（完全适配后端接口） */
export class ApiService {
    /** 用户注册（适配后端 /api/user/register） */
    static async register(data: RegisterRequest): Promise<ApiResponse<void>> {
        const requestData = new RegisterRequestData(data.userAccount, data.password, data.username, data.telephoneNumber);
        return HttpService.post<void, RegisterRequestData>('/api/user/register', requestData);
    }
    /** 用户登录（适配后端 /api/user/login） */
    static async login(data: LoginRequest): Promise<ApiResponse<LoginSuccessData>> {
        const requestData = new LoginRequestData(data.userAccount, data.password);
        return HttpService.post<LoginSuccessData, LoginRequestData>('/api/user/login', requestData);
    }
    /** 上传图片（Base64 方案，使用原接口 /api/image/imageUpload） */
    // static async uploadImage(data: ImageUploadRequest): Promise<ApiResponse<void>> {
    //   // 这里由调用方先把文件读成 base64 再传入，此方法保持签名不变
    //   // 为兼容调用方现有传参，此处只负责将已读取的 base64 发给后端
    //   // 注意：真正的 base64 字符串由 UploadPage 读取后通过 data.imageName + base64 传递过来
    //   throw new Error('uploadImage should be called via ApiService.uploadImageBase64 in Base64 mode');
    // }
    //
    // /** 新增：显式的 Base64 上传方法（使用原接口） */
    // static async uploadImageBase64(imageName: string, base64: string): Promise<ApiResponse<void>> {
    //   // 根据后端接口文档，使用 multipartFile 字段名
    //   console.log('使用 multipartFile 格式上传');
    //   const body = new ImageUploadMultipartBody(base64, imageName);
    //   return HttpService.post<void, ImageUploadMultipartBody>('/api/image/imageUpload', body);
    // }
    /** 真正的文件上传方法（使用文件路径） */
    static async uploadImageFile(imageName: string, filePath: string, content: string = '', userImageName?: string): Promise<ApiResponse<void>> {
        console.log('使用文件路径上传:', filePath);
        return HttpService.uploadFile<void>('/api/image/imageUpload', filePath, imageName, content, undefined, userImageName);
    }
    /** MultipartBuilder文件上传方法（使用自定义MultipartBuilder） */
    static async uploadImageFileWithBuilder(imageName: string, filePath: string, content: string = '', userImageName?: string): Promise<ApiResponse<void>> {
        console.log('使用MultipartBuilder上传文件:', filePath);
        return HttpService.uploadFileWithBuilder<void>('/api/image/imageUpload', filePath, imageName, content, undefined, userImageName);
    }
    /** 原生FormData文件上传方法（使用鸿蒙原生FormData） */
    static async uploadImageFileFormData(imageName: string, filePath: string, content: string = ''): Promise<ApiResponse<void>> {
        console.log('使用鸿蒙原生FormData上传文件:', filePath);
        return HttpService.uploadFileNative<void>('/api/image/imageUpload', filePath, imageName, content);
    }
    //
    // /** 使用官方推荐的文件上传方法 */
    // static async uploadImageFileOfficial(imageName: string, filePath: string, content: string = ''): Promise<ApiResponse<void>> {
    //   console.log('使用官方postFile方法上传文件:', filePath);
    //   return HttpService.uploadFileOfficial<void>('/api/image/imageUpload', filePath, imageName, content);
    // }
    //
    // /** 使用@ohos.request.uploadFile进行文件上传（最推荐的方法） */
    // static async uploadImageFileWithRequest(imageName: string, filePath: string, content: string = ''): Promise<ApiResponse<void>> {
    //   console.log('使用@ohos.request.uploadFile上传文件:', filePath);
    //   return HttpService.uploadFileWithRequest<void>('/api/image/imageUpload', filePath, imageName, content);
    // }
    /** 随机获取图片（适配后端 /api/image/getImageRandomly） */
    static async getRandomImages(count: number = 8): Promise<ApiResponse<ImageItem[]>> {
        const url = `/api/image/getImageRandomly?count=${count}`;
        const emptyData = new EmptyRequestData();
        return HttpService.post<ImageItem[], EmptyRequestData>(url, emptyData);
    }
    /** 搜索图片（适配后端 /api/image/searchImage） */
    static async searchImages(imageName: string): Promise<ApiResponse<ImageItem[]>> {
        const requestData = new SearchImageRequestData(imageName);
        return HttpService.post<ImageItem[], SearchImageRequestData>('/api/image/searchImage', requestData);
    }
    /** 查看我的发布（适配后端 /api/image/getMyImage） */
    static async getMyImages(pageData: PageRequest): Promise<ApiResponse<PageResponse<ImageItem>>> {
        const requestData = new PageRequestData(pageData.page, pageData.size);
        return HttpService.post<PageResponse<ImageItem>, PageRequestData>('/api/image/getMyImage', requestData);
    }
    /** 获取个人发布作品数（适配后端 /api/image/getMyImageNumber） */
    static async getMyImageCount(): Promise<ApiResponse<number>> {
        return HttpService.get<number>('/api/image/getMyImageNumber');
    }
    /** 点赞/取消点赞（适配后端 /api/userLike/changeUserLike） */
    static async toggleLike(imageId: number): Promise<ApiResponse<void>> {
        const requestData = new ToggleLikeRequestData(imageId);
        return HttpService.post<void, ToggleLikeRequestData>('/api/userLike/changeUserLike', requestData);
    }
    /** 发表评论（适配后端 /api/comments/postComments） */
    static async postComment(data: PostCommentRequest): Promise<ApiResponse<void>> {
        const requestData = new PostCommentRequestData(data.content, data.imageId);
        return HttpService.post<void, PostCommentRequestData>('/api/comments/postComments', requestData);
    }
    /** 删除评论（适配后端 /api/comments/deleteComments） */
    static async deleteComment(commentId: number): Promise<ApiResponse<void>> {
        const requestData = new DeleteCommentRequestData(commentId);
        return HttpService.post<void, DeleteCommentRequestData>('/api/comments/deleteComments', requestData);
    }
    /** 删除图片（适配后端 /api/image/deleteImage） */
    // static async deleteImage(imageId: number): Promise<ApiResponse<void>> {
    //   const requestData = new DeleteCommentRequestData(imageId);
    //   return HttpService.post<void, DeleteCommentRequestData>('/api/bookmark/deleteImage', requestData);
    // }
    /** 删除图片（适配后端 /api/image/deleteImage） */
    static async deleteImage(imageId: number): Promise<ApiResponse<void>> {
        const requestData = new DeleteImageRequestData(imageId);
        return HttpService.post<void, DeleteImageRequestData>('/api/image/deleteImage', requestData);
    }
    /** 获取图片详情（适配后端 /api/image/getImageDetail） */
    static async getImageDetail(imageId: number): Promise<ApiResponse<ImageItem>> {
        const url = `/api/image/getImageDetail?imageId=${imageId}`;
        const emptyData = new EmptyRequestData();
        return HttpService.post<ImageItem, EmptyRequestData>(url, emptyData);
    }
    /** 获取图片评论列表（适配后端 /api/comments/getCommentsList） */
    static async getImageComments(imageId: number): Promise<ApiResponse<Comment[]>> {
        const requestData = new GetCommentsListRequestData(imageId);
        return HttpService.post<Comment[], GetCommentsListRequestData>('/api/comments/getCommentsList', requestData);
    }
    /** 获取收藏列表（适配后端 /api/bookmark/getBookmarkList） */
    static async getBookmarkList(): Promise<ApiResponse<ImageItem[]>> {
        return HttpService.get<ImageItem[]>('/api/bookmark/getBookmarkList');
    }
    /** 获取用户信息 */
    static async getUserInfo(): Promise<ApiResponse<UserInfo>> {
        return HttpService.get<UserInfo>('/api/user/getUserInfo');
    }
    /** 获取用户浏览记录 */
    static async getBrowsingHistoryList(): Promise<ApiResponse<ImageItem[]>> {
        return HttpService.get<ImageItem[]>('/api/bookmark/getBrowsingHistoryList');
    }
    /** 获取图片基础信息并记录浏览记录 */
    static async getImageInformation(imageId: number): Promise<ApiResponse<ImageItem>> {
        const requestData = new GetImageInformationRequestData(imageId);
        return HttpService.post<ImageItem, GetImageInformationRequestData>('/api/image/getImageInformation', requestData);
    }
    /** 收藏/取消收藏 */
    static async changeBookmark(imageId: number): Promise<ApiResponse<void>> {
        const requestData = new ChangeBookmarkRequestData(imageId);
        return HttpService.post<void, ChangeBookmarkRequestData>('/api/bookmark/changeBookmark', requestData);
    }
    /** 上传用户头像（使用 /api/user/changeUserHeadshot） */
    static async uploadUserAvatar(filePath: string, fileName: string): Promise<ApiResponse<string>> {
        console.log('上传用户头像:', filePath);
        return HttpService.uploadFileNative<string>('/api/user/changeUserHeadshot', filePath, fileName, '', undefined, 'headshotImage');
    }
    /** 获取用户基本信息（使用 /api/user/getUserBasicInformation） */
    static async getUserBasicInformation(): Promise<ApiResponse<UserBasicInfo>> {
        return HttpService.get<UserBasicInfo>('/api/user/getUserBasicInformation');
    }
}
