/**
 * 颜色常量定义
 */
export class Colors {
    // 白色透明度变体
    static readonly White10 = 'rgba(255, 255, 255, 0.1)';
    static readonly White20 = 'rgba(255, 255, 255, 0.2)';
    static readonly White40 = 'rgba(255, 255, 255, 0.4)';
    static readonly White60 = 'rgba(255, 255, 255, 0.6)';
    // 黑色透明度变体（用于统一文本为黑色）
    static readonly Black10 = 'rgba(0, 0, 0, 0.1)';
    static readonly Black20 = 'rgba(0, 0, 0, 0.2)';
    static readonly Black40 = 'rgba(0, 0, 0, 0.4)';
    static readonly Black60 = 'rgba(0, 0, 0, 0.6)';
    // 渐变色
    static readonly PrimaryGreen = '#4CAF50';
    static readonly LightGreen = '#E8F5E8';
}
