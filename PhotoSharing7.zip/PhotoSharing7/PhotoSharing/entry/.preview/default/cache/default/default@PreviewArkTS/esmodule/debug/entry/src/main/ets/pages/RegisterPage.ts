if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface RegisterPage_Params {
    userAccount?: string;
    password?: string;
    confirmPassword?: string;
    username?: string;
    telephoneNumber?: string;
    isLoading?: boolean;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import type { RegisterRequest } from '../models/User';
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
class RegisterPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__userAccount = new ObservedPropertySimplePU('', this, "userAccount");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__confirmPassword = new ObservedPropertySimplePU('', this, "confirmPassword");
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.__telephoneNumber = new ObservedPropertySimplePU('', this, "telephoneNumber");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: RegisterPage_Params) {
        if (params.userAccount !== undefined) {
            this.userAccount = params.userAccount;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.confirmPassword !== undefined) {
            this.confirmPassword = params.confirmPassword;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
        if (params.telephoneNumber !== undefined) {
            this.telephoneNumber = params.telephoneNumber;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
    }
    updateStateVars(params: RegisterPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__userAccount.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__confirmPassword.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
        this.__telephoneNumber.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__userAccount.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__confirmPassword.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        this.__telephoneNumber.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __userAccount: ObservedPropertySimplePU<string>;
    get userAccount() {
        return this.__userAccount.get();
    }
    set userAccount(newValue: string) {
        this.__userAccount.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __confirmPassword: ObservedPropertySimplePU<string>;
    get confirmPassword() {
        return this.__confirmPassword.get();
    }
    set confirmPassword(newValue: string) {
        this.__confirmPassword.set(newValue);
    }
    private __username: ObservedPropertySimplePU<string>;
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    private __telephoneNumber: ObservedPropertySimplePU<string>;
    get telephoneNumber() {
        return this.__telephoneNumber.get();
    }
    set telephoneNumber(newValue: string) {
        this.__telephoneNumber.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    /** 注册处理 */
    async register() {
        // 表单验证
        if (!this.userAccount.trim()) {
            promptAction.showToast({ message: '请输入账号' });
            return;
        }
        if (!this.password.trim()) {
            promptAction.showToast({ message: '请输入密码' });
            return;
        }
        if (this.password !== this.confirmPassword) {
            promptAction.showToast({ message: '两次输入的密码不一致' });
            return;
        }
        if (!this.username.trim()) {
            promptAction.showToast({ message: '请输入用户名' });
            return;
        }
        if (!this.telephoneNumber.trim()) {
            promptAction.showToast({ message: '请输入手机号' });
            return;
        }
        this.isLoading = true;
        try {
            const request: RegisterRequest = {
                userAccount: this.userAccount.trim(),
                password: this.password.trim(),
                username: this.username.trim(),
                telephoneNumber: this.telephoneNumber.trim()
            };
            const response = await ApiService.register(request);
            if (response.code === 1) {
                promptAction.showToast({ message: '注册成功' });
                // 返回登录页面
                router.back();
            }
            else {
                promptAction.showToast({ message: response.msg || '注册失败' });
            }
        }
        catch (error) {
            console.error('注册失败:', error);
            promptAction.showToast({ message: '注册失败，请检查网络连接' });
        }
        finally {
            this.isLoading = false;
        }
    }
    /** 返回上一页 */
    goBack() {
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(351:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RegisterPage.ets(353:7)", "entry");
            // 顶部导航栏
            Row.width('100%');
            // 顶部导航栏
            Row.height(56);
            // 顶部导航栏
            Row.padding({ left: 16, right: 16 });
            // 顶部导航栏
            Row.backgroundColor(Color.Transparent);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('←');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(354:9)", "entry");
            Text.fontSize(24);
            Text.fontColor(Color.Black);
            Text.onClick(() => this.goBack());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('注册');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(359:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
            Text.margin({ left: 16 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/RegisterPage.ets(365:9)", "entry");
        }, Blank);
        Blank.pop();
        // 顶部导航栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 注册表单
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/RegisterPage.ets(373:7)", "entry");
            // 注册表单
            Scroll.layoutWeight(1);
            // 注册表单
            Scroll.scrollable(ScrollDirection.Vertical);
            // 注册表单
            Scroll.scrollBar(BarState.Auto);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(374:9)", "entry");
            Column.width('100%');
            Column.padding({ left: 32, right: 32, bottom: 32 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 标题区域
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(376:11)", "entry");
            // 标题区域
            Column.margin({ top: 20, bottom: 30 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('创建账号');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(377:13)", "entry");
            Text.fontSize(24);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('加入我们，分享你的精彩瞬间');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(382:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Colors.Black60);
        }, Text);
        Text.pop();
        // 标题区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 输入表单
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(389:11)", "entry");
            // 输入表单
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 账号输入框
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(391:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('账号');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(392:15)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入账号' });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(398:15)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.onChange((value: string) => {
                this.userAccount = value;
            });
        }, TextInput);
        // 账号输入框
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 用户名输入框
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(412:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('用户名');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(413:15)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入用户名' });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(419:15)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.onChange((value: string) => {
                this.username = value;
            });
        }, TextInput);
        // 用户名输入框
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 手机号输入框
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(433:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('手机号');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(434:15)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入手机号' });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(440:15)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.type(InputType.PhoneNumber);
            TextInput.onChange((value: string) => {
                this.telephoneNumber = value;
            });
        }, TextInput);
        // 手机号输入框
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 密码输入框
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(455:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('密码');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(456:15)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入密码' });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(462:15)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.type(InputType.Password);
            TextInput.onChange((value: string) => {
                this.password = value;
            });
        }, TextInput);
        // 密码输入框
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 确认密码输入框
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/RegisterPage.ets(477:13)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('确认密码');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(478:15)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请再次输入密码' });
            TextInput.debugLine("entry/src/main/ets/pages/RegisterPage.ets(484:15)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.type(InputType.Password);
            TextInput.onChange((value: string) => {
                this.confirmPassword = value;
            });
        }, TextInput);
        // 确认密码输入框
        Column.pop();
        // 输入表单
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 注册按钮
            Button.createWithLabel(this.isLoading ? '注册中...' : '注册');
            Button.debugLine("entry/src/main/ets/pages/RegisterPage.ets(501:11)", "entry");
            // 注册按钮
            Button.width('100%');
            // 注册按钮
            Button.height(48);
            // 注册按钮
            Button.backgroundColor('#4CAF50');
            // 注册按钮
            Button.borderRadius(8);
            // 注册按钮
            Button.fontSize(16);
            // 注册按钮
            Button.fontWeight(FontWeight.Medium);
            // 注册按钮
            Button.fontColor(Color.Black);
            // 注册按钮
            Button.enabled(!this.isLoading);
            // 注册按钮
            Button.onClick(() => this.register());
            // 注册按钮
            Button.margin({ top: 20 });
        }, Button);
        // 注册按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 登录链接
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/RegisterPage.ets(514:11)", "entry");
            // 登录链接
            Row.margin({ top: 16 });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('已有账号？');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(515:13)", "entry");
            Text.fontSize(14);
            Text.fontColor(Colors.Black60);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('立即登录');
            Text.debugLine("entry/src/main/ets/pages/RegisterPage.ets(519:13)", "entry");
            Text.fontSize(14);
            Text.fontColor('#4CAF50');
            Text.fontWeight(FontWeight.Medium);
            Text.onClick(() => this.goBack());
        }, Text);
        Text.pop();
        // 登录链接
        Row.pop();
        Column.pop();
        // 注册表单
        Scroll.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "RegisterPage";
    }
}
registerNamedRoute(() => new RegisterPage(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/RegisterPage", pageFullPath: "entry/src/main/ets/pages/RegisterPage", integratedHsp: "false", moduleType: "followWithHap" });
