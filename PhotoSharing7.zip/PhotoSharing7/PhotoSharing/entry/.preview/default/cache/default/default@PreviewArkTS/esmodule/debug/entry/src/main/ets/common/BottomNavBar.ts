if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface BottomNavBar_Params {
    currentPage?: string;
}
import router from "@ohos:router";
export class BottomNavBar extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__currentPage = new SynchedPropertySimpleOneWayPU(params.currentPage, this, "currentPage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: BottomNavBar_Params) {
    }
    updateStateVars(params: BottomNavBar_Params) {
        this.__currentPage.reset(params.currentPage);
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__currentPage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __currentPage: SynchedPropertySimpleOneWayPU<string>; // 由父页面传入当前页面状态
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: string) {
        this.__currentPage.set(newValue);
    }
    /**
     * 切换到首页
     */
    navigateToHome() {
        router.replaceUrl({ url: 'pages/Index' });
        this.currentPage = 'home';
    }
    /**
     * 切换到上传页面
     */
    navigateToUpload() {
        router.replaceUrl({ url: 'pages/UploadPage' });
        this.currentPage = 'upload';
    }
    /**
     * 切换到个人中心
     */
    navigateToProfile() {
        router.replaceUrl({ url: 'pages/ProfilePage' });
        this.currentPage = 'profile';
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/common/BottomNavBar.ets(35:5)", "entry");
            Row.width('100%');
            Row.height(80);
            Row.backgroundColor(Color.White);
            Row.borderRadius({ topLeft: 20, topRight: 20 });
            Row.shadow({
                radius: 10,
                color: 'rgba(0, 0, 0, 0.1)',
                offsetX: 0,
                offsetY: -2
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 首页
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/common/BottomNavBar.ets(37:7)", "entry");
            // 首页
            Column.onClick(() => this.navigateToHome());
            // 首页
            Column.layoutWeight(1);
            // 首页
            Column.justifyContent(FlexAlign.Center);
            // 首页
            Column.padding({ top: 8, bottom: 8 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777249, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/common/BottomNavBar.ets(38:9)", "entry");
            Image.width(24);
            Image.height(24);
            Image.opacity(this.currentPage === 'home' ? 1.0 : 0.6);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('首页');
            Text.debugLine("entry/src/main/ets/common/BottomNavBar.ets(43:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(this.currentPage === 'home' ? '#4CAF50' : '#999999');
        }, Text);
        Text.pop();
        // 首页
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 添加按钮
            Column.create();
            Column.debugLine("entry/src/main/ets/common/BottomNavBar.ets(53:7)", "entry");
            // 添加按钮
            Column.justifyContent(FlexAlign.Center);
            // 添加按钮
            Column.padding({ top: 8, bottom: 8 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild();
            Button.debugLine("entry/src/main/ets/common/BottomNavBar.ets(54:9)", "entry");
            Button.width(56);
            Button.height(56);
            Button.backgroundColor('#4CAF50');
            Button.borderRadius(28);
            Button.onClick(() => this.navigateToUpload());
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('+');
            Text.debugLine("entry/src/main/ets/common/BottomNavBar.ets(55:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(Color.White);
            Text.fontWeight(FontWeight.Bold);
        }, Text);
        Text.pop();
        Button.pop();
        // 添加按钮
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 个人中心
            Column.create({ space: 4 });
            Column.debugLine("entry/src/main/ets/common/BottomNavBar.ets(70:7)", "entry");
            // 个人中心
            Column.onClick(() => this.navigateToProfile());
            // 个人中心
            Column.layoutWeight(1);
            // 个人中心
            Column.justifyContent(FlexAlign.Center);
            // 个人中心
            Column.padding({ top: 8, bottom: 8 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777250, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/common/BottomNavBar.ets(71:9)", "entry");
            Image.width(24);
            Image.height(24);
            Image.opacity(this.currentPage === 'profile' ? 1.0 : 0.6);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的');
            Text.debugLine("entry/src/main/ets/common/BottomNavBar.ets(76:9)", "entry");
            Text.fontSize(12);
            Text.fontColor(this.currentPage === 'profile' ? '#4CAF50' : '#999999');
        }, Text);
        Text.pop();
        // 个人中心
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
