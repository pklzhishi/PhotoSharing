if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface UploadPage_Params {
    selectedImagePath?: string;
    imageName?: string;
    content?: string;
    isUploading?: boolean;
    previewImage?: image.PixelMap | null;
}
import router from "@ohos:router";
import picker from "@ohos:file.picker";
import promptAction from "@ohos:promptAction";
import fs from "@ohos:file.fs";
import image from "@ohos:multimedia.image";
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
import type { ApiResponse } from '../models/User';
import { BottomNavBar } from "@normalized:N&&&entry/src/main/ets/common/BottomNavBar&";
class UploadPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__selectedImagePath = new ObservedPropertySimplePU('', this, "selectedImagePath");
        this.__imageName = new ObservedPropertySimplePU('', this, "imageName");
        this.__content = new ObservedPropertySimplePU('', this, "content");
        this.__isUploading = new ObservedPropertySimplePU(false, this, "isUploading");
        this.__previewImage = new ObservedPropertyObjectPU(null, this, "previewImage");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: UploadPage_Params) {
        if (params.selectedImagePath !== undefined) {
            this.selectedImagePath = params.selectedImagePath;
        }
        if (params.imageName !== undefined) {
            this.imageName = params.imageName;
        }
        if (params.content !== undefined) {
            this.content = params.content;
        }
        if (params.isUploading !== undefined) {
            this.isUploading = params.isUploading;
        }
        if (params.previewImage !== undefined) {
            this.previewImage = params.previewImage;
        }
    }
    updateStateVars(params: UploadPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__selectedImagePath.purgeDependencyOnElmtId(rmElmtId);
        this.__imageName.purgeDependencyOnElmtId(rmElmtId);
        this.__content.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploading.purgeDependencyOnElmtId(rmElmtId);
        this.__previewImage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__selectedImagePath.aboutToBeDeleted();
        this.__imageName.aboutToBeDeleted();
        this.__content.aboutToBeDeleted();
        this.__isUploading.aboutToBeDeleted();
        this.__previewImage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __selectedImagePath: ObservedPropertySimplePU<string>;
    get selectedImagePath() {
        return this.__selectedImagePath.get();
    }
    set selectedImagePath(newValue: string) {
        this.__selectedImagePath.set(newValue);
    }
    private __imageName: ObservedPropertySimplePU<string>;
    get imageName() {
        return this.__imageName.get();
    }
    set imageName(newValue: string) {
        this.__imageName.set(newValue);
    }
    private __content: ObservedPropertySimplePU<string>;
    get content() {
        return this.__content.get();
    }
    set content(newValue: string) {
        this.__content.set(newValue);
    }
    private __isUploading: ObservedPropertySimplePU<boolean>;
    get isUploading() {
        return this.__isUploading.get();
    }
    set isUploading(newValue: boolean) {
        this.__isUploading.set(newValue);
    }
    private __previewImage: ObservedPropertyObjectPU<image.PixelMap | null>;
    get previewImage() {
        return this.__previewImage.get();
    }
    set previewImage(newValue: image.PixelMap | null) {
        this.__previewImage.set(newValue);
    }
    aboutToAppear() {
        // 页面初始化
    }
    /**
     * 选择图片
     */
    async selectImage() {
        try {
            const photoSelectOptions = new picker.PhotoSelectOptions();
            photoSelectOptions.MIMEType = picker.PhotoViewMIMETypes.IMAGE_TYPE;
            photoSelectOptions.maxSelectNumber = 1;
            const photoPicker = new picker.PhotoViewPicker();
            const photoSelectResult = await photoPicker.select(photoSelectOptions);
            if (photoSelectResult.photoUris && photoSelectResult.photoUris.length > 0) {
                this.selectedImagePath = photoSelectResult.photoUris[0];
                this.loadPreviewImage();
                // 提取文件扩展名用于生成文件名
                const pathExtension = this.selectedImagePath.split('.').pop()?.toLowerCase() || 'jpg';
                console.log('选择的图片路径:', this.selectedImagePath);
                console.log('提取的扩展名:', pathExtension);
                // 从文件路径中提取真实文件名
                const realFileName = this.selectedImagePath.split('/').pop() || '';
                console.log('从路径提取的真实文件名:', realFileName);
                // 如果没有设置图片名称，使用真实文件名
                if (!this.imageName) {
                    this.imageName = realFileName; // 直接使用真实文件名
                }
                else {
                    // 如果用户已经输入了图片名称，确保包含正确的扩展名
                    const currentName = this.imageName.trim();
                    if (!currentName.includes('.')) {
                        // 用户没有输入扩展名，自动添加
                        this.imageName = `${currentName}.${pathExtension}`;
                    }
                    else {
                        // 用户已经输入了扩展名，检查是否正确
                        const userExt = currentName.split('.').pop()?.toLowerCase() || '';
                        if (userExt !== pathExtension) {
                            // 扩展名不匹配，使用正确的扩展名
                            const nameWithoutExt = currentName.split('.')[0];
                            this.imageName = `${nameWithoutExt}.${pathExtension}`;
                        }
                    }
                }
                console.log('最终图片名称:', this.imageName);
            }
        }
        catch (error) { // 去掉类型标注
            console.error('选择图片失败:', error);
            promptAction.showToast({ message: '选择图片失败' });
        }
    }
    /**
     * 加载预览图片
     */
    async loadPreviewImage() {
        if (!this.selectedImagePath)
            return;
        try {
            const file = fs.openSync(this.selectedImagePath, fs.OpenMode.READ_ONLY);
            const imageSource = image.createImageSource(file.fd);
            this.previewImage = await imageSource.createPixelMap();
            fs.closeSync(file);
        }
        catch (error) { // 去掉类型标注
            console.error('加载预览图片失败:', error);
        }
    }
    /**
     * 上传图片
     */
    async uploadImage() {
        if (!this.selectedImagePath) {
            promptAction.showToast({ message: '请先选择图片' });
            return;
        }
        if (!this.imageName.trim()) {
            promptAction.showToast({ message: '请输入图片名称' });
            return;
        }
        this.isUploading = true;
        try {
            console.log('开始上传图片，文件名:', this.imageName.trim());
            console.log('文件路径:', this.selectedImagePath);
            console.log('内容描述:', this.content.trim());
            // 添加文件格式检查 - 从实际文件路径中提取扩展名
            const actualFileExtension = this.selectedImagePath.split('.').pop()?.toLowerCase() || '';
            const userFileExtension = this.imageName.trim().split('.').pop()?.toLowerCase() || '';
            console.log('实际文件路径:', this.selectedImagePath);
            console.log('实际文件扩展名:', actualFileExtension);
            console.log('用户输入文件名:', this.imageName.trim());
            console.log('用户输入扩展名:', userFileExtension);
            console.log('支持的文件格式: jpg, jpeg, png, gif');
            // 使用实际文件扩展名进行验证
            const fileExtension = actualFileExtension;
            console.log('用于验证的扩展名:', fileExtension);
            console.log('当前文件格式是否支持:', ['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension));
            if (!['jpg', 'jpeg', 'png', 'gif'].includes(fileExtension)) {
                promptAction.showToast({ message: '请选择 jpg、jpeg、png、gif 格式的图片' });
                return;
            }
            // 验证文件是否存在和可读
            try {
                const testFile = fs.openSync(this.selectedImagePath, fs.OpenMode.READ_ONLY);
                const testStat = fs.statSync(testFile.fd);
                console.log('a文件验证成功:');
                console.log('a- 文件大小:', testStat.size, '字节');
                console.log('a- 文件可读性: 正常');
                fs.closeSync(testFile);
            }
            catch (fileError) {
                console.error('a文件验证失败:', fileError);
                promptAction.showToast({ message: '文件读取失败，请重新选择图片' });
                return;
            }
            // 这段代码已被移除，因为上传逻辑已经通过ApiService处理
            // 直接使用原始multipart方法（已验证能成功到达后端）
            let response: ApiResponse<void>;
            try {
                console.log('a=== 开始上传流程 ===');
                console.log('a使用原始multipart方法上传...');
                console.log('a上传参数检查:');
                console.log('a- 文件名:', this.imageName.trim());
                console.log('a- 文件路径:', this.selectedImagePath);
                console.log('a- 内容描述:', this.content.trim());
                // 提取用户输入的图片名称（不包含扩展名）
                const userImageName = this.imageName.trim().split('.')[0];
                // 从文件路径获取实际扩展名
                const actualExtension = this.selectedImagePath.split('.').pop()?.toLowerCase() || 'jpg';
                // 构建完整文件名：用户名称 + 实际扩展名
                const fullFileName = `${userImageName}.${actualExtension}`;
                console.log('你用户输入的图片名称（不含扩展名）:', userImageName);
                console.log('你从文件路径获取的扩展名:', actualExtension);
                console.log('你构建的完整文件名:', fullFileName);
                console.log('你实际文件路径:', this.selectedImagePath);
                console.log('你用户当前输入的文件名:', this.imageName.trim());
                console.log('你即将传递给后端的imageName字段:', userImageName);
                console.log('你即将传递给后端的multipartFile字段:', fullFileName);
                // 验证文件完整性
                try {
                    const testFile = fs.openSync(this.selectedImagePath, fs.OpenMode.READ_ONLY);
                    const testStat = fs.statSync(testFile.fd);
                    const testBuffer = new ArrayBuffer(testStat.size);
                    fs.readSync(testFile.fd, testBuffer);
                    fs.closeSync(testFile);
                    const testArray = new Uint8Array(testBuffer);
                    console.log('a文件验证 - 原始大小:', testArray.length);
                    console.log('a文件验证 - 前10个字节:', Array.from(testArray.slice(0, 10)));
                    console.log('a文件验证 - 后10个字节:', Array.from(testArray.slice(-10)));
                }
                catch (verifyError) {
                    console.error('a文件验证失败:', verifyError);
                    throw new Error('文件验证失败');
                }
                // 尝试使用鸿蒙原生FormData方法（不使用Base64）
                response = await ApiService.uploadImageFileFormData(fullFileName, this.selectedImagePath, this.content.trim());
            }
            catch (error) {
                console.error('上传失败:', error);
                if (error instanceof Error) {
                    throw error;
                }
                else {
                    throw new Error(String(error));
                }
            }
            console.log('你上传响应详情:');
            console.log('你- 响应码:', response.code);
            console.log('你 响应消息:', response.msg);
            console.log('你 响应数据:', response.data);
            console.log('你- 完整响应:', JSON.stringify(response));
            if (response.code === 1) {
                console.log('a上传成功，准备清空表单');
                promptAction.showToast({ message: '上传成功' });
                // 清空表单
                this.selectedImagePath = '';
                this.imageName = '';
                this.content = '';
                this.previewImage = null;
                // 返回主页
                router.back();
            }
            else {
                console.error('a上传失败，响应码:', response.code, '错误信息:', response.msg);
                promptAction.showToast({ message: response.msg || '上传失败' });
            }
        }
        catch (error) {
            console.error('上传异常:', error);
            if (error instanceof Error) {
                promptAction.showToast({ message: `上传失败: ${error.message}` });
            }
            else {
                promptAction.showToast({ message: '上传失败，请检查网络连接' });
            }
        }
        finally {
            this.isUploading = false;
        }
    }
    /**
     * 返回
     */
    goBack() {
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(248:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航栏
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/UploadPage.ets(250:7)", "entry");
            // 顶部导航栏
            Row.width('100%');
            // 顶部导航栏
            Row.height(56);
            // 顶部导航栏
            Row.padding({ left: 16, right: 16 });
            // 顶部导航栏
            Row.backgroundColor(Color.Transparent);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('上传图片');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(251:9)", "entry");
            Text.fontSize(18);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/UploadPage.ets(256:9)", "entry");
        }, Blank);
        Blank.pop();
        // 顶部导航栏
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 可滚动的内容区域
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/UploadPage.ets(264:7)", "entry");
            // 可滚动的内容区域
            Scroll.layoutWeight(1);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 上传表单
            Column.create({ space: 24 });
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(266:9)", "entry");
            // 上传表单
            Column.width('100%');
            // 上传表单
            Column.padding({ left: 24, right: 24, top: 24, bottom: 24 });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片选择区域
            Column.create({ space: 16 });
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(268:11)", "entry");
            // 图片选择区域
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.previewImage) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 显示预览图片
                        Image.create(this.previewImage);
                        Image.debugLine("entry/src/main/ets/pages/UploadPage.ets(272:15)", "entry");
                        // 显示预览图片
                        Image.width('100%');
                        // 显示预览图片
                        Image.height(200);
                        // 显示预览图片
                        Image.borderRadius(12);
                        // 显示预览图片
                        Image.objectFit(ImageFit.Cover);
                        // 显示预览图片
                        Image.backgroundColor(Colors.White20);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 图片选择按钮
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(280:15)", "entry");
                        // 图片选择按钮
                        Column.width('100%');
                        // 图片选择按钮
                        Column.height(180);
                        // 图片选择按钮
                        Column.borderRadius(12);
                        // 图片选择按钮
                        Column.backgroundColor(Colors.White10);
                        // 图片选择按钮
                        Column.border({
                            width: 2,
                            color: Colors.White20,
                            style: BorderStyle.Dashed
                        });
                        // 图片选择按钮
                        Column.justifyContent(FlexAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('📷');
                        Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(281:17)", "entry");
                        Text.fontSize(48);
                        Text.opacity(0.6);
                    }, Text);
                    Text.pop();
                    // 图片选择按钮
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel(this.previewImage ? '重新选择' : '选择图片');
            Button.debugLine("entry/src/main/ets/pages/UploadPage.ets(297:13)", "entry");
            Button.width('100%');
            Button.height(40);
            Button.backgroundColor(Colors.White20);
            Button.borderRadius(8);
            Button.fontSize(14);
            Button.fontColor(Color.Black);
            Button.onClick(() => this.selectImage());
        }, Button);
        Button.pop();
        // 图片选择区域
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 图片名称输入
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(309:11)", "entry");
            // 图片名称输入
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('图片标题');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(310:13)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入图片标题' });
            TextInput.debugLine("entry/src/main/ets/pages/UploadPage.ets(316:13)", "entry");
            TextInput.width('100%');
            TextInput.height(48);
            TextInput.backgroundColor(Colors.White20);
            TextInput.borderRadius(8);
            TextInput.fontSize(16);
            TextInput.fontColor(Color.Black);
            TextInput.placeholderColor(Colors.Black40);
            TextInput.onChange((value: string) => {
                this.imageName = value;
            });
        }, TextInput);
        // 图片名称输入
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 内容描述输入
            Column.create({ space: 8 });
            Column.debugLine("entry/src/main/ets/pages/UploadPage.ets(331:11)", "entry");
            // 内容描述输入
            Column.width('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('内容描述');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(332:13)", "entry");
            Text.fontSize(14);
            Text.fontWeight(FontWeight.Medium);
            Text.fontColor(Color.Black);
            Text.alignSelf(ItemAlign.Start);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create({ placeholder: '请输入图片内容描述（可选）' });
            TextArea.debugLine("entry/src/main/ets/pages/UploadPage.ets(338:13)", "entry");
            TextArea.width('100%');
            TextArea.height(80);
            TextArea.backgroundColor(Colors.White20);
            TextArea.borderRadius(8);
            TextArea.fontSize(16);
            TextArea.fontColor(Color.Black);
            TextArea.placeholderColor(Colors.Black40);
            TextArea.onChange((value: string) => {
                this.content = value;
            });
        }, TextArea);
        // 内容描述输入
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 上传按钮
            Button.createWithLabel(this.isUploading ? '上传中...' : '上传图片');
            Button.debugLine("entry/src/main/ets/pages/UploadPage.ets(353:11)", "entry");
            // 上传按钮
            Button.width('100%');
            // 上传按钮
            Button.height(48);
            // 上传按钮
            Button.backgroundColor('#4CAF50');
            // 上传按钮
            Button.borderRadius(8);
            // 上传按钮
            Button.fontSize(16);
            // 上传按钮
            Button.fontWeight(FontWeight.Medium);
            // 上传按钮
            Button.fontColor(Color.White);
            // 上传按钮
            Button.enabled(!this.isUploading && this.selectedImagePath !== '');
            // 上传按钮
            Button.onClick(() => this.uploadImage());
            // 上传按钮
            Button.margin({ top: 5 });
        }, Button);
        // 上传按钮
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 提示信息
            Text.create('支持 JPG、PNG 格式，建议大小不超过 10MB');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(366:11)", "entry");
            // 提示信息
            Text.fontSize(12);
            // 提示信息
            Text.fontColor(Colors.Black60);
            // 提示信息
            Text.textAlign(TextAlign.Center);
            // 提示信息
            Text.margin({ top: 16 });
        }, Text);
        // 提示信息
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 添加底部间距，确保内容不会被底部导航栏遮挡
            Text.create('');
            Text.debugLine("entry/src/main/ets/pages/UploadPage.ets(373:11)", "entry");
            // 添加底部间距，确保内容不会被底部导航栏遮挡
            Text.height(80);
        }, Text);
        // 添加底部间距，确保内容不会被底部导航栏遮挡
        Text.pop();
        // 上传表单
        Column.pop();
        // 可滚动的内容区域
        Scroll.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // 底部导航栏 - 固定在底部
                    BottomNavBar(this, { currentPage: 'upload' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/UploadPage.ets", line: 382, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            currentPage: 'upload'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        currentPage: 'upload'
                    });
                }
            }, { name: "BottomNavBar" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "UploadPage";
    }
}
registerNamedRoute(() => new UploadPage(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/UploadPage", pageFullPath: "entry/src/main/ets/pages/UploadPage", integratedHsp: "false", moduleType: "followWithHap" });
