if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    images?: ImageItem[];
    isLoading?: boolean;
    isRefreshing?: boolean;
    searchText?: string;
    isSearching?: boolean;
    showSearchInput?: boolean;
    searchInputOpacity?: number;
    searchInputHeight?: number;
    isSearchResult?: boolean;
    userAvatarUrl?: string;
    username?: string;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import type { ImageItem } from '../models/Image';
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
import { BottomNavBar } from "@normalized:N&&&entry/src/main/ets/common/BottomNavBar&";
import { UserState } from "@normalized:N&&&entry/src/main/ets/services/UserState&";
import { HttpService } from "@normalized:N&&&entry/src/main/ets/services/HttpService&";
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__images = new ObservedPropertyObjectPU([], this, "images");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.__searchText = new ObservedPropertySimplePU('', this, "searchText");
        this.__isSearching = new ObservedPropertySimplePU(false, this, "isSearching");
        this.__showSearchInput = new ObservedPropertySimplePU(false, this, "showSearchInput");
        this.__searchInputOpacity = new ObservedPropertySimplePU(0, this, "searchInputOpacity");
        this.__searchInputHeight = new ObservedPropertySimplePU(0, this, "searchInputHeight");
        this.__isSearchResult = new ObservedPropertySimplePU(false, this, "isSearchResult");
        this.__userAvatarUrl = new ObservedPropertySimplePU('', this, "userAvatarUrl");
        this.__username = new ObservedPropertySimplePU('', this, "username");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.images !== undefined) {
            this.images = params.images;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.searchText !== undefined) {
            this.searchText = params.searchText;
        }
        if (params.isSearching !== undefined) {
            this.isSearching = params.isSearching;
        }
        if (params.showSearchInput !== undefined) {
            this.showSearchInput = params.showSearchInput;
        }
        if (params.searchInputOpacity !== undefined) {
            this.searchInputOpacity = params.searchInputOpacity;
        }
        if (params.searchInputHeight !== undefined) {
            this.searchInputHeight = params.searchInputHeight;
        }
        if (params.isSearchResult !== undefined) {
            this.isSearchResult = params.isSearchResult;
        }
        if (params.userAvatarUrl !== undefined) {
            this.userAvatarUrl = params.userAvatarUrl;
        }
        if (params.username !== undefined) {
            this.username = params.username;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__images.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
        this.__searchText.purgeDependencyOnElmtId(rmElmtId);
        this.__isSearching.purgeDependencyOnElmtId(rmElmtId);
        this.__showSearchInput.purgeDependencyOnElmtId(rmElmtId);
        this.__searchInputOpacity.purgeDependencyOnElmtId(rmElmtId);
        this.__searchInputHeight.purgeDependencyOnElmtId(rmElmtId);
        this.__isSearchResult.purgeDependencyOnElmtId(rmElmtId);
        this.__userAvatarUrl.purgeDependencyOnElmtId(rmElmtId);
        this.__username.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__images.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        this.__searchText.aboutToBeDeleted();
        this.__isSearching.aboutToBeDeleted();
        this.__showSearchInput.aboutToBeDeleted();
        this.__searchInputOpacity.aboutToBeDeleted();
        this.__searchInputHeight.aboutToBeDeleted();
        this.__isSearchResult.aboutToBeDeleted();
        this.__userAvatarUrl.aboutToBeDeleted();
        this.__username.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __images: ObservedPropertyObjectPU<ImageItem[]>;
    get images() {
        return this.__images.get();
    }
    set images(newValue: ImageItem[]) {
        this.__images.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    private __searchText: ObservedPropertySimplePU<string>;
    get searchText() {
        return this.__searchText.get();
    }
    set searchText(newValue: string) {
        this.__searchText.set(newValue);
    }
    private __isSearching: ObservedPropertySimplePU<boolean>;
    get isSearching() {
        return this.__isSearching.get();
    }
    set isSearching(newValue: boolean) {
        this.__isSearching.set(newValue);
    }
    private __showSearchInput: ObservedPropertySimplePU<boolean>;
    get showSearchInput() {
        return this.__showSearchInput.get();
    }
    set showSearchInput(newValue: boolean) {
        this.__showSearchInput.set(newValue);
    }
    private __searchInputOpacity: ObservedPropertySimplePU<number>;
    get searchInputOpacity() {
        return this.__searchInputOpacity.get();
    }
    set searchInputOpacity(newValue: number) {
        this.__searchInputOpacity.set(newValue);
    }
    private __searchInputHeight: ObservedPropertySimplePU<number>;
    get searchInputHeight() {
        return this.__searchInputHeight.get();
    }
    set searchInputHeight(newValue: number) {
        this.__searchInputHeight.set(newValue);
    }
    private __isSearchResult: ObservedPropertySimplePU<boolean>; // 标记当前显示的是否为搜索结果
    get isSearchResult() {
        return this.__isSearchResult.get();
    }
    set isSearchResult(newValue: boolean) {
        this.__isSearchResult.set(newValue);
    }
    private __userAvatarUrl: ObservedPropertySimplePU<string>; // 用户头像URL
    get userAvatarUrl() {
        return this.__userAvatarUrl.get();
    }
    set userAvatarUrl(newValue: string) {
        this.__userAvatarUrl.set(newValue);
    }
    private __username: ObservedPropertySimplePU<string>; // 用户名
    get username() {
        return this.__username.get();
    }
    set username(newValue: string) {
        this.__username.set(newValue);
    }
    /**
     * 去掉文件后缀，只显示图片名称
     */
    private getDisplayImageName(imageName: string): string {
        if (!imageName)
            return '';
        // 找到最后一个点的位置
        const lastDotIndex = imageName.lastIndexOf('.');
        if (lastDotIndex === -1) {
            // 没有后缀，直接返回
            return imageName;
        }
        // 返回点之前的部分
        return imageName.substring(0, lastDotIndex);
    }
    aboutToAppear() {
        this.loadImages();
        this.loadUserBasicInfo();
        // 监听用户状态变化
        UserState.addListener((userInfo) => {
            if (userInfo && userInfo.headshotUrl) {
                this.userAvatarUrl = userInfo.headshotUrl;
                console.log('首页用户头像URL更新:', this.userAvatarUrl);
            }
            if (userInfo && userInfo.username) {
                this.username = userInfo.username;
                console.log('首页用户名更新:', this.username);
            }
        });
        // 初始化时获取用户信息
        const userInfo = UserState.getUserInfo();
        if (userInfo && userInfo.headshotUrl) {
            this.userAvatarUrl = userInfo.headshotUrl;
        }
        if (userInfo && userInfo.username) {
            this.username = userInfo.username;
        }
    }
    onPageShow() {
        // 页面显示时重新加载数据，确保从详情页返回时数据是最新的
        console.log('Index onPageShow - 重新加载图片数据');
        this.loadImages();
        this.loadUserBasicInfo();
    }
    /**
     * 加载用户基本信息
     */
    async loadUserBasicInfo() {
        try {
            // 先检查是否有token
            const token = await HttpService.getToken();
            console.log('首页检查用户登录状态，token:', token ? '存在' : '不存在');
            if (!token) {
                console.log('用户未登录，不获取用户基本信息');
                return;
            }
            console.log('开始获取用户基本信息');
            const response = await ApiService.getUserBasicInformation();
            console.log('获取用户基本信息响应:', JSON.stringify(response, null, 2));
            if (response.code === 1 && response.data) {
                console.log('用户基本信息获取成功:', response.data);
                // 更新用户名
                if (response.data.username) {
                    this.username = response.data.username;
                }
                // 更新头像URL
                if (response.data.headshotUrl) {
                    // 构建完整的头像URL
                    const baseUrl = HttpService.getBaseUrl();
                    this.userAvatarUrl = `${baseUrl}/images/${response.data.headshotUrl}`;
                    console.log('首页用户头像URL:', this.userAvatarUrl);
                    // 更新全局用户状态
                    const userInfo = UserState.getUserInfo();
                    if (userInfo) {
                        userInfo.headshotUrl = this.userAvatarUrl;
                        userInfo.username = response.data.username;
                        UserState.setUserInfo(userInfo);
                    }
                }
            }
            else {
                console.error('获取用户基本信息失败，响应码:', response.code, '消息:', response.msg);
            }
        }
        catch (error) {
            console.error('获取用户基本信息失败:', error);
        }
    }
    /**
     * 加载图片数据
     */
    async loadImages() {
        this.isLoading = true;
        this.isSearchResult = false; // 重置搜索状态
        try {
            console.log('开始加载图片数据...');
            const response = await ApiService.getRandomImages(8);
            console.log('API响应:', JSON.stringify(response, null, 2));
            if (response.code === 1) {
                this.images = response.data || [];
                console.log('图片加载成功，数量:', this.images.length);
                console.log('映射后的图片数据:', this.images);
            }
            else {
                console.error('API返回错误，code:', response.code, 'msg:', response.msg);
                this.images = [];
            }
        }
        catch (error) {
            console.error('加载图片失败:', error);
            this.images = [];
        }
        finally {
            this.isLoading = false;
        }
    }
    /**
     * 刷新图片
     */
    async refreshImages() {
        this.isRefreshing = true;
        await this.loadImages();
        this.isRefreshing = false;
    }
    /**
     * 切换搜索输入框显示状态
     */
    toggleSearchInput() {
        if (!this.showSearchInput) {
            // 显示搜索框
            this.showSearchInput = true;
            Context.animateTo({
                duration: 300,
                curve: Curve.EaseInOut
            }, () => {
                this.searchInputOpacity = 1;
                this.searchInputHeight = 56;
            });
        }
        else {
            // 隐藏搜索框
            Context.animateTo({
                duration: 300,
                curve: Curve.EaseInOut
            }, () => {
                this.searchInputOpacity = 0;
                this.searchInputHeight = 0;
            });
            // 延迟执行状态重置
            setTimeout(() => {
                this.showSearchInput = false;
                this.searchText = '';
                this.loadImages();
            }, 300);
        }
    }
    /**
     * 执行搜索
     */
    async performSearch() {
        if (!this.searchText.trim()) {
            promptAction.showToast({ message: '请输入搜索关键词' });
            return;
        }
        this.isSearching = true;
        this.isSearchResult = true; // 标记为搜索结果
        try {
            console.log('开始搜索图片，关键词:', this.searchText);
            const response = await ApiService.searchImages(this.searchText);
            console.log('搜索响应:', JSON.stringify(response, null, 2));
            if (response.code === 1) {
                this.images = response.data || [];
                console.log('搜索成功，找到图片数量:', this.images.length);
                if (this.images.length === 0) {
                    promptAction.showToast({ message: '未找到相关图片' });
                }
            }
            else {
                console.error('搜索失败，响应码:', response.code, '错误信息:', response.msg);
                promptAction.showToast({ message: '搜索失败，请重试' });
                this.images = [];
            }
        }
        catch (error) {
            console.error('搜索异常:', error);
            promptAction.showToast({ message: '搜索失败，请检查网络连接' });
            this.images = [];
        }
        finally {
            this.isSearching = false;
        }
    }
    /**
     * 清空搜索
     */
    clearSearch() {
        this.searchText = '';
        // 使用动画隐藏搜索框
        Context.animateTo({
            duration: 300,
            curve: Curve.EaseInOut
        }, () => {
            this.searchInputOpacity = 0;
            this.searchInputHeight = 0;
        });
        // 延迟执行状态重置
        setTimeout(() => {
            this.showSearchInput = false;
            this.loadImages();
        }, 300);
    }
    /**
     * 点赞/取消点赞
     */
    async toggleLike(image: ImageItem) {
        try {
            const response = await ApiService.toggleLike(image.imageId);
            if (response.code === 1) {
                // 更新本地状态
                const index = this.images.findIndex((img: ImageItem) => img.imageId === image.imageId);
                if (index !== -1) {
                    this.images[index].isLiked = !this.images[index].isLiked;
                    this.images[index].likeCount = (this.images[index].likeCount || 0) + (this.images[index].isLiked ? 1 : -1);
                }
            }
        }
        catch (error) {
            console.error('点赞失败:', error);
        }
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Index.ets(271:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 顶部导航栏
            // Row() {
            //   Text('拾光映画')
            //     .fontSize(20)
            //     .fontWeight(FontWeight.Bold)
            //     .fontColor(Color.Black)
            //
            //   Blank()
            //
            //   // 搜索按钮
            //   Image($r('app.media.sousuo'))
            //     .width(24)
            //     .height(24)
            //     .onClick(() => this.toggleSearchInput())
            // }
            // .width('100%')
            // .height(56)
            // .padding({ left: 20, right: 20 })
            // .backgroundColor(Color.Transparent)
            // 搜索输入框
            if (this.showSearchInput) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/Index.ets(294:9)", "entry");
                        Row.width('100%');
                        Row.height(this.searchInputHeight);
                        Row.opacity(this.searchInputOpacity);
                        Row.padding({ left: 16, right: 16, bottom: 8 });
                        Row.margin({ top: 15 });
                        Row.transition(TransitionEffect.OPACITY.animation({ duration: 300, curve: Curve.EaseInOut }));
                        Row.transition(TransitionEffect.scale({}));
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '搜索图片...' });
                        TextInput.debugLine("entry/src/main/ets/pages/Index.ets(295:11)", "entry");
                        TextInput.layoutWeight(1);
                        TextInput.height(40);
                        TextInput.backgroundColor(Color.White);
                        TextInput.borderRadius(20);
                        TextInput.fontSize(14);
                        TextInput.fontColor(Color.Black);
                        TextInput.placeholderColor(Colors.Black40);
                        TextInput.onChange((value: string) => {
                            this.searchText = value;
                        });
                        TextInput.onSubmit(() => {
                            this.performSearch();
                        });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('搜索');
                        Button.debugLine("entry/src/main/ets/pages/Index.ets(310:11)", "entry");
                        Button.width(60);
                        Button.height(40);
                        Button.backgroundColor('#4CAF50');
                        Button.fontColor(Color.White);
                        Button.borderRadius(20);
                        Button.fontSize(14);
                        Button.enabled(!this.isSearching);
                        Button.onClick(() => this.performSearch());
                    }, Button);
                    Button.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('取消');
                        Button.debugLine("entry/src/main/ets/pages/Index.ets(320:11)", "entry");
                        Button.width(60);
                        Button.height(40);
                        Button.backgroundColor('#F5F5F5');
                        Button.fontColor(Color.Black);
                        Button.borderRadius(20);
                        Button.fontSize(14);
                        Button.onClick(() => this.clearSearch());
                    }, Button);
                    Button.pop();
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 顶部导航栏
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/Index.ets(338:9)", "entry");
                        // 顶部导航栏
                        Row.width('100%');
                        // 顶部导航栏
                        Row.height(56);
                        // 顶部导航栏
                        Row.padding({ left: 16, right: 16 });
                        // 顶部导航栏
                        Row.backgroundColor(Color.Transparent);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户头像和用户名
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/Index.ets(340:11)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 用户头像
                        if (this.userAvatarUrl) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Image.create(this.userAvatarUrl);
                                    Image.debugLine("entry/src/main/ets/pages/Index.ets(343:15)", "entry");
                                    Image.width(32);
                                    Image.height(32);
                                    Image.borderRadius(16);
                                    Image.objectFit(ImageFit.Cover);
                                }, Image);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Image.create({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
                                    Image.debugLine("entry/src/main/ets/pages/Index.ets(349:15)", "entry");
                                    Image.width(32);
                                    Image.height(32);
                                    Image.borderRadius(16);
                                    Image.objectFit(ImageFit.Cover);
                                }, Image);
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户名
                        Text.create(this.username || '拾光映画');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(357:13)", "entry");
                        // 用户名
                        Text.fontSize(18);
                        // 用户名
                        Text.fontWeight(FontWeight.Medium);
                        // 用户名
                        Text.fontColor(Color.Black);
                    }, Text);
                    // 用户名
                    Text.pop();
                    // 用户头像和用户名
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/Index.ets(363:11)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 搜索按钮
                        Image.create({ "id": 16777248, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/Index.ets(366:11)", "entry");
                        // 搜索按钮
                        Image.width(24);
                        // 搜索按钮
                        Image.height(24);
                        // 搜索按钮
                        Image.onClick(() => this.toggleSearchInput());
                    }, Image);
                    // 顶部导航栏
                    Row.pop();
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 图片网格
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 加载中状态
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(382:9)", "entry");
                        // 加载中状态
                        Column.justifyContent(FlexAlign.Center);
                        // 加载中状态
                        Column.width('100%');
                        // 加载中状态
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/Index.ets(383:11)", "entry");
                        LoadingProgress.width(50);
                        LoadingProgress.height(50);
                        LoadingProgress.color('#4CAF50');
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('加载中...');
                        Text.debugLine("entry/src/main/ets/pages/Index.ets(388:11)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Color.Black);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    // 加载中状态
                    Column.pop();
                });
            }
            else if (this.images.length === 0) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 无图片状态 - 区分搜索结果和未登录状态
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/Index.ets(398:9)", "entry");
                        // 无图片状态 - 区分搜索结果和未登录状态
                        Column.justifyContent(FlexAlign.Center);
                        // 无图片状态 - 区分搜索结果和未登录状态
                        Column.width('100%');
                        // 无图片状态 - 区分搜索结果和未登录状态
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.isSearchResult) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 搜索结果为空
                                    Image.create({ "id": 16777247, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
                                    Image.debugLine("entry/src/main/ets/pages/Index.ets(401:13)", "entry");
                                    // 搜索结果为空
                                    Image.width(80);
                                    // 搜索结果为空
                                    Image.height(80);
                                    // 搜索结果为空
                                    Image.margin({ bottom: 16 });
                                }, Image);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(`没有找到与"${this.searchText}"相关的图片`);
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(406:13)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Colors.Black60);
                                    Text.margin({ bottom: 24 });
                                    Text.textAlign(TextAlign.Center);
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 未登录状态
                                    Image.create({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
                                    Image.debugLine("entry/src/main/ets/pages/Index.ets(413:13)", "entry");
                                    // 未登录状态
                                    Image.width(80);
                                    // 未登录状态
                                    Image.height(80);
                                    // 未登录状态
                                    Image.margin({ bottom: 16 });
                                }, Image);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('请登录浏览作品');
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(418:13)", "entry");
                                    Text.fontSize(18);
                                    Text.fontColor(Color.Black);
                                    Text.margin({ bottom: 8 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('登录后即可查看精彩内容');
                                    Text.debugLine("entry/src/main/ets/pages/Index.ets(423:13)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Colors.Black60);
                                    Text.margin({ bottom: 24 });
                                }, Text);
                                Text.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Button.createWithLabel('立即登录');
                                    Button.debugLine("entry/src/main/ets/pages/Index.ets(428:13)", "entry");
                                    Button.width(120);
                                    Button.height(40);
                                    Button.backgroundColor('#4CAF50');
                                    Button.fontColor(Color.White);
                                    Button.borderRadius(20);
                                    Button.onClick(() => {
                                        router.pushUrl({ url: 'pages/LoginPage' });
                                    });
                                }, Button);
                                Button.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    // 无图片状态 - 区分搜索结果和未登录状态
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 图片列表
                        Refresh.create({ refreshing: this.isRefreshing });
                        Refresh.debugLine("entry/src/main/ets/pages/Index.ets(444:9)", "entry");
                        // 图片列表
                        Refresh.onRefreshing(() => {
                            this.refreshImages();
                        });
                        // 图片列表
                        Refresh.layoutWeight(1);
                    }, Refresh);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Grid.create();
                        Grid.debugLine("entry/src/main/ets/pages/Index.ets(445:11)", "entry");
                        Grid.columnsTemplate('1fr 1fr');
                        Grid.rowsGap(12);
                        Grid.columnsGap(12);
                        Grid.padding({ top: 3, left: 16, right: 16, bottom: 16 });
                        Grid.onScrollIndex(() => {
                            // 可以在这里实现分页加载
                        });
                    }, Grid);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        ForEach.create();
                        const forEachItemGenFunction = (_item, index: number) => {
                            const image = _item;
                            {
                                const itemCreation2 = (elmtId, isInitialRender) => {
                                    GridItem.create(() => { }, false);
                                    GridItem.debugLine("entry/src/main/ets/pages/Index.ets(447:15)", "entry");
                                };
                                const observedDeepRender = () => {
                                    this.observeComponentCreation2(itemCreation2, GridItem);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Column.create();
                                        Column.debugLine("entry/src/main/ets/pages/Index.ets(448:17)", "entry");
                                        Column.width('100%');
                                        Column.backgroundColor(Colors.White10);
                                        Column.borderRadius(12);
                                        Column.padding(8);
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 图片
                                        Image.create(image.imageUrl);
                                        Image.debugLine("entry/src/main/ets/pages/Index.ets(450:19)", "entry");
                                        // 图片
                                        Image.width('100%');
                                        // 图片
                                        Image.height(200);
                                        // 图片
                                        Image.borderRadius(12);
                                        // 图片
                                        Image.objectFit(ImageFit.Cover);
                                        // 图片
                                        Image.onClick(async () => {
                                            // 跳转到图片详情页面，传递完整的图片数据
                                            console.log('点击图片，准备跳转到详情页面，图片ID:', image.imageId);
                                            try {
                                                // 调用获取图片信息接口，记录浏览记录
                                                console.log('调用获取图片信息接口，记录浏览记录...');
                                                const infoResponse = await ApiService.getImageInformation(image.imageId);
                                                console.log('获取图片信息响应:', JSON.stringify(infoResponse, null, 2));
                                                if (infoResponse.code === 1 && infoResponse.data) {
                                                    console.log('浏览记录已记录，图片信息:', infoResponse.data);
                                                    // 使用从接口获取的最新图片信息
                                                    router.pushUrl({
                                                        url: 'pages/ImageDetailPage',
                                                        params: {
                                                            imageId: image.imageId,
                                                            imageData: JSON.stringify(infoResponse.data) // 使用最新的图片数据
                                                        }
                                                    }).then(() => {
                                                        console.log('跳转成功');
                                                    }).catch((error: Error) => {
                                                        console.error('跳转失败:', error);
                                                    });
                                                }
                                                else {
                                                    console.warn('获取图片信息失败，使用原有数据跳转');
                                                    // 如果接口失败，使用原有数据跳转
                                                    router.pushUrl({
                                                        url: 'pages/ImageDetailPage',
                                                        params: {
                                                            imageId: image.imageId,
                                                            imageData: JSON.stringify(image) // 使用原有图片数据
                                                        }
                                                    }).then(() => {
                                                        console.log('跳转成功');
                                                    }).catch((error: Error) => {
                                                        console.error('跳转失败:', error);
                                                    });
                                                }
                                            }
                                            catch (error) {
                                                console.error('调用获取图片信息接口失败:', error);
                                                // 如果接口调用失败，仍然跳转到详情页面
                                                router.pushUrl({
                                                    url: 'pages/ImageDetailPage',
                                                    params: {
                                                        imageId: image.imageId,
                                                        imageData: JSON.stringify(image) // 使用原有图片数据
                                                    }
                                                }).then(() => {
                                                    console.log('跳转成功');
                                                }).catch((error: Error) => {
                                                    console.error('跳转失败:', error);
                                                });
                                            }
                                        });
                                    }, Image);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // 图片信息
                                        Column.create({ space: 8 });
                                        Column.debugLine("entry/src/main/ets/pages/Index.ets(512:19)", "entry");
                                        // 图片信息
                                        Column.width('100%');
                                        // 图片信息
                                        Column.padding({ top: 8, left: 8, right: 8, bottom: 5 });
                                    }, Column);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(this.getDisplayImageName(image.imageName));
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(513:21)", "entry");
                                        Text.fontSize(14);
                                        Text.fontWeight(FontWeight.Medium);
                                        Text.fontColor(Color.Black);
                                        Text.maxLines(1);
                                        Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create();
                                        Row.debugLine("entry/src/main/ets/pages/Index.ets(520:21)", "entry");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(image.username || '匿名用户');
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(521:23)", "entry");
                                        Text.fontSize(12);
                                        Text.fontColor(Colors.Black60);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Blank.create();
                                        Blank.debugLine("entry/src/main/ets/pages/Index.ets(525:23)", "entry");
                                    }, Blank);
                                    Blank.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Row.create({ space: 4 });
                                        Row.debugLine("entry/src/main/ets/pages/Index.ets(527:23)", "entry");
                                    }, Row);
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        Text.create(image.isLike ? '❤️' : '🤍');
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(528:25)", "entry");
                                        Text.fontSize(16);
                                    }, Text);
                                    Text.pop();
                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                        // .onClick(() => this.toggleLike(image))
                                        Text.create((image.imageLike || 0).toString());
                                        Text.debugLine("entry/src/main/ets/pages/Index.ets(532:25)", "entry");
                                        // .onClick(() => this.toggleLike(image))
                                        Text.fontSize(12);
                                        // .onClick(() => this.toggleLike(image))
                                        Text.fontColor(Colors.Black60);
                                    }, Text);
                                    // .onClick(() => this.toggleLike(image))
                                    Text.pop();
                                    Row.pop();
                                    Row.pop();
                                    // 图片信息
                                    Column.pop();
                                    Column.pop();
                                    GridItem.pop();
                                };
                                observedDeepRender();
                            }
                        };
                        this.forEachUpdateFunction(elmtId, this.images, forEachItemGenFunction, undefined, true, false);
                    }, ForEach);
                    ForEach.pop();
                    Grid.pop();
                    // 图片列表
                    Refresh.pop();
                });
            }
        }, If);
        If.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // 底部导航栏
                    BottomNavBar(this, { currentPage: 'home' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Index.ets", line: 563, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            currentPage: 'home'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        currentPage: 'home'
                    });
                }
            }, { name: "BottomNavBar" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/Index", pageFullPath: "entry/src/main/ets/pages/Index", integratedHsp: "false", moduleType: "followWithHap" });
