if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ImageDetailPage_Params {
    imageDetail?: ImageItem | null;
    comments?: Comment[];
    isLoading?: boolean;
    isLiking?: boolean;
    isCommenting?: boolean;
    newComment?: string;
    imageId?: number;
    showCommentInput?: boolean;
    isBookmarking?: boolean;
    currentUserId?: number;
    isImageOwner?: boolean;
    deletedCommentIds?: Set<number>;
    displayImageUri?: string;
    showActions?: boolean;
    isOwner?: boolean;
    img?: PixelMap | null;
    userAvatarUrl?: string;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import fs from "@ohos:file.fs";
import image from "@ohos:multimedia.image";
import http from "@ohos:net.http";
import fileIo from "@ohos:file.fs";
import abilityAccessCtrl from "@ohos:abilityAccessCtrl";
import type common from "@ohos:app.ability.common";
import fileUri from "@ohos:file.fileuri";
import photoAccessHelper from "@ohos:file.photoAccessHelper";
import unifiedDataChannel from "@ohos:data.unifiedDataChannel";
import pasteboard from "@ohos:pasteboard";
import type { ImageItem } from '../models/Image';
import type { Comment } from '../models/Comment';
import type { UserInfo } from '../models/User';
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
import { UserState } from "@normalized:N&&&entry/src/main/ets/services/UserState&";
import { HttpService } from "@normalized:N&&&entry/src/main/ets/services/HttpService&";
// 定义点赞数据接口
interface LikeData {
    isLiked: boolean;
    likeCount: number;
    timestamp: number;
}
// 定义点赞状态返回接口
interface LikeStatus {
    isLiked: boolean;
    likeCount: number;
}
// 定义收藏数据接口
interface BookmarkData {
    isBookmarked: boolean;
    bookmarkCount: number;
    timestamp: number;
}
// 定义收藏状态返回接口
interface BookmarkStatus {
    isBookmarked: boolean;
    bookmarkCount: number;
}
// 获取图片基础信息接口的关键字段（关心点赞、收藏状态）
interface ImageInformationDTO {
    imageLike?: number;
    likeCount?: number;
    isLike?: number; // 后端返回：1=已点赞，0=未点赞
    isBookmark?: number; // 后端返回：1=已收藏，0=未收藏
    imageBookmark?: number; // 后端返回：收藏数量
}
class ImageDetailPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__imageDetail = new ObservedPropertyObjectPU(null, this, "imageDetail");
        this.__comments = new ObservedPropertyObjectPU([], this, "comments");
        this.__isLoading = new ObservedPropertySimplePU(true, this, "isLoading");
        this.__isLiking = new ObservedPropertySimplePU(false, this, "isLiking");
        this.__isCommenting = new ObservedPropertySimplePU(false, this, "isCommenting");
        this.__newComment = new ObservedPropertySimplePU('', this, "newComment");
        this.__imageId = new ObservedPropertySimplePU(0, this, "imageId");
        this.__showCommentInput = new ObservedPropertySimplePU(false, this, "showCommentInput");
        this.__isBookmarking = new ObservedPropertySimplePU(false, this, "isBookmarking");
        this.__currentUserId = new ObservedPropertySimplePU(0, this, "currentUserId");
        this.__isImageOwner = new ObservedPropertySimplePU(false, this, "isImageOwner");
        this.__deletedCommentIds = new ObservedPropertyObjectPU(new Set(), this, "deletedCommentIds");
        this.__displayImageUri = new ObservedPropertySimplePU('', this, "displayImageUri");
        this.__showActions = new ObservedPropertySimplePU(false, this, "showActions");
        this.__isOwner = new ObservedPropertySimplePU(false, this, "isOwner");
        this.__img = new ObservedPropertyObjectPU(null, this, "img");
        this.__userAvatarUrl = new ObservedPropertySimplePU('', this, "userAvatarUrl");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ImageDetailPage_Params) {
        if (params.imageDetail !== undefined) {
            this.imageDetail = params.imageDetail;
        }
        if (params.comments !== undefined) {
            this.comments = params.comments;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isLiking !== undefined) {
            this.isLiking = params.isLiking;
        }
        if (params.isCommenting !== undefined) {
            this.isCommenting = params.isCommenting;
        }
        if (params.newComment !== undefined) {
            this.newComment = params.newComment;
        }
        if (params.imageId !== undefined) {
            this.imageId = params.imageId;
        }
        if (params.showCommentInput !== undefined) {
            this.showCommentInput = params.showCommentInput;
        }
        if (params.isBookmarking !== undefined) {
            this.isBookmarking = params.isBookmarking;
        }
        if (params.currentUserId !== undefined) {
            this.currentUserId = params.currentUserId;
        }
        if (params.isImageOwner !== undefined) {
            this.isImageOwner = params.isImageOwner;
        }
        if (params.deletedCommentIds !== undefined) {
            this.deletedCommentIds = params.deletedCommentIds;
        }
        if (params.displayImageUri !== undefined) {
            this.displayImageUri = params.displayImageUri;
        }
        if (params.showActions !== undefined) {
            this.showActions = params.showActions;
        }
        if (params.isOwner !== undefined) {
            this.isOwner = params.isOwner;
        }
        if (params.img !== undefined) {
            this.img = params.img;
        }
        if (params.userAvatarUrl !== undefined) {
            this.userAvatarUrl = params.userAvatarUrl;
        }
    }
    updateStateVars(params: ImageDetailPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__imageDetail.purgeDependencyOnElmtId(rmElmtId);
        this.__comments.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isLiking.purgeDependencyOnElmtId(rmElmtId);
        this.__isCommenting.purgeDependencyOnElmtId(rmElmtId);
        this.__newComment.purgeDependencyOnElmtId(rmElmtId);
        this.__imageId.purgeDependencyOnElmtId(rmElmtId);
        this.__showCommentInput.purgeDependencyOnElmtId(rmElmtId);
        this.__isBookmarking.purgeDependencyOnElmtId(rmElmtId);
        this.__currentUserId.purgeDependencyOnElmtId(rmElmtId);
        this.__isImageOwner.purgeDependencyOnElmtId(rmElmtId);
        this.__deletedCommentIds.purgeDependencyOnElmtId(rmElmtId);
        this.__displayImageUri.purgeDependencyOnElmtId(rmElmtId);
        this.__showActions.purgeDependencyOnElmtId(rmElmtId);
        this.__isOwner.purgeDependencyOnElmtId(rmElmtId);
        this.__img.purgeDependencyOnElmtId(rmElmtId);
        this.__userAvatarUrl.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__imageDetail.aboutToBeDeleted();
        this.__comments.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isLiking.aboutToBeDeleted();
        this.__isCommenting.aboutToBeDeleted();
        this.__newComment.aboutToBeDeleted();
        this.__imageId.aboutToBeDeleted();
        this.__showCommentInput.aboutToBeDeleted();
        this.__isBookmarking.aboutToBeDeleted();
        this.__currentUserId.aboutToBeDeleted();
        this.__isImageOwner.aboutToBeDeleted();
        this.__deletedCommentIds.aboutToBeDeleted();
        this.__displayImageUri.aboutToBeDeleted();
        this.__showActions.aboutToBeDeleted();
        this.__isOwner.aboutToBeDeleted();
        this.__img.aboutToBeDeleted();
        this.__userAvatarUrl.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __imageDetail: ObservedPropertyObjectPU<ImageItem | null>;
    get imageDetail() {
        return this.__imageDetail.get();
    }
    set imageDetail(newValue: ImageItem | null) {
        this.__imageDetail.set(newValue);
    }
    private __comments: ObservedPropertyObjectPU<Comment[]>;
    get comments() {
        return this.__comments.get();
    }
    set comments(newValue: Comment[]) {
        this.__comments.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isLiking: ObservedPropertySimplePU<boolean>;
    get isLiking() {
        return this.__isLiking.get();
    }
    set isLiking(newValue: boolean) {
        this.__isLiking.set(newValue);
    }
    private __isCommenting: ObservedPropertySimplePU<boolean>;
    get isCommenting() {
        return this.__isCommenting.get();
    }
    set isCommenting(newValue: boolean) {
        this.__isCommenting.set(newValue);
    }
    private __newComment: ObservedPropertySimplePU<string>;
    get newComment() {
        return this.__newComment.get();
    }
    set newComment(newValue: string) {
        this.__newComment.set(newValue);
    }
    private __imageId: ObservedPropertySimplePU<number>;
    get imageId() {
        return this.__imageId.get();
    }
    set imageId(newValue: number) {
        this.__imageId.set(newValue);
    }
    private __showCommentInput: ObservedPropertySimplePU<boolean>; // 控制评论输入框显示
    get showCommentInput() {
        return this.__showCommentInput.get();
    }
    set showCommentInput(newValue: boolean) {
        this.__showCommentInput.set(newValue);
    }
    private __isBookmarking: ObservedPropertySimplePU<boolean>; // 控制收藏操作状态
    get isBookmarking() {
        return this.__isBookmarking.get();
    }
    set isBookmarking(newValue: boolean) {
        this.__isBookmarking.set(newValue);
    }
    private __currentUserId: ObservedPropertySimplePU<number>; // 当前用户ID
    get currentUserId() {
        return this.__currentUserId.get();
    }
    set currentUserId(newValue: number) {
        this.__currentUserId.set(newValue);
    }
    private __isImageOwner: ObservedPropertySimplePU<boolean>; // 是否为图片作者
    get isImageOwner() {
        return this.__isImageOwner.get();
    }
    set isImageOwner(newValue: boolean) {
        this.__isImageOwner.set(newValue);
    }
    private __deletedCommentIds: ObservedPropertyObjectPU<Set<number>>; // 已删除的评论ID集合
    get deletedCommentIds() {
        return this.__deletedCommentIds.get();
    }
    set deletedCommentIds(newValue: Set<number>) {
        this.__deletedCommentIds.set(newValue);
    }
    private __displayImageUri: ObservedPropertySimplePU<string>;
    get displayImageUri() {
        return this.__displayImageUri.get();
    }
    set displayImageUri(newValue: string) {
        this.__displayImageUri.set(newValue);
    }
    private __showActions: ObservedPropertySimplePU<boolean>; // 右上角更多菜单
    get showActions() {
        return this.__showActions.get();
    }
    set showActions(newValue: boolean) {
        this.__showActions.set(newValue);
    }
    private __isOwner: ObservedPropertySimplePU<boolean>; // 是否为本人发布
    get isOwner() {
        return this.__isOwner.get();
    }
    set isOwner(newValue: boolean) {
        this.__isOwner.set(newValue);
    }
    private __img: ObservedPropertyObjectPU<PixelMap | null>; // 用于保存的图片数据
    get img() {
        return this.__img.get();
    }
    set img(newValue: PixelMap | null) {
        this.__img.set(newValue);
    }
    private __userAvatarUrl: ObservedPropertySimplePU<string>; // 用户头像URL
    get userAvatarUrl() {
        return this.__userAvatarUrl.get();
    }
    set userAvatarUrl(newValue: string) {
        this.__userAvatarUrl.set(newValue);
    }
    /**
     * 去掉文件后缀，只显示图片名称
     */
    private getDisplayImageName(imageName: string): string {
        if (!imageName)
            return '';
        // 找到最后一个点的位置
        const lastDotIndex = imageName.lastIndexOf('.');
        if (lastDotIndex === -1) {
            // 没有后缀，直接返回
            return imageName;
        }
        // 返回点之前的部分
        return imageName.substring(0, lastDotIndex);
    }
    /**
     * 获取显示的用户名
     */
    private getDisplayUsername(): string {
        if (!this.imageDetail)
            return '匿名用户';
        // 如果都没有，根据是否为本人发布显示不同信息
        if (this.isOwner) {
            return '我';
        }
        // 直接使用 username 字段，就像主页一样
        return this.imageDetail.username || '匿名用户';
    }
    /**
     * 保存图片到相册 - 使用沙箱环境方法
     */
    async saveScreenshot(pixelMap: image.PixelMap, filename: string) {
        const docExt: string = 'jpg';
        let targetPath: string = '';
        try {
            let imagePackerApi = image.createImagePacker();
            let packOpts: image.PackingOption = { format: "image/jpeg", quality: 90 };
            // 保存文件到沙箱环境
            const imgBuffer: ArrayBuffer = await imagePackerApi.packing(pixelMap, packOpts);
            targetPath = (getContext(this) as common.UIAbilityContext).filesDir + "/" + filename + '.' + docExt;
            let file = await fileIo.open(targetPath, fileIo.OpenMode.CREATE | fileIo.OpenMode.READ_WRITE);
            await fileIo.write(file.fd, imgBuffer);
            await fileIo.close(file.fd);
            // 先缓存增加预览图
            let dirpath = (getContext(this) as common.UIAbilityContext).tempDir + '/temp_' + filename + '.jpg';
            let dirUri = fileUri.getUriFromPath(dirpath);
            let finalFile = fs.openSync(targetPath, fs.OpenMode.READ_ONLY);
            let dirFile = fs.openSync(dirpath, fs.OpenMode.READ_WRITE | fs.OpenMode.CREATE);
            fs.copyFileSync(finalFile.fd, dirFile.fd);
            fs.closeSync(finalFile);
            fs.closeSync(dirFile);
            // 保存到相册
            let srcFileUris: Array<string> = [dirUri];
            let photoCreationConfigs: Array<photoAccessHelper.PhotoCreationConfig> = [
                {
                    fileNameExtension: 'jpg',
                    photoType: photoAccessHelper.PhotoType.IMAGE,
                }
            ];
            let desFileUris: Array<string> = await photoAccessHelper.getPhotoAccessHelper(getContext(this))
                .showAssetsCreationDialog(srcFileUris, photoCreationConfigs);
            let desFile: fileIo.File = await fileIo.open(desFileUris[0], fileIo.OpenMode.WRITE_ONLY);
            let srcFile: fileIo.File = await fileIo.open(dirUri, fileIo.OpenMode.READ_ONLY);
            await fileIo.copyFile(srcFile.fd, desFile.fd);
            fileIo.closeSync(srcFile);
            fileIo.closeSync(desFile);
            promptAction.showToast({
                message: '图片已保存到相册！',
                duration: 3000
            });
        }
        catch (error) {
            // 发生异常要移除沙箱文件
            if (fs.accessSync(targetPath)) {
                fs.unlinkSync(targetPath);
            }
            console.error('保存图片失败:', error);
            promptAction.showToast({
                message: '保存失败: ' + String(error),
                duration: 3000
            });
        }
    }
    /**
     * 检查相册权限
     */
    async checkPermission(): Promise<boolean> {
        const context = getContext(this) as common.UIAbilityContext;
        const atManager = abilityAccessCtrl.createAtManager();
        try {
            const grantStatus = await atManager.requestPermissionsFromUser(context, ['ohos.permission.WRITE_MEDIA', 'ohos.permission.WRITE_IMAGEVIDEO']);
            console.log('权限申请结果:', grantStatus);
            return grantStatus.authResults[0] === 0;
        }
        catch (err) {
            console.error(`权限申请失败: ${err}`);
            return false;
        }
    }
    /** 统一获取可显示/下载的图片URL，处理相对路径或仅文件名 */
    private getDisplayImageUrl(): string {
        const base = HttpService.getBaseUrl();
        const url = this.imageDetail ? this.imageDetail.imageUrl : '';
        if (!url)
            return '';
        // 1) 已经是完整URL
        if (url.startsWith('http')) {
            return url;
        }
        // 2) 可能是以/开头的相对路径
        if (url.includes('/') && (url.startsWith('/') || url.indexOf('/') > 0)) {
            return `${base}${url.startsWith('/') ? url : '/' + url}`;
        }
        // 3) 仅文件名（例如 123.png）→ 拼接静态资源路径 /images/<filename>
        return `${base}/images/${encodeURIComponent(url)}`;
    }
    // 使用全局存储评论数据、点赞状态和收藏状态（更持久）
    private static getGlobalStorage(): Record<string, string> {
        // 定义全局存储接口
        interface GlobalStorage {
            commentsStorage?: Record<string, string>;
            likesStorage?: Record<string, string>;
            bookmarksStorage?: Record<string, string>;
        }
        const globalStorage = globalThis as GlobalStorage;
        if (!globalStorage.commentsStorage) {
            globalStorage.commentsStorage = {};
        }
        if (!globalStorage.likesStorage) {
            globalStorage.likesStorage = {};
        }
        if (!globalStorage.bookmarksStorage) {
            globalStorage.bookmarksStorage = {};
        }
        return globalStorage.commentsStorage;
    }
    // 获取点赞存储
    private static getLikesStorage(): Record<string, string> {
        interface GlobalStorage {
            likesStorage?: Record<string, string>;
        }
        const globalStorage = globalThis as GlobalStorage;
        if (!globalStorage.likesStorage) {
            globalStorage.likesStorage = {};
        }
        return globalStorage.likesStorage;
    }
    // 获取收藏存储
    private static getBookmarksStorage(): Record<string, string> {
        interface GlobalStorage {
            bookmarksStorage?: Record<string, string>;
        }
        const globalStorage = globalThis as GlobalStorage;
        if (!globalStorage.bookmarksStorage) {
            globalStorage.bookmarksStorage = {};
        }
        return globalStorage.bookmarksStorage;
    }
    async aboutToAppear() {
        // 获取传递的参数
        console.log('ImageDetailPage aboutToAppear 被调用');
        interface RouterParams {
            imageId: number;
            imageData?: string; // 可选的图片数据
            isOwner?: boolean; // 是否为本人发布
        }
        const params = router.getParams() as RouterParams;
        console.log('接收到的参数:', params);
        console.log('参数类型:', typeof params);
        console.log('isOwner 原始值:', params?.isOwner);
        console.log('isOwner 类型:', typeof params?.isOwner);
        if (params && params.imageId) {
            this.imageId = params.imageId;
            this.isOwner = !!params.isOwner;
            console.log('开始加载图片详情，图片ID:', this.imageId);
            console.log('isOwner 参数值:', params.isOwner);
            console.log('this.isOwner 设置后:', this.isOwner);
            // 如果传递了完整的图片数据，直接使用
            if (params.imageData) {
                try {
                    this.imageDetail = JSON.parse(params.imageData);
                    console.log('使用传递的图片数据:', this.imageDetail);
                    // 收藏状态由后端接口控制，不再从本地存储恢复
                    // 先拉取基础信息（含 imageLike），记录浏览
                    this.refreshImageInformation();
                    this.isLoading = false;
                    // 检查是否为图片作者
                    this.checkImageOwnership();
                    // 预备可显示图片地址（本地或完整URL）
                    this.ensureDisplayImageUri();
                    // 仍然尝试加载评论（如果API存在的话）
                    this.loadComments();
                    this.loadComments();
                }
                catch (error) {
                    console.error('解析图片数据失败:', error);
                    this.loadImageDetail();
                }
            }
            else {
                // 如果没有传递图片数据，尝试从API加载
                this.loadImageDetail();
            }
            // 获取当前用户信息
            this.loadCurrentUserInfo();
            // 主动获取用户基本信息
            await this.loadUserBasicInfo();
            // 监听用户状态变化，更新头像
            UserState.addListener((userInfo) => {
                if (userInfo && userInfo.headshotUrl) {
                    this.userAvatarUrl = userInfo.headshotUrl;
                    console.log('图片详情页用户头像URL更新:', this.userAvatarUrl);
                }
            });
            // 初始化时获取用户头像URL
            const userInfo = UserState.getUserInfo();
            if (userInfo && userInfo.headshotUrl) {
                this.userAvatarUrl = userInfo.headshotUrl;
            }
            // 调试：显示当前存储状态
            const storage = ImageDetailPage.getGlobalStorage();
            const likesStorage = ImageDetailPage.getLikesStorage();
            const bookmarksStorage = ImageDetailPage.getBookmarksStorage();
            console.log('页面加载时的存储状态:', Object.keys(storage));
            console.log('页面加载时的点赞存储状态:', Object.keys(likesStorage));
            console.log('页面加载时的收藏存储状态:', Object.keys(bookmarksStorage));
            console.log('当前图片ID的存储key:', `comments_${this.imageId}`);
            console.log('当前图片ID的点赞key:', `like_${this.imageId}`);
            console.log('当前图片ID的收藏key:', `bookmark_${this.imageId}`);
            console.log('是否有当前图片的评论数据:', !!storage[`comments_${this.imageId}`]);
            console.log('是否有当前图片的点赞数据:', !!likesStorage[`like_${this.imageId}`]);
            console.log('是否有当前图片的收藏数据:', !!bookmarksStorage[`bookmark_${this.imageId}`]);
        }
        else {
            console.error('未接收到有效的图片ID参数');
        }
    }
    /**
     * 加载用户基本信息
     */
    async loadUserBasicInfo() {
        try {
            // 先检查是否有token
            const token = await HttpService.getToken();
            console.log('ImageDetailPage检查用户登录状态，token:', token ? '存在' : '不存在');
            if (!token) {
                console.log('用户未登录，不获取用户基本信息');
                return;
            }
            console.log('开始获取用户基本信息');
            const response = await ApiService.getUserBasicInformation();
            console.log('获取用户基本信息响应:', JSON.stringify(response, null, 2));
            if (response.code === 1 && response.data) {
                console.log('用户基本信息获取成功:', response.data);
                // 更新头像URL
                if (response.data.headshotUrl) {
                    // 构建完整的头像URL
                    const baseUrl = HttpService.getBaseUrl();
                    this.userAvatarUrl = `${baseUrl}/images/${response.data.headshotUrl}`;
                    console.log('ImageDetailPage用户头像URL:', this.userAvatarUrl);
                    // 更新全局用户状态
                    const userInfo = UserState.getUserInfo();
                    if (userInfo) {
                        userInfo.headshotUrl = this.userAvatarUrl;
                        userInfo.username = response.data.username;
                        UserState.setUserInfo(userInfo);
                    }
                }
            }
            else {
                console.error('获取用户基本信息失败，响应码:', response.code, '消息:', response.msg);
            }
        }
        catch (error) {
            console.error('获取用户基本信息失败:', error);
        }
    }
    /**
     * 获取当前用户信息
     */
    async loadCurrentUserInfo() {
        try {
            const HttpServiceModule = await import("@normalized:N&&&entry/src/main/ets/services/HttpService&");
            const HttpService = HttpServiceModule.HttpService;
            const token = await HttpService.getToken();
            console.log('=== 获取用户信息 ===');
            console.log('Token状态:', token ? '已获取' : '未获取');
            if (token) {
                // 尝试获取用户基本信息
                try {
                    const userInfoResponse = await ApiService.getUserBasicInformation();
                    console.log('用户基本信息API响应:', userInfoResponse);
                    if (userInfoResponse.code === 1 && userInfoResponse.data) {
                        // 从用户基本信息中获取用户名和头像
                        const username = userInfoResponse.data.username || '用户';
                        const headshotUrl = userInfoResponse.data.headshotUrl;
                        console.log('从API获取的用户名:', username);
                        console.log('从API获取的头像URL:', headshotUrl);
                        // 更新UserState中的用户信息
                        const currentUserInfo = UserState.getUserInfo();
                        if (currentUserInfo) {
                            currentUserInfo.username = username;
                            if (headshotUrl) {
                                const baseUrl = HttpService.getBaseUrl();
                                currentUserInfo.headshotUrl = `${baseUrl}/images/${headshotUrl}`;
                            }
                            UserState.setUserInfo(currentUserInfo);
                        }
                        else {
                            // 如果UserState中没有用户信息，创建一个新的
                            const newUserInfo: UserInfo = {
                                userId: 1,
                                username: username,
                                headshotUrl: headshotUrl ? `${HttpService.getBaseUrl()}/images/${headshotUrl}` : '',
                                userAccount: '',
                                telephoneNumber: ''
                            };
                            UserState.setUserInfo(newUserInfo);
                        }
                        console.log('获取的用户信息成功');
                    }
                    else {
                        console.log('API返回失败，使用默认用户ID');
                        this.currentUserId = 1; // 假设当前用户ID为1
                    }
                }
                catch (error) {
                    console.error('获取用户信息失败:', error);
                    // 如果获取用户信息失败，使用默认值
                    this.currentUserId = 1; // 假设当前用户ID为1
                    console.log('使用默认用户ID:', this.currentUserId);
                }
            }
            else {
                console.log('用户未登录，使用默认用户ID');
                this.currentUserId = 1; // 即使未登录也使用默认值进行测试
            }
            console.log('最终用户ID:', this.currentUserId);
        }
        catch (error) {
            console.error('加载当前用户信息失败:', error);
            this.currentUserId = 1; // 出错时也使用默认值
        }
    }
    /**
     * 检查是否为图片作者
     */
    checkImageOwnership() {
        if (this.imageDetail && this.currentUserId > 0) {
            // 假设图片对象中有userId字段表示图片作者ID
            const imageOwnerId = this.imageDetail.userId || 0;
            this.isImageOwner = this.currentUserId === imageOwnerId;
        }
        else {
            this.isImageOwner = false;
        }
    }
    /**
     * 加载图片详情
     */
    async loadImageDetail() {
        this.isLoading = true;
        try {
            console.log('开始加载图片详情，图片ID:', this.imageId);
            // 先加载已删除的评论ID
            await this.loadDeletedCommentIds();
            // 由于后端可能没有getImageDetail API，我们使用传递过来的图片数据
            if (this.imageDetail) {
                console.log('使用传递的图片数据:', this.imageDetail);
                // 预备可显示图片地址（本地或完整URL）
                this.ensureDisplayImageUri();
                // 点赞状态由后端接口控制，不再从本地存储恢复
                // 尝试从本地存储加载收藏状态
                const bookmarkStatus = await this.loadBookmarkStatusFromLocal(this.imageId);
                if (bookmarkStatus) {
                    console.log('从本地存储恢复收藏状态:', bookmarkStatus);
                    this.imageDetail.isBookmarked = bookmarkStatus.isBookmarked;
                    this.imageDetail.bookmarkCount = bookmarkStatus.bookmarkCount;
                }
                else {
                    console.log('没有找到本地收藏状态，使用默认值');
                    this.imageDetail.isBookmarked = false;
                    this.imageDetail.bookmarkCount = 0;
                }
                // 检查是否为图片作者
                this.checkImageOwnership();
                // 收藏状态由后端接口控制，不再从本地存储恢复
                // 向后端获取图片基础信息并合并（使用 imageLike 作为点赞数）
                await this.refreshImageInformation();
            }
            else {
                console.error('没有图片数据，无法显示详情');
                promptAction.showToast({ message: '图片数据缺失' });
                return;
            }
            // 加载评论
            await this.loadComments();
        }
        catch (error) {
            console.error('加载图片详情失败:', error);
            console.error('错误类型:', typeof error);
            console.error('错误详情:', JSON.stringify(error));
            promptAction.showToast({ message: '加载失败' });
        }
        finally {
            this.isLoading = false;
        }
    }
    /**
     * 从后端获取图片基础信息并记录浏览，将返回的 imageLike 映射到 likeCount，isLike 映射到 isLiked
     */
    private async refreshImageInformation() {
        try {
            console.log('调用 getImageInformation 接口，imageId:', this.imageId);
            const resp = await ApiService.getImageInformation(this.imageId);
            console.log('getImageInformation 响应:', resp);
            if (resp && resp.code === 1 && resp.data) {
                const data: ImageInformationDTO = resp.data as ImageInformationDTO;
                const likeFromServer = (data.imageLike !== undefined ? data.imageLike : data.likeCount);
                const serverLikeCount: number | undefined = typeof likeFromServer === 'number' ? likeFromServer : undefined;
                if (this.imageDetail) {
                    // 用后端的点赞总数覆盖本地点赞数量显示
                    if (serverLikeCount !== undefined && !Number.isNaN(serverLikeCount)) {
                        this.imageDetail.likeCount = serverLikeCount;
                    }
                    // 使用后端返回的 isLike 字段控制点赞状态：1=已点赞，0=未点赞
                    if (typeof data?.isLike === 'number') {
                        this.imageDetail.isLiked = data.isLike === 1;
                        console.log('从后端更新点赞状态，isLike:', data.isLike, 'isLiked:', this.imageDetail.isLiked);
                    }
                    // 使用后端返回的 isBookmark 字段控制收藏状态：1=已收藏，0=未收藏
                    if (typeof data?.isBookmark === 'number') {
                        this.imageDetail.isBookmarked = data.isBookmark === 1;
                        console.log('从后端更新收藏状态，isBookmark:', data.isBookmark, 'isBookmarked:', this.imageDetail.isBookmarked);
                    }
                    // 使用后端返回的 imageBookmark 字段更新收藏数量
                    if (typeof data?.imageBookmark === 'number') {
                        this.imageDetail.bookmarkCount = data.imageBookmark;
                        console.log('从后端更新收藏数量，imageBookmark:', data.imageBookmark);
                    }
                    // 注意：ImageInformationDTO 接口中没有 username 字段
                    // 用户名信息应该从传递的图片数据中获取，不需要从后端更新
                }
            }
            else {
                console.warn('getImageInformation 返回非成功，保持现有展示');
            }
        }
        catch (e) {
            console.error('获取图片基础信息失败:', e);
        }
    }
    /**
     * 准备详情页可显示的图片地址：
     * - 如果是完整URL或带路径的相对URL，直接补全使用
     * - 如果只有文件名，则从受保护接口带token下载到本地缓存并使用本地文件路径显示
     */
    async ensureDisplayImageUri() {
        try {
            if (!this.imageDetail) {
                this.displayImageUri = '';
                return;
            }
            const base = HttpService.getBaseUrl();
            const raw = this.imageDetail.imageUrl || '';
            if (!raw) {
                this.displayImageUri = '';
                return;
            }
            // 完整URL或含路径的相对URL → 直接补全
            if (raw.startsWith('http') || raw.includes('/')) {
                this.displayImageUri = raw.startsWith('http') ? raw : `${base}${raw.startsWith('/') ? raw : '/' + raw}`;
            }
            else {
                // 仅文件名 → 直接使用静态资源路径 /images/<filename>
                const publicUrl = `${base}/images/${encodeURIComponent(raw)}`;
                this.displayImageUri = publicUrl;
                console.log('采用公开图片地址用于展示:', publicUrl);
            }
            // 同时加载图片数据到 PixelMap 用于保存
            await this.loadImageForSave();
        }
        catch (e) {
            console.error('ensureDisplayImageUri 失败:', e);
            this.displayImageUri = '';
        }
    }
    /**
     * 加载图片数据到 PixelMap 用于保存
     */
    async loadImageForSave() {
        try {
            if (!this.displayImageUri) {
                this.img = null;
                return;
            }
            console.log('开始加载图片数据用于保存:', this.displayImageUri);
            const imageData = await this.downloadImage(this.displayImageUri);
            if (imageData) {
                const imageSource = image.createImageSource(imageData);
                this.img = await imageSource.createPixelMap();
                imageSource.release();
                console.log('图片数据加载成功，可用于保存');
            }
            else {
                console.error('图片数据加载失败');
                this.img = null;
            }
        }
        catch (e) {
            console.error('loadImageForSave 失败:', e);
            this.img = null;
        }
    }
    /**
     * 点赞/取消点赞
     */
    async toggleLike() {
        if (!this.imageDetail || this.isLiking)
            return;
        this.isLiking = true;
        try {
            // 先更新本地状态
            const oldIsLiked = this.imageDetail.isLiked;
            const oldLikeCount = this.imageDetail.likeCount || 0;
            this.imageDetail.isLiked = !this.imageDetail.isLiked;
            this.imageDetail.likeCount = oldLikeCount + (this.imageDetail.isLiked ? 1 : -1);
            // 保存到本地存储
            await this.saveLikeStatusToLocal(this.imageDetail.imageId, this.imageDetail.isLiked, this.imageDetail.likeCount);
            promptAction.showToast({
                message: this.imageDetail.isLiked ? '点赞成功' : '取消点赞'
            });
            // 尝试调用API（即使失败也不影响本地显示）
            try {
                const response = await ApiService.toggleLike(this.imageDetail.imageId);
                console.log('点赞API响应:', response);
                if (response.code === 1) {
                    console.log('点赞API调用成功');
                }
                else {
                    console.error('点赞API失败，响应码:', response.code, '错误信息:', response.msg);
                }
            }
            catch (apiError) {
                console.error('点赞API调用异常:', apiError);
                // API失败不影响本地显示
            }
        }
        catch (error) {
            console.error('点赞失败:', error);
            promptAction.showToast({ message: '操作失败' });
        }
        finally {
            this.isLiking = false;
        }
    }
    /**
     * 收藏/取消收藏
     */
    async toggleBookmark() {
        if (!this.imageDetail || this.isBookmarking)
            return;
        this.isBookmarking = true;
        try {
            // 先更新本地状态
            const oldIsBookmarked: boolean = this.imageDetail.isBookmarked || false;
            const oldBookmarkCount: number = this.imageDetail.bookmarkCount || 0;
            this.imageDetail.isBookmarked = !this.imageDetail.isBookmarked;
            this.imageDetail.bookmarkCount = oldBookmarkCount + (this.imageDetail.isBookmarked ? 1 : -1);
            promptAction.showToast({
                message: this.imageDetail.isBookmarked ? '收藏成功' : '取消收藏'
            });
            // 尝试调用API（即使失败也不影响本地显示）
            try {
                const response = await ApiService.changeBookmark(this.imageDetail.imageId);
                console.log('收藏API响应:', response);
                if (response.code === 1) {
                    console.log('收藏API调用成功');
                    // 重新获取图片信息以同步后端状态
                    await this.refreshImageInformation();
                }
                else {
                    console.error('收藏API失败，响应码:', response.code, '错误信息:', response.msg);
                }
            }
            catch (apiError) {
                console.error('收藏API调用异常:', apiError);
                // API失败不影响本地显示
            }
        }
        catch (error) {
            console.error('收藏失败:', error);
            promptAction.showToast({ message: '操作失败' });
        }
        finally {
            this.isBookmarking = false;
        }
    }
    /**
     * 切换评论输入框显示状态
     */
    toggleCommentInput() {
        this.showCommentInput = !this.showCommentInput;
        if (!this.showCommentInput) {
            // 如果隐藏输入框，清空输入内容
            this.newComment = '';
        }
    }
    /**
     * 发表评论
     */
    async postComment() {
        if (!this.newComment.trim() || this.isCommenting)
            return;
        this.isCommenting = true;
        try {
            console.log('=== 开始发表评论 ===');
            console.log('评论内容:', this.newComment.trim());
            console.log('图片ID:', this.imageId);
            console.log('图片ID类型:', typeof this.imageId);
            // 检查是否有token，如果没有则提示用户登录
            const HttpServiceModule = await import("@normalized:N&&&entry/src/main/ets/services/HttpService&");
            const HttpService = HttpServiceModule.HttpService;
            const token = await HttpService.getToken();
            console.log('当前token状态:', token ? '已登录' : '未登录');
            if (!token) {
                promptAction.showDialog({
                    title: '需要登录',
                    message: '发表评论需要先登录，是否前往登录页面？',
                    buttons: [
                        {
                            text: '取消',
                            color: '#666666'
                        },
                        {
                            text: '去登录',
                            color: '#4CAF50'
                        }
                    ]
                }).then((result) => {
                    if (result.index === 1) {
                        // 用户选择去登录
                        router.pushUrl({ url: 'pages/LoginPage' });
                    }
                });
                this.isCommenting = false;
                return;
            }
            // 先保存评论内容，避免在API调用后丢失
            const commentContent = this.newComment.trim();
            // 获取当前用户信息
            const currentUserInfo = UserState.getUserInfo();
            const currentUsername = currentUserInfo?.username || '用户';
            const currentUserId = currentUserInfo?.userId || 1;
            // 创建新的评论对象
            const newComment: Comment = {
                commentId: Date.now(),
                content: commentContent,
                imageId: this.imageId,
                userId: currentUserId,
                username: currentUsername,
                createTime: new Date().toISOString(),
                userAvatarUrl: this.userAvatarUrl // 添加当前用户头像URL
            };
            console.log('创建新评论，ID:', newComment.commentId, '类型:', typeof newComment.commentId);
            // 先添加到本地列表
            this.comments.unshift(newComment);
            // 保存到本地存储
            await this.saveCommentsToLocal(this.comments);
            console.log('评论已添加到本地列表，当前评论数量:', this.comments.length);
            // 清空输入框和隐藏输入区域
            this.newComment = '';
            this.showCommentInput = false;
            // 尝试调用API（即使失败也不影响本地显示）
            try {
                const response = await ApiService.postComment({
                    content: commentContent,
                    imageId: this.imageId
                });
                console.log('发表评论API响应:', response);
                console.log('响应码:', response.code);
                console.log('响应消息:', response.msg);
                console.log('响应数据:', response.data);
                if (response.code === 1) {
                    promptAction.showToast({ message: '评论成功' });
                    console.log('评论已成功同步到服务器');
                    // 注意：postComment API返回的是void，不包含commentId
                    // 如果需要获取服务器返回的commentId，需要修改API接口或使用其他方法
                    console.log('评论已成功保存到服务器，但无法获取服务器返回的评论ID');
                }
                else {
                    console.error('发表评论API失败，响应码:', response.code, '错误信息:', response.msg);
                    promptAction.showToast({ message: '评论已保存到本地，但服务器同步失败' });
                }
            }
            catch (apiError) {
                console.error('发表评论API调用异常:', apiError);
                promptAction.showToast({ message: '评论已保存到本地，但服务器同步失败' });
            }
        }
        catch (error) {
            console.error('发表评论失败:', error);
            console.error('错误类型:', typeof error);
            console.error('错误详情:', JSON.stringify(error));
            promptAction.showToast({ message: '评论失败，请检查网络连接' });
        }
        finally {
            this.isCommenting = false;
        }
    }
    /**
     * 删除评论
     */
    async deleteComment(comment: Comment) {
        console.log('=== 删除评论开始 ===');
        console.log('评论对象:', comment);
        console.log('评论ID:', comment.commentId, '类型:', typeof comment.commentId);
        // 检查是否有token，如果没有则提示用户登录
        const HttpServiceModule = await import("@normalized:N&&&entry/src/main/ets/services/HttpService&");
        const HttpService = HttpServiceModule.HttpService;
        const token = await HttpService.getToken();
        if (!token) {
            promptAction.showDialog({
                title: '需要登录',
                message: '删除评论需要先登录，是否前往登录页面？',
                buttons: [
                    {
                        text: '取消',
                        color: '#666666'
                    },
                    {
                        text: '去登录',
                        color: '#4CAF50'
                    }
                ]
            }).then((result) => {
                if (result.index === 1) {
                    // 用户选择去登录
                    router.pushUrl({ url: 'pages/LoginPage' });
                }
            });
            return;
        }
        // 添加确认对话框
        promptAction.showDialog({
            title: '确认删除',
            message: '确定要删除这条评论吗？',
            buttons: [
                {
                    text: '取消',
                    color: '#666666'
                },
                {
                    text: '删除',
                    color: '#FF5722'
                }
            ]
        }).then(async (result) => {
            if (result.index === 1) {
                // 用户确认删除
                try {
                    // 显示删除中提示
                    promptAction.showToast({
                        message: '正在删除评论...',
                        duration: 1000
                    });
                    console.log('开始删除评论，ID:', comment.commentId);
                    // 尝试调用API删除评论
                    try {
                        // 调试评论ID
                        console.log('=== 评论ID调试 ===');
                        console.log('完整评论对象:', JSON.stringify(comment, null, 2));
                        console.log('评论ID:', comment.commentId);
                        console.log('评论ID类型:', typeof comment.commentId);
                        console.log('评论ID是否为null:', comment.commentId === null);
                        console.log('评论ID是否为undefined:', comment.commentId === undefined);
                        // 详细调试评论对象
                        console.log('=== 评论删除调试 ===');
                        console.log('完整评论对象:', JSON.stringify(comment, null, 2));
                        console.log('评论对象所有字段:', Object.keys(comment));
                        console.log('commentId字段值:', comment.commentId);
                        console.log('commentId字段类型:', typeof comment.commentId);
                        console.log('commentId是否为null:', comment.commentId === null);
                        console.log('commentId是否为undefined:', comment.commentId === undefined);
                        // 尝试从不同字段获取ID
                        let commentId: number | null = null;
                        // 优先使用服务器返回的id字段
                        if (comment.id !== null && comment.id !== undefined) {
                            commentId = Number(comment.id);
                            console.log('使用id字段:', commentId);
                        }
                        else if (comment.commentId !== null && comment.commentId !== undefined) {
                            commentId = Number(comment.commentId);
                            console.log('使用commentId字段:', commentId);
                        }
                        else {
                            console.log('所有ID字段都为空，尝试其他方法...');
                            console.log('评论对象:', JSON.stringify(comment, null, 2));
                        }
                        if (commentId === null || isNaN(commentId) || commentId <= 0) {
                            console.error('未找到有效的评论ID');
                            console.error('所有字段:', Object.keys(comment));
                            console.error('所有值:', Object.values(comment));
                            // 如果无法获取有效的评论ID，尝试通过内容匹配删除
                            console.log('尝试通过内容匹配删除评论');
                            const originalLength = this.comments.length;
                            this.comments = this.comments.filter(c => {
                                return c.content !== comment.content || c.imageId !== comment.imageId;
                            });
                            if (this.comments.length < originalLength) {
                                console.log('通过内容匹配成功删除评论');
                                await this.saveCommentsToLocal(this.comments);
                                promptAction.showToast({ message: '评论已删除' });
                                return;
                            }
                            else {
                                promptAction.showToast({ message: '评论ID为空，无法删除' });
                                return;
                            }
                        }
                        console.log('最终使用的评论ID:', commentId);
                        const response = await ApiService.deleteComment(commentId);
                        console.log('API删除响应:', response);
                        console.log('响应码:', response.code);
                        console.log('响应消息:', response.msg);
                        console.log('响应数据:', response.data);
                        if (response.code === 1) {
                            console.log('API删除成功');
                            promptAction.showToast({ message: '删除成功' });
                        }
                        else {
                            console.log('API删除失败，响应码:', response.code, '错误信息:', response.msg);
                            promptAction.showToast({ message: '删除失败: ' + (response.msg || '未知错误') });
                            return;
                        }
                    }
                    catch (apiError) {
                        console.error('API删除异常:', apiError);
                        console.error('异常类型:', typeof apiError);
                        console.error('异常详情:', JSON.stringify(apiError));
                        promptAction.showToast({ message: '删除失败，请检查网络连接' });
                        return;
                    }
                    // API删除成功后，从本地列表中移除
                    const originalLength = this.comments.length;
                    this.comments = this.comments.filter(c => {
                        // 使用多种方式匹配要删除的评论
                        if (c.commentId !== null && c.commentId !== undefined && comment.commentId !== null && comment.commentId !== undefined) {
                            return c.commentId !== comment.commentId;
                        }
                        // 如果ID为空，通过内容和图片ID匹配
                        return c.content !== comment.content || c.imageId !== comment.imageId;
                    });
                    // 保存到本地存储
                    await this.saveCommentsToLocal(this.comments);
                    console.log('评论删除完成，原数量:', originalLength, '现数量:', this.comments.length);
                }
                catch (error) {
                    console.error('删除评论失败:', error);
                    console.error('错误类型:', typeof error);
                    console.error('错误详情:', JSON.stringify(error));
                    promptAction.showToast({ message: '删除失败，请检查网络连接' });
                }
            }
        });
    }
    /**
     * 重新加载评论
     */
    async loadComments() {
        try {
            console.log('尝试加载评论，图片ID:', this.imageId);
            // 优先从API加载评论（确保获取最新的评论状态）
            try {
                console.log('调用 getImageComments API...');
                const commentsResponse = await ApiService.getImageComments(this.imageId);
                console.log('getImageComments 响应:', commentsResponse);
                if (commentsResponse.code === 1) {
                    this.comments = commentsResponse.data || [];
                    // 为评论添加头像信息
                    this.comments = this.comments.map(comment => {
                        console.log('处理评论:', {
                            id: comment.id,
                            commentId: comment.commentId,
                            username: comment.username,
                            userId: comment.userId,
                            currentUserId: this.currentUserId,
                            headshotUrl: comment.headshotUrl,
                            userAvatarUrl: comment.userAvatarUrl,
                            currentUserAvatarUrl: this.userAvatarUrl
                        });
                        // 优先使用服务器返回的头像URL
                        let finalAvatarUrl = comment.headshotUrl || comment.userAvatarUrl;
                        // 检查评论的头像URL是否有效（服务器返回的是 "http://.../images/null"）
                        const isCommentAvatarInvalid = !finalAvatarUrl ||
                            (typeof finalAvatarUrl === 'string' && finalAvatarUrl.trim() === '') ||
                            (typeof finalAvatarUrl === 'string' && finalAvatarUrl.toLowerCase() === 'null') ||
                            (typeof finalAvatarUrl === 'string' && finalAvatarUrl.toLowerCase() === 'undefined') ||
                            (typeof finalAvatarUrl === 'string' && finalAvatarUrl.includes('/images/null'));
                        // 如果评论的头像无效/缺失，且当前用户有头像，则使用当前用户头像作为备用
                        if (isCommentAvatarInvalid && this.userAvatarUrl) {
                            finalAvatarUrl = this.userAvatarUrl;
                            console.log('为评论ID:', comment.id || comment.commentId, '添加当前用户头像URL (fallback):', finalAvatarUrl);
                        }
                        // 如果是当前用户的评论，确保使用当前用户头像
                        else if (comment.userId === this.currentUserId ||
                            comment.username === '我' ||
                            comment.username === '当前用户') {
                            finalAvatarUrl = this.userAvatarUrl;
                            console.log('为当前用户评论ID:', comment.id || comment.commentId, '添加当前用户头像URL:', finalAvatarUrl);
                        }
                        // 如果评论有头像URL但不是完整URL，尝试构建完整URL
                        else if (finalAvatarUrl && !finalAvatarUrl.startsWith('http')) {
                            const baseUrl = HttpService.getBaseUrl();
                            finalAvatarUrl = `${baseUrl}/images/${finalAvatarUrl}`;
                            console.log('为评论ID:', comment.id || comment.commentId, '构建完整头像URL:', finalAvatarUrl);
                        }
                        const updatedComment: Comment = {
                            id: comment.id,
                            commentId: comment.commentId,
                            content: comment.content,
                            imageId: comment.imageId || this.imageId,
                            userId: comment.userId,
                            username: comment.username,
                            createTime: comment.createTime,
                            commentsTime: comment.commentsTime,
                            userAvatarUrl: finalAvatarUrl,
                            headshotUrl: comment.headshotUrl
                        };
                        return updatedComment;
                    });
                    console.log('评论列表加载成功，评论数量:', this.comments.length);
                    // 调试：检查API响应的完整结构
                    console.log('=== API响应完整结构 ===');
                    console.log('完整响应:', JSON.stringify(commentsResponse, null, 2));
                    console.log('响应数据类型:', typeof commentsResponse.data);
                    console.log('响应数据是否为数组:', Array.isArray(commentsResponse.data));
                    // 调试：检查从API加载的评论ID格式
                    if (this.comments.length > 0) {
                        console.log('=== API评论ID调试 ===');
                        this.comments.forEach((comment, index) => {
                            console.log(`评论${index + 1}完整对象:`, JSON.stringify(comment, null, 2));
                            console.log(`评论${index + 1}所有字段:`, Object.keys(comment));
                            console.log(`评论${index + 1}字段值:`, {
                                commentId: comment.commentId,
                                commentIdType: typeof comment.commentId,
                                content: comment.content?.substring(0, 20) + '...',
                                imageId: comment.imageId,
                                userId: comment.userId,
                                username: comment.username
                            });
                            // 通过JSON序列化检查所有字段
                            const commentJson = JSON.stringify(comment);
                            console.log(`评论${index + 1}JSON内容:`, commentJson);
                            // 检查是否包含其他可能的ID字段
                            if (commentJson.includes('"id"')) {
                                console.log(`评论${index + 1}包含id字段`);
                            }
                            if (commentJson.includes('"comment_id"')) {
                                console.log(`评论${index + 1}包含comment_id字段`);
                            }
                            if (commentJson.includes('"commentID"')) {
                                console.log(`评论${index + 1}包含commentID字段`);
                            }
                        });
                    }
                    else {
                        console.log('API返回的评论列表为空');
                    }
                    // 保存到本地存储
                    await this.saveCommentsToLocal(this.comments);
                    return;
                }
                else {
                    console.error('获取评论失败，响应码:', commentsResponse.code, '错误信息:', commentsResponse.msg);
                }
            }
            catch (apiError) {
                console.error('API调用失败，尝试从本地存储加载:', apiError);
            }
            // 如果API失败，尝试从本地存储加载评论
            console.log('从本地存储加载评论...');
            const localComments = await this.loadCommentsFromLocal();
            this.comments = localComments;
            console.log('从本地存储加载评论，数量:', this.comments.length);
            // 调试：检查从本地存储加载的评论ID格式
            if (this.comments.length > 0) {
                console.log('=== 本地评论ID调试 ===');
                this.comments.forEach((comment, index) => {
                    console.log(`本地评论${index + 1}:`, {
                        commentId: comment.commentId,
                        commentIdType: typeof comment.commentId,
                        content: comment.content?.substring(0, 20) + '...'
                    });
                });
            }
        }
        catch (error) {
            console.error('加载评论失败:', error);
            console.error('使用空评论列表');
            this.comments = [];
        }
    }
    /**
     * 从本地存储加载评论
     */
    async loadCommentsFromLocal(): Promise<Comment[]> {
        try {
            // 使用全局存储评论数据
            const commentsKey = `comments_${this.imageId}`;
            const storage = ImageDetailPage.getGlobalStorage();
            console.log('尝试从本地存储加载评论，key:', commentsKey);
            console.log('当前存储的所有keys:', Object.keys(storage));
            const storedComments = storage[commentsKey];
            console.log('存储的评论数据:', storedComments);
            if (storedComments) {
                const comments = JSON.parse(storedComments) as Comment[];
                console.log('从本地存储加载评论成功，数量:', comments.length);
                console.log('加载的评论内容:', comments);
                return comments;
            }
            else {
                console.log('没有找到存储的评论数据');
            }
        }
        catch (error) {
            console.error('从本地存储加载评论失败:', error);
        }
        return [];
    }
    /**
     * 保存评论到本地存储
     */
    async saveCommentsToLocal(comments: Comment[]): Promise<void> {
        try {
            // 使用全局存储评论数据
            const commentsKey = `comments_${this.imageId}`;
            const storage = ImageDetailPage.getGlobalStorage();
            console.log('保存评论到本地存储，key:', commentsKey);
            console.log('要保存的评论数量:', comments.length);
            console.log('要保存的评论内容:', comments);
            storage[commentsKey] = JSON.stringify(comments);
            console.log('评论已保存到本地存储，数量:', comments.length);
            console.log('保存后的存储内容:', storage[commentsKey]);
            console.log('全局存储状态:', Object.keys(storage));
        }
        catch (error) {
            console.error('保存评论到本地存储失败:', error);
        }
    }
    /**
     * 保存点赞状态到本地存储
     */
    async saveLikeStatusToLocal(imageId: number, isLiked: boolean, likeCount: number): Promise<void> {
        try {
            const likeKey = `like_${imageId}`;
            const likesStorage = ImageDetailPage.getLikesStorage();
            const likeData: LikeData = {
                isLiked: isLiked,
                likeCount: likeCount,
                timestamp: Date.now()
            };
            console.log('保存点赞状态到本地存储，key:', likeKey);
            console.log('点赞状态:', likeData);
            likesStorage[likeKey] = JSON.stringify(likeData);
            console.log('点赞状态已保存到本地存储');
            console.log('点赞存储状态:', Object.keys(likesStorage));
        }
        catch (error) {
            console.error('保存点赞状态到本地存储失败:', error);
        }
    }
    /**
     * 从本地存储加载点赞状态
     */
    async loadLikeStatusFromLocal(imageId: number): Promise<LikeStatus | null> {
        try {
            const likeKey = `like_${imageId}`;
            const likesStorage = ImageDetailPage.getLikesStorage();
            console.log('尝试从本地存储加载点赞状态，key:', likeKey);
            console.log('当前点赞存储的所有keys:', Object.keys(likesStorage));
            const storedLikeData = likesStorage[likeKey];
            console.log('存储的点赞数据:', storedLikeData);
            if (storedLikeData) {
                const likeData = JSON.parse(storedLikeData) as LikeData;
                console.log('从本地存储加载点赞状态成功:', likeData);
                const likeStatus: LikeStatus = {
                    isLiked: likeData.isLiked,
                    likeCount: likeData.likeCount
                };
                return likeStatus;
            }
            else {
                console.log('没有找到存储的点赞数据');
            }
        }
        catch (error) {
            console.error('从本地存储加载点赞状态失败:', error);
        }
        return null;
    }
    /**
     * 保存收藏状态到本地存储
     */
    async saveBookmarkStatusToLocal(imageId: number, isBookmarked: boolean, bookmarkCount: number): Promise<void> {
        try {
            const bookmarkKey = `bookmark_${imageId}`;
            const bookmarksStorage = ImageDetailPage.getBookmarksStorage();
            const bookmarkData: BookmarkData = {
                isBookmarked: isBookmarked,
                bookmarkCount: bookmarkCount,
                timestamp: Date.now()
            };
            console.log('保存收藏状态到本地存储，key:', bookmarkKey);
            console.log('收藏状态:', bookmarkData);
            bookmarksStorage[bookmarkKey] = JSON.stringify(bookmarkData);
            console.log('收藏状态已保存到本地存储');
            console.log('收藏存储状态:', Object.keys(bookmarksStorage));
        }
        catch (error) {
            console.error('保存收藏状态到本地存储失败:', error);
        }
    }
    /**
     * 从本地存储加载收藏状态
     */
    async loadBookmarkStatusFromLocal(imageId: number): Promise<BookmarkStatus | null> {
        try {
            const bookmarkKey = `bookmark_${imageId}`;
            const bookmarksStorage = ImageDetailPage.getBookmarksStorage();
            console.log('尝试从本地存储加载收藏状态，key:', bookmarkKey);
            console.log('当前收藏存储的所有keys:', Object.keys(bookmarksStorage));
            const storedBookmarkData = bookmarksStorage[bookmarkKey];
            console.log('存储的收藏数据:', storedBookmarkData);
            if (storedBookmarkData) {
                const bookmarkData = JSON.parse(storedBookmarkData) as BookmarkData;
                console.log('从本地存储加载收藏状态成功:', bookmarkData);
                const bookmarkStatus: BookmarkStatus = {
                    isBookmarked: bookmarkData.isBookmarked,
                    bookmarkCount: bookmarkData.bookmarkCount
                };
                return bookmarkStatus;
            }
            else {
                console.log('没有找到存储的收藏数据');
            }
        }
        catch (error) {
            console.error('从本地存储加载收藏状态失败:', error);
        }
        return null;
    }
    /**
     * 保存已删除的评论ID到本地存储
     */
    async saveDeletedCommentIds(): Promise<void> {
        try {
            const deletedKey = `deleted_${this.imageId}`;
            const storage = ImageDetailPage.getGlobalStorage();
            storage[deletedKey] = JSON.stringify(Array.from(this.deletedCommentIds));
            console.log('已删除评论ID已保存到本地存储:', Array.from(this.deletedCommentIds));
        }
        catch (error) {
            console.error('保存已删除评论ID失败:', error);
        }
    }
    /**
     * 从本地存储加载已删除的评论ID
     */
    async loadDeletedCommentIds(): Promise<void> {
        try {
            const deletedKey = `deleted_${this.imageId}`;
            const storage = ImageDetailPage.getGlobalStorage();
            console.log('尝试加载已删除评论ID，key:', deletedKey);
            console.log('当前存储的所有keys:', Object.keys(storage));
            const storedDeletedIds = storage[deletedKey];
            console.log('存储的已删除评论ID数据:', storedDeletedIds);
            if (storedDeletedIds) {
                const deletedIds = JSON.parse(storedDeletedIds) as number[];
                this.deletedCommentIds = new Set(deletedIds);
                console.log('从本地存储加载已删除评论ID成功:', Array.from(this.deletedCommentIds));
            }
            else {
                this.deletedCommentIds = new Set();
                console.log('没有找到已删除的评论ID');
            }
        }
        catch (error) {
            console.error('加载已删除评论ID失败:', error);
            this.deletedCommentIds = new Set();
        }
    }
    /**
     * 分享图片 - 显示图片链接供用户复制
     */
    async shareImage() {
        if (!this.imageDetail) {
            promptAction.showToast({ message: '图片信息不可用' });
            return;
        }
        try {
            // 获取图片的完整URL
            const imageUrl = this.getDisplayImageUrl();
            if (!imageUrl) {
                promptAction.showToast({ message: '图片链接不可用' });
                return;
            }
            // 显示分享对话框
            promptAction.showDialog({
                title: '分享图片',
                message: `图片链接：\n${imageUrl}\n\n点击确定复制链接到剪贴板`,
                buttons: [
                    { text: '取消', color: '#999999' },
                    { text: '复制链接', color: '#4CAF50' }
                ]
            }).then((result) => {
                if (result.index === 1) {
                    // 用户选择复制链接，直接复制到剪贴板
                    this.copyToClipboard(imageUrl);
                }
            });
        }
        catch (error) {
            console.error('分享图片失败:', error);
            promptAction.showToast({
                message: '分享失败: ' + String(error),
                duration: 3000
            });
        }
    }
    /**
     * 复制文本到剪贴板
     */
    async copyToClipboard(text: string) {
        try {
            // 构造PlainText数据
            let plainTextData = new unifiedDataChannel.UnifiedData();
            let plainText = new unifiedDataChannel.PlainText();
            // 设置文本内容
            plainText.details = {
                Key: 'imageUrl',
                Value: 'imageUrl',
            };
            plainText.textContent = text;
            plainText.abstract = text;
            plainTextData.addRecord(plainText);
            // 设置跨应用分享选项
            plainTextData.properties.shareOptions = unifiedDataChannel.ShareOptions.CROSS_APP;
            // 写入系统剪贴板
            await pasteboard.getSystemPasteboard().setUnifiedData(plainTextData);
            // 显示成功提示
            promptAction.showToast({
                message: '链接已复制到剪贴板',
                duration: 2000
            });
        }
        catch (error) {
            console.error('复制到剪贴板失败:', error);
            // 如果剪贴板API失败，显示链接供用户手动复制
            promptAction.showDialog({
                title: '图片链接',
                message: `复制失败，请手动复制：\n${text}`,
                buttons: [
                    { text: '确定', color: '#4CAF50' }
                ]
            });
        }
    }
    /**
     * 保存图片到相册 - 使用沙箱环境方法
     */
    async saveImage() {
        if (!this.img) {
            promptAction.showToast({ message: '图片数据未准备好，请稍后再试' });
            return;
        }
        // 首先检查权限
        if (!await this.checkPermission()) {
            promptAction.showToast({
                message: '需要相册权限，请在设置中手动开启',
                duration: 3000
            });
            return;
        }
        try {
            console.log('=== 开始保存图片到相册 ===');
            // 显示保存中提示
            promptAction.showToast({
                message: '正在保存图片到相册...',
                duration: 1000
            });
            // 生成文件名
            const timestamp = new Date().getTime();
            const filename = `PhotoSharing_${timestamp}`;
            // 使用新的保存方法
            await this.saveScreenshot(this.img, filename);
        }
        catch (error) {
            console.error('=== 保存图片到相册失败 ===');
            console.error('错误类型:', typeof error);
            console.error('错误信息:', error);
            console.error('错误堆栈:', (error as Error).stack);
            promptAction.showToast({
                message: '保存失败: ' + String(error),
                duration: 3000
            });
        }
    }
    /**
     * 下载图片数据
     */
    private async downloadImage(url: string): Promise<ArrayBuffer | null> {
        try {
            console.log('=== 开始下载图片 ===');
            console.log('图片URL:', url);
            const httpRequest = http.createHttp();
            console.log('HTTP请求对象创建成功');
            const response = await httpRequest.request(url, {
                method: http.RequestMethod.GET,
                header: {
                    'Content-Type': 'application/json'
                }
            });
            console.log('HTTP响应状态码:', response.responseCode);
            console.log('响应头:', response.header);
            if (response.responseCode === 200) {
                const result = response.result as ArrayBuffer;
                console.log('图片下载成功，数据大小:', result.byteLength);
                return result;
            }
            else {
                console.error('图片下载失败，状态码:', response.responseCode);
                console.error('响应消息:', response.header);
                return null;
            }
        }
        catch (error) {
            console.error('=== 下载图片异常 ===');
            console.error('错误类型:', typeof error);
            console.error('错误信息:', error);
            console.error('错误堆栈:', (error as Error).stack);
            return null;
        }
    }
    /** 下载受保护图片（自动附带token） */
    private async downloadImageWithToken(url: string): Promise<ArrayBuffer | null> {
        try {
            console.log('=== 开始下载受保护图片 ===');
            console.log('受保护图片URL:', url);
            const httpRequest = http.createHttp();
            const token = await HttpService.getToken();
            const headers: Record<string, string> = {
                'Content-Type': 'application/octet-stream'
            };
            if (token) {
                headers['token'] = token;
            }
            const response = await httpRequest.request(url, {
                method: http.RequestMethod.GET,
                header: headers
            });
            console.log('受保护图片HTTP响应状态码:', response.responseCode);
            if (response.responseCode === 200) {
                return response.result as ArrayBuffer;
            }
            console.error('受保护图片下载失败，状态码:', response.responseCode);
            return null;
        }
        catch (error) {
            console.error('下载受保护图片异常:', error);
            return null;
        }
    }
    /**
     * 格式化时间显示
     */
    formatTime(timeString?: string): string {
        if (!timeString)
            return '';
        try {
            const date = new Date(timeString);
            const now = new Date();
            const diff = now.getTime() - date.getTime();
            // 小于1分钟
            if (diff < 60000) {
                return '刚刚';
            }
            // 小于1小时
            else if (diff < 3600000) {
                return `${Math.floor(diff / 60000)}分钟前`;
            }
            // 小于1天
            else if (diff < 86400000) {
                return `${Math.floor(diff / 3600000)}小时前`;
            }
            // 小于7天
            else if (diff < 604800000) {
                return `${Math.floor(diff / 86400000)}天前`;
            }
            // 超过7天，显示具体日期
            else {
                return date.toLocaleDateString('zh-CN', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                });
            }
        }
        catch (error) {
            console.error('时间格式化失败:', error);
            return timeString;
        }
    }
    /**
     * 返回
     */
    goBack() {
        router.back();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Stack.create();
            Stack.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1608:5)", "entry");
            Stack.width('100%');
            Stack.height('100%');
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 主内容层
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1610:7)", "entry");
            // 主内容层
            Column.width('100%');
            // 主内容层
            Column.height('100%');
            // 主内容层
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 顶部导航栏 - 包含用户信息
            Row.create({ space: 12 });
            Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1612:9)", "entry");
            // 顶部导航栏 - 包含用户信息
            Row.width('100%');
            // 顶部导航栏 - 包含用户信息
            Row.height(56);
            // 顶部导航栏 - 包含用户信息
            Row.padding({ left: 16, right: 16 });
            // 顶部导航栏 - 包含用户信息
            Row.backgroundColor(Color.Transparent);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('←');
            Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1613:11)", "entry");
            Text.fontSize(24);
            Text.fontColor(Color.Black);
            Text.onClick(() => this.goBack());
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 图片作者头像
            // 图片作者头像
            // 用户头像
            if (this.userAvatarUrl) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create(this.userAvatarUrl);
                        Image.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1622:13)", "entry");
                        Image.width(32);
                        Image.height(32);
                        Image.borderRadius(16);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1628:13)", "entry");
                        Image.width(32);
                        Image.height(32);
                        Image.borderRadius(16);
                        Image.objectFit(ImageFit.Cover);
                    }, Image);
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 用户名称
            Text.create(this.getDisplayUsername());
            Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1636:11)", "entry");
            // 用户名称
            Text.fontSize(16);
            // 用户名称
            Text.fontWeight(FontWeight.Medium);
            // 用户名称
            Text.fontColor(Color.Black);
        }, Text);
        // 用户名称
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1642:11)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 更多操作
            Text.create('⋯');
            Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1645:11)", "entry");
            // 更多操作
            Text.fontSize(24);
            // 更多操作
            Text.fontColor(Color.Black);
            // 更多操作
            Text.onClick(() => {
                console.log('点击三点按钮，当前 isOwner:', this.isOwner);
                this.showActions = !this.showActions;
            });
        }, Text);
        // 更多操作
        Text.pop();
        // 顶部导航栏 - 包含用户信息
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isLoading) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 加载中状态
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1660:11)", "entry");
                        // 加载中状态
                        Column.justifyContent(FlexAlign.Center);
                        // 加载中状态
                        Column.width('100%');
                        // 加载中状态
                        Column.flexGrow(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1661:13)", "entry");
                        LoadingProgress.width(50);
                        LoadingProgress.height(50);
                        LoadingProgress.color('#4CAF50');
                    }, LoadingProgress);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('加载中...');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1666:13)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Color.Black);
                        Text.margin({ top: 16 });
                    }, Text);
                    Text.pop();
                    // 加载中状态
                    Column.pop();
                });
            }
            else if (this.imageDetail) {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 图片详情内容
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1676:11)", "entry");
                        // 图片详情内容
                        Column.flexGrow(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 可滚动的内容区域
                        Scroll.create();
                        Scroll.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1678:13)", "entry");
                        // 可滚动的内容区域
                        Scroll.layoutWeight(1);
                    }, Scroll);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 0 });
                        Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1679:15)", "entry");
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 图片内容
                        Image.create(this.displayImageUri || this.getDisplayImageUrl());
                        Image.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1681:17)", "entry");
                        // 图片内容
                        Image.width('100%');
                        // 图片内容
                        Image.height(400);
                        // 图片内容
                        Image.objectFit(ImageFit.Cover);
                        // 图片内容
                        Image.backgroundColor(Colors.White20);
                        Gesture.create(GesturePriority.Low);
                        TapGesture.create({ count: 2 });
                        TapGesture.onAction(() => {
                            console.log('双击图片，开始保存');
                            this.saveImage();
                        });
                        TapGesture.pop();
                        Gesture.pop();
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 图片标题
                        Text.create(this.getDisplayImageName(this.imageDetail.imageName));
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1695:17)", "entry");
                        // 图片标题
                        Text.fontSize(18);
                        // 图片标题
                        Text.fontWeight(FontWeight.Bold);
                        // 图片标题
                        Text.fontColor(Color.Black);
                        // 图片标题
                        Text.width('100%');
                        // 图片标题
                        Text.textAlign(TextAlign.Start);
                        // 图片标题
                        Text.padding({ left: 16, right: 16, top: 16, bottom: 8 });
                        // 图片标题
                        Text.backgroundColor(Color.White);
                    }, Text);
                    // 图片标题
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 图片详情描述
                        if (this.imageDetail.content) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create(this.imageDetail.content);
                                    Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1706:19)", "entry");
                                    Text.fontSize(16);
                                    Text.fontColor(Color.Black);
                                    Text.width('100%');
                                    Text.textAlign(TextAlign.Start);
                                    Text.lineHeight(24);
                                    Text.padding({ left: 16, right: 16, bottom: 16 });
                                    Text.backgroundColor(Color.White);
                                }, Text);
                                Text.pop();
                            });
                        }
                        // 互动区域
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 互动区域
                        Row.create({ space: 20 });
                        Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1717:17)", "entry");
                        // 互动区域
                        Row.width('100%');
                        // 互动区域
                        Row.padding({ left: 16, right: 16, top: 12, bottom: 12 });
                        // 互动区域
                        Row.backgroundColor(Color.White);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 点赞按钮
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1719:19)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.imageDetail.isLiked ? '❤️' : '🤍');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1720:21)", "entry");
                        Text.fontSize(24);
                        Text.onClick(() => this.toggleLike());
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create((this.imageDetail.likeCount || 0).toString());
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1724:21)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    // 点赞按钮
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 收藏按钮
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1730:19)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.imageDetail.isBookmarked ? '⭐' : '☆');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1731:21)", "entry");
                        Text.fontSize(24);
                        Text.onClick(() => this.toggleBookmark());
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create((this.imageDetail.bookmarkCount || 0).toString());
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1735:21)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    // 收藏按钮
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 评论按钮
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1741:19)", "entry");
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('💬');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1742:21)", "entry");
                        Text.fontSize(24);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create((this.comments.length).toString());
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1745:21)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    // 评论按钮
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1750:19)", "entry");
                    }, Blank);
                    Blank.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 分享按钮
                        Text.create('📤');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1753:19)", "entry");
                        // 分享按钮
                        Text.fontSize(24);
                        // 分享按钮
                        Text.onClick(() => this.shareImage());
                    }, Text);
                    // 分享按钮
                    Text.pop();
                    // 互动区域
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 评论区域
                        Column.create({ space: 12 });
                        Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1762:17)", "entry");
                        // 评论区域
                        Column.width('100%');
                        // 评论区域
                        Column.backgroundColor(Color.White);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 评论标题
                        Row.create();
                        Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1764:19)", "entry");
                        // 评论标题
                        Row.width('100%');
                        // 评论标题
                        Row.padding({ left: 16, right: 16, top: 16, bottom: 8 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`共${this.comments.length}条评论`);
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1765:21)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(FontWeight.Medium);
                        Text.fontColor(Color.Black);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Blank.create();
                        Blank.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1770:21)", "entry");
                    }, Blank);
                    Blank.pop();
                    // 评论标题
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 评论列表
                        if (this.comments.length > 0) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create({ space: 12 });
                                    Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1777:21)", "entry");
                                    Column.padding({ left: 16, right: 16, bottom: 16 });
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = (_item, index: number) => {
                                        const comment = _item;
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Row.create({ space: 12 });
                                            Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1779:25)", "entry");
                                            Row.width('100%');
                                            Row.padding(12);
                                            Row.backgroundColor(Colors.White10);
                                            Row.borderRadius(8);
                                            Row.alignItems(VerticalAlign.Top);
                                            Gesture.create(GesturePriority.Low);
                                            // 双击删除评论
                                            TapGesture.create({ count: 2 });
                                            // 双击删除评论
                                            TapGesture.onAction(() => {
                                                console.log('=== 双击评论被触发 ===');
                                                console.log('评论信息:', comment);
                                                console.log('评论ID:', comment.commentId);
                                                this.deleteComment(comment);
                                            });
                                            // 双击删除评论
                                            TapGesture.pop();
                                            Gesture.pop();
                                        }, Row);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            If.create();
                                            // 评论者头像
                                            if (comment.userAvatarUrl) {
                                                this.ifElseBranchUpdateFunction(0, () => {
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        Image.create(comment.userAvatarUrl);
                                                        Image.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1782:29)", "entry");
                                                        Image.width(32);
                                                        Image.height(32);
                                                        Image.borderRadius(16);
                                                        Image.objectFit(ImageFit.Cover);
                                                    }, Image);
                                                });
                                            }
                                            else {
                                                this.ifElseBranchUpdateFunction(1, () => {
                                                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                        Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
                                                        Image.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1788:29)", "entry");
                                                        Image.width(32);
                                                        Image.height(32);
                                                        Image.borderRadius(16);
                                                        Image.objectFit(ImageFit.Cover);
                                                    }, Image);
                                                });
                                            }
                                        }, If);
                                        If.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            // 评论内容
                                            Column.create({ space: 4 });
                                            Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1796:27)", "entry");
                                            // 评论内容
                                            Column.layoutWeight(1);
                                        }, Column);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Row.create();
                                            Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1797:29)", "entry");
                                            Row.width('100%');
                                        }, Row);
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(comment.username || '匿名用户');
                                            Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1798:31)", "entry");
                                            Text.fontSize(14);
                                            Text.fontWeight(FontWeight.Medium);
                                            Text.fontColor(Color.Black);
                                        }, Text);
                                        Text.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            // 删除提示
                                            Blank.create();
                                            Blank.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1804:31)", "entry");
                                        }, Blank);
                                        // 删除提示
                                        Blank.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create('双击删除');
                                            Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1805:31)", "entry");
                                            Text.fontSize(10);
                                            Text.fontColor('#999');
                                            Text.fontStyle(FontStyle.Italic);
                                        }, Text);
                                        Text.pop();
                                        Row.pop();
                                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                                            Text.create(comment.content);
                                            Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1812:29)", "entry");
                                            Text.fontSize(14);
                                            Text.fontColor(Color.Black);
                                            Text.width('100%');
                                            Text.textAlign(TextAlign.Start);
                                            Text.lineHeight(20);
                                        }, Text);
                                        Text.pop();
                                        // 评论内容
                                        Column.pop();
                                        Row.pop();
                                    };
                                    this.forEachUpdateFunction(elmtId, this.comments, forEachItemGenFunction, undefined, true, false);
                                }, ForEach);
                                ForEach.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('暂无评论');
                                    Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1842:21)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor(Colors.Black40);
                                    Text.textAlign(TextAlign.Center);
                                    Text.width('100%');
                                    Text.padding(20);
                                }, Text);
                                Text.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    // 评论区域
                    Column.pop();
                    Column.pop();
                    // 可滚动的内容区域
                    Scroll.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 固定在底部的评论输入区域
                        Row.create({ space: 12 });
                        Row.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1861:13)", "entry");
                        // 固定在底部的评论输入区域
                        Row.width('100%');
                        // 固定在底部的评论输入区域
                        Row.padding({ left: 16, right: 16, top: 8, bottom: 8 });
                        // 固定在底部的评论输入区域
                        Row.backgroundColor(Color.White);
                        // 固定在底部的评论输入区域
                        Row.borderRadius({ topLeft: 16, topRight: 16 });
                        // 固定在底部的评论输入区域
                        Row.shadow({ radius: 8, color: '#1A000000', offsetX: 0, offsetY: -2 });
                        // 固定在底部的评论输入区域
                        Row.margin({ bottom: 30 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        TextInput.create({ placeholder: '说点什么...', text: this.newComment });
                        TextInput.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1862:15)", "entry");
                        TextInput.layoutWeight(1);
                        TextInput.height(50);
                        TextInput.backgroundColor(Color.White);
                        TextInput.borderRadius(25);
                        TextInput.fontSize(14);
                        TextInput.fontColor(Color.Black);
                        TextInput.placeholderColor(Colors.Black40);
                        TextInput.onChange((value: string) => {
                            this.newComment = value;
                        });
                    }, TextInput);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel(this.isCommenting ? '发送中...' : '发送');
                        Button.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1874:15)", "entry");
                        Button.width(80);
                        Button.height(50);
                        Button.backgroundColor('#4CAF50');
                        Button.fontColor(Color.White);
                        Button.borderRadius(25);
                        Button.fontSize(14);
                        Button.enabled(!this.isCommenting && this.newComment.trim() !== '');
                        Button.onClick(() => this.postComment());
                    }, Button);
                    Button.pop();
                    // 固定在底部的评论输入区域
                    Row.pop();
                    // 图片详情内容
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(2, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 错误状态
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1894:11)", "entry");
                        // 错误状态
                        Column.justifyContent(FlexAlign.Center);
                        // 错误状态
                        Column.width('100%');
                        // 错误状态
                        Column.flexGrow(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('😞');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1895:13)", "entry");
                        Text.fontSize(48);
                        Text.margin({ bottom: 16 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('加载失败');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1899:13)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Color.Black);
                        Text.margin({ bottom: 8 });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('重试');
                        Button.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1904:13)", "entry");
                        Button.width(100);
                        Button.height(40);
                        Button.backgroundColor('#4CAF50');
                        Button.fontColor(Color.White);
                        Button.borderRadius(8);
                        Button.onClick(() => this.loadImageDetail());
                    }, Button);
                    Button.pop();
                    // 错误状态
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        // 主内容层
        Column.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 覆盖层：三点下拉菜单（绝对定位到右上角）
            if (this.showActions) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 8 });
                        Column.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1931:9)", "entry");
                        Column.backgroundColor(Color.White);
                        Column.borderRadius(12);
                        Column.shadow({ radius: 8, color: '#22000000', offsetX: 0, offsetY: 2 });
                        Column.align(Alignment.TopEnd);
                        Column.margin({ top: 56, right: 16 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('保存图片');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1932:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Color.Black);
                        Text.padding({ top: 10, bottom: 10, left: 14, right: 14 });
                        Text.backgroundColor(Color.White);
                        Text.borderRadius(8);
                        Text.onClick(() => { this.saveImage(); this.showActions = false; });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('分享图片');
                        Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1940:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Color.Black);
                        Text.padding({ top: 10, bottom: 10, left: 14, right: 14 });
                        Text.backgroundColor(Color.White);
                        Text.borderRadius(8);
                        Text.onClick(() => { this.shareImage(); this.showActions = false; });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.isOwner) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('删除图片');
                                    Text.debugLine("entry/src/main/ets/pages/ImageDetailPage.ets(1949:13)", "entry");
                                    Text.fontSize(14);
                                    Text.fontColor('#FF3B30');
                                    Text.padding({ top: 10, bottom: 10, left: 14, right: 14 });
                                    Text.backgroundColor('#FFF5F5');
                                    Text.borderRadius(8);
                                    Text.onClick(async () => {
                                        if (this.imageDetail) {
                                            try {
                                                const res = await ApiService.deleteImage(this.imageDetail.imageId);
                                                if (res.code === 1) {
                                                    promptAction.showToast({ message: '删除成功' });
                                                    this.showActions = false;
                                                    router.back();
                                                    return;
                                                }
                                                promptAction.showToast({ message: res.msg || '删除失败' });
                                            }
                                            catch (e) {
                                                promptAction.showToast({ message: '删除失败' });
                                            }
                                        }
                                        this.showActions = false;
                                    });
                                }, Text);
                                Text.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ImageDetailPage";
    }
}
registerNamedRoute(() => new ImageDetailPage(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/ImageDetailPage", pageFullPath: "entry/src/main/ets/pages/ImageDetailPage", integratedHsp: "false", moduleType: "followWithHap" });
