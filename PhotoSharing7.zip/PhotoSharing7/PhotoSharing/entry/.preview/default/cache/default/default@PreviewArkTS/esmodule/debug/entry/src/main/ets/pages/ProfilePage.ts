if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ProfilePage_Params {
    myImages?: ImageItem[];
    imageCount?: number;
    isLoading?: boolean;
    isRefreshing?: boolean;
    currentPage?: number;
    hasMore?: boolean;
    isLoggedIn?: boolean;
    currentUsername?: string;
    currentUserAccount?: string;
    currentTab?: string;
    favoriteCount?: number;
    historyCount?: number;
    userAvatar?: image.PixelMap | null;
    isUploadingAvatar?: boolean;
    userAvatarUrl?: string;
    userBasicInfo?: UserBasicInfo | null;
}
import router from "@ohos:router";
import promptAction from "@ohos:promptAction";
import picker from "@ohos:file.picker";
import fs from "@ohos:file.fs";
import image from "@ohos:multimedia.image";
import type { ImageItem, PageRequest } from '../models/Image';
import { ApiService } from "@normalized:N&&&entry/src/main/ets/services/ApiService&";
import { HttpService } from "@normalized:N&&&entry/src/main/ets/services/HttpService&";
import type { UserBasicInfo } from '../models/User';
import { Colors } from "@normalized:N&&&entry/src/main/ets/common/Colors&";
import { BottomNavBar } from "@normalized:N&&&entry/src/main/ets/common/BottomNavBar&";
import { UserState } from "@normalized:N&&&entry/src/main/ets/services/UserState&";
/** 图片摘要信息接口 */
interface ImageSummary {
    id: number;
    name: string;
}
/** 图片列表项接口 */
interface ImageListItem {
    id: number;
    name: string;
}
/** 图片数量响应数据接口 */
interface ImageCountData {
    number: number;
}
class ProfilePage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__myImages = new ObservedPropertyObjectPU([], this, "myImages");
        this.__imageCount = new ObservedPropertySimplePU(0, this, "imageCount");
        this.__isLoading = new ObservedPropertySimplePU(false, this, "isLoading");
        this.__isRefreshing = new ObservedPropertySimplePU(false, this, "isRefreshing");
        this.__currentPage = new ObservedPropertySimplePU(1, this, "currentPage");
        this.__hasMore = new ObservedPropertySimplePU(true, this, "hasMore");
        this.__isLoggedIn = new ObservedPropertySimplePU(false, this, "isLoggedIn");
        this.__currentUsername = new ObservedPropertySimplePU('我', this, "currentUsername");
        this.__currentUserAccount = new ObservedPropertySimplePU('', this, "currentUserAccount");
        this.__currentTab = new ObservedPropertySimplePU('works', this, "currentTab");
        this.__favoriteCount = new ObservedPropertySimplePU(0, this, "favoriteCount");
        this.__historyCount = new ObservedPropertySimplePU(0, this, "historyCount");
        this.__userAvatar = new ObservedPropertyObjectPU(null, this, "userAvatar");
        this.__isUploadingAvatar = new ObservedPropertySimplePU(false, this, "isUploadingAvatar");
        this.__userAvatarUrl = new ObservedPropertySimplePU('', this, "userAvatarUrl");
        this.__userBasicInfo = new ObservedPropertyObjectPU(null, this, "userBasicInfo");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ProfilePage_Params) {
        if (params.myImages !== undefined) {
            this.myImages = params.myImages;
        }
        if (params.imageCount !== undefined) {
            this.imageCount = params.imageCount;
        }
        if (params.isLoading !== undefined) {
            this.isLoading = params.isLoading;
        }
        if (params.isRefreshing !== undefined) {
            this.isRefreshing = params.isRefreshing;
        }
        if (params.currentPage !== undefined) {
            this.currentPage = params.currentPage;
        }
        if (params.hasMore !== undefined) {
            this.hasMore = params.hasMore;
        }
        if (params.isLoggedIn !== undefined) {
            this.isLoggedIn = params.isLoggedIn;
        }
        if (params.currentUsername !== undefined) {
            this.currentUsername = params.currentUsername;
        }
        if (params.currentUserAccount !== undefined) {
            this.currentUserAccount = params.currentUserAccount;
        }
        if (params.currentTab !== undefined) {
            this.currentTab = params.currentTab;
        }
        if (params.favoriteCount !== undefined) {
            this.favoriteCount = params.favoriteCount;
        }
        if (params.historyCount !== undefined) {
            this.historyCount = params.historyCount;
        }
        if (params.userAvatar !== undefined) {
            this.userAvatar = params.userAvatar;
        }
        if (params.isUploadingAvatar !== undefined) {
            this.isUploadingAvatar = params.isUploadingAvatar;
        }
        if (params.userAvatarUrl !== undefined) {
            this.userAvatarUrl = params.userAvatarUrl;
        }
        if (params.userBasicInfo !== undefined) {
            this.userBasicInfo = params.userBasicInfo;
        }
    }
    updateStateVars(params: ProfilePage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__myImages.purgeDependencyOnElmtId(rmElmtId);
        this.__imageCount.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoading.purgeDependencyOnElmtId(rmElmtId);
        this.__isRefreshing.purgeDependencyOnElmtId(rmElmtId);
        this.__currentPage.purgeDependencyOnElmtId(rmElmtId);
        this.__hasMore.purgeDependencyOnElmtId(rmElmtId);
        this.__isLoggedIn.purgeDependencyOnElmtId(rmElmtId);
        this.__currentUsername.purgeDependencyOnElmtId(rmElmtId);
        this.__currentUserAccount.purgeDependencyOnElmtId(rmElmtId);
        this.__currentTab.purgeDependencyOnElmtId(rmElmtId);
        this.__favoriteCount.purgeDependencyOnElmtId(rmElmtId);
        this.__historyCount.purgeDependencyOnElmtId(rmElmtId);
        this.__userAvatar.purgeDependencyOnElmtId(rmElmtId);
        this.__isUploadingAvatar.purgeDependencyOnElmtId(rmElmtId);
        this.__userAvatarUrl.purgeDependencyOnElmtId(rmElmtId);
        this.__userBasicInfo.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__myImages.aboutToBeDeleted();
        this.__imageCount.aboutToBeDeleted();
        this.__isLoading.aboutToBeDeleted();
        this.__isRefreshing.aboutToBeDeleted();
        this.__currentPage.aboutToBeDeleted();
        this.__hasMore.aboutToBeDeleted();
        this.__isLoggedIn.aboutToBeDeleted();
        this.__currentUsername.aboutToBeDeleted();
        this.__currentUserAccount.aboutToBeDeleted();
        this.__currentTab.aboutToBeDeleted();
        this.__favoriteCount.aboutToBeDeleted();
        this.__historyCount.aboutToBeDeleted();
        this.__userAvatar.aboutToBeDeleted();
        this.__isUploadingAvatar.aboutToBeDeleted();
        this.__userAvatarUrl.aboutToBeDeleted();
        this.__userBasicInfo.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __myImages: ObservedPropertyObjectPU<ImageItem[]>;
    get myImages() {
        return this.__myImages.get();
    }
    set myImages(newValue: ImageItem[]) {
        this.__myImages.set(newValue);
    }
    private __imageCount: ObservedPropertySimplePU<number>;
    get imageCount() {
        return this.__imageCount.get();
    }
    set imageCount(newValue: number) {
        this.__imageCount.set(newValue);
    }
    private __isLoading: ObservedPropertySimplePU<boolean>;
    get isLoading() {
        return this.__isLoading.get();
    }
    set isLoading(newValue: boolean) {
        this.__isLoading.set(newValue);
    }
    private __isRefreshing: ObservedPropertySimplePU<boolean>;
    get isRefreshing() {
        return this.__isRefreshing.get();
    }
    set isRefreshing(newValue: boolean) {
        this.__isRefreshing.set(newValue);
    }
    private __currentPage: ObservedPropertySimplePU<number>;
    get currentPage() {
        return this.__currentPage.get();
    }
    set currentPage(newValue: number) {
        this.__currentPage.set(newValue);
    }
    private __hasMore: ObservedPropertySimplePU<boolean>;
    get hasMore() {
        return this.__hasMore.get();
    }
    set hasMore(newValue: boolean) {
        this.__hasMore.set(newValue);
    }
    private __isLoggedIn: ObservedPropertySimplePU<boolean>;
    get isLoggedIn() {
        return this.__isLoggedIn.get();
    }
    set isLoggedIn(newValue: boolean) {
        this.__isLoggedIn.set(newValue);
    }
    private __currentUsername: ObservedPropertySimplePU<string>;
    get currentUsername() {
        return this.__currentUsername.get();
    }
    set currentUsername(newValue: string) {
        this.__currentUsername.set(newValue);
    }
    private __currentUserAccount: ObservedPropertySimplePU<string>;
    get currentUserAccount() {
        return this.__currentUserAccount.get();
    }
    set currentUserAccount(newValue: string) {
        this.__currentUserAccount.set(newValue);
    }
    private __currentTab: ObservedPropertySimplePU<string>; // 'works'、'favorites' 或 'history'
    get currentTab() {
        return this.__currentTab.get();
    }
    set currentTab(newValue: string) {
        this.__currentTab.set(newValue);
    }
    private __favoriteCount: ObservedPropertySimplePU<number>;
    get favoriteCount() {
        return this.__favoriteCount.get();
    }
    set favoriteCount(newValue: number) {
        this.__favoriteCount.set(newValue);
    }
    private __historyCount: ObservedPropertySimplePU<number>;
    get historyCount() {
        return this.__historyCount.get();
    }
    set historyCount(newValue: number) {
        this.__historyCount.set(newValue);
    }
    private __userAvatar: ObservedPropertyObjectPU<image.PixelMap | null>;
    get userAvatar() {
        return this.__userAvatar.get();
    }
    set userAvatar(newValue: image.PixelMap | null) {
        this.__userAvatar.set(newValue);
    }
    private __isUploadingAvatar: ObservedPropertySimplePU<boolean>;
    get isUploadingAvatar() {
        return this.__isUploadingAvatar.get();
    }
    set isUploadingAvatar(newValue: boolean) {
        this.__isUploadingAvatar.set(newValue);
    }
    private __userAvatarUrl: ObservedPropertySimplePU<string>; // 服务器返回的头像URL
    get userAvatarUrl() {
        return this.__userAvatarUrl.get();
    }
    set userAvatarUrl(newValue: string) {
        this.__userAvatarUrl.set(newValue);
    }
    private __userBasicInfo: ObservedPropertyObjectPU<UserBasicInfo | null>; // 用户基本信息
    get userBasicInfo() {
        return this.__userBasicInfo.get();
    }
    set userBasicInfo(newValue: UserBasicInfo | null) {
        this.__userBasicInfo.set(newValue);
    }
    /**
     * 去掉文件后缀，只显示图片名称
     */
    private getDisplayImageName(imageName: string): string {
        if (!imageName)
            return '';
        // 找到最后一个点的位置
        const lastDotIndex = imageName.lastIndexOf('.');
        if (lastDotIndex === -1) {
            // 没有后缀，直接返回
            return imageName;
        }
        // 返回点之前的部分
        return imageName.substring(0, lastDotIndex);
    }
    aboutToAppear() {
        this.loadUserBasicInfo(); // 使用新的用户基本信息API
        this.loadMyImages(true);
        this.loadFavoriteCount();
        this.loadHistoryCount();
        // 监听用户状态变化
        UserState.addListener((userInfo) => {
            if (userInfo && userInfo.headshotUrl) {
                this.userAvatarUrl = userInfo.headshotUrl;
                console.log('用户头像URL更新:', this.userAvatarUrl);
            }
        });
        // 初始化时获取用户头像URL
        const userInfo = UserState.getUserInfo();
        if (userInfo && userInfo.headshotUrl) {
            this.userAvatarUrl = userInfo.headshotUrl;
            console.log('页面初始化时设置头像URL:', this.userAvatarUrl);
        }
    }
    onPageShow() {
        // 页面显示时重新加载用户信息和当前标签页数据，确保从详情页返回时数据是最新的
        console.log('ProfilePage onPageShow - 重新加载用户信息和数据');
        // 先检查全局状态中是否有头像URL
        const userInfo = UserState.getUserInfo();
        if (userInfo && userInfo.headshotUrl) {
            this.userAvatarUrl = userInfo.headshotUrl;
            console.log('页面显示时使用全局状态中的头像URL:', this.userAvatarUrl);
        }
        // 加载用户基本信息
        this.loadUserBasicInfo();
        // 根据当前标签页重新加载数据
        if (this.currentTab === 'works') {
            this.loadMyImages(true);
        }
        else if (this.currentTab === 'favorites') {
            this.loadFavorites(true);
        }
        else if (this.currentTab === 'history') {
            this.loadHistory(true);
        }
    }
    /**
     * 加载用户基本信息
     */
    async loadUserBasicInfo() {
        try {
            // 先检查是否有token
            const token = await HttpService.getToken();
            console.log('检查用户登录状态，token:', token ? '存在' : '不存在');
            if (!token) {
                this.isLoggedIn = false;
                this.imageCount = 0;
                this.currentUsername = '我';
                this.currentUserAccount = 'user@example.com';
                return;
            }
            // 有token，设置为已登录状态
            this.isLoggedIn = true;
            console.log('开始获取用户基本信息');
            const response = await ApiService.getUserBasicInformation();
            console.log('获取用户基本信息响应:', JSON.stringify(response, null, 2));
            if (response.code === 1 && response.data) {
                this.userBasicInfo = response.data;
                console.log('用户基本信息获取成功:', this.userBasicInfo);
                // 更新用户名和头像
                if (response.data.username) {
                    this.currentUsername = response.data.username;
                }
                if (response.data.headshotUrl) {
                    // 构建完整的头像URL
                    const baseUrl = HttpService.getBaseUrl();
                    this.userAvatarUrl = `${baseUrl}/images/${response.data.headshotUrl}`;
                    console.log('用户头像URL:', this.userAvatarUrl);
                    // 更新全局用户状态
                    const userInfo = UserState.getUserInfo();
                    if (userInfo) {
                        userInfo.headshotUrl = this.userAvatarUrl;
                        userInfo.username = response.data.username;
                        UserState.setUserInfo(userInfo);
                    }
                }
                // 更新用户账号（使用email字段）
                if (response.data.email) {
                    this.currentUserAccount = response.data.email;
                }
                // 获取用户图片数量
                try {
                    console.log('开始获取用户图片数量');
                    const imageCountResponse = await ApiService.getMyImageCount();
                    console.log('获取图片数量响应:', JSON.stringify(imageCountResponse, null, 2));
                    if (imageCountResponse.code === 1) {
                        // 后端返回的数据结构是 {number: 2}，需要提取number字段
                        if (imageCountResponse.data && typeof imageCountResponse.data === 'object') {
                            const data = imageCountResponse.data as ImageCountData;
                            this.imageCount = data.number || 0;
                        }
                        else {
                            this.imageCount = 0;
                        }
                        console.log('用户已登录，图片数量:', this.imageCount);
                    }
                    else {
                        this.imageCount = 0;
                        console.error('获取图片数量失败，响应码:', imageCountResponse.code, '消息:', imageCountResponse.msg);
                    }
                }
                catch (imageCountError) {
                    console.error('获取图片数量失败:', imageCountError);
                    this.imageCount = 0;
                }
            }
            else {
                console.error('获取用户基本信息失败，响应码:', response.code, '消息:', response.msg);
                // 即使获取用户信息失败，也保持登录状态
                console.log('保持登录状态，使用默认用户信息');
            }
        }
        catch (error) {
            console.error('获取用户基本信息失败:', error);
            // 只有在没有token的情况下才设置为未登录
            const token = await HttpService.getToken();
            if (!token) {
                this.isLoggedIn = false;
                this.imageCount = 0;
            }
        }
    }
    /**
     * 加载用户信息
     */
    async loadUserInfo() {
        try {
            // 先检查是否有token
            const token = await HttpService.getToken();
            console.log('检查用户登录状态，token:', token ? '存在' : '不存在');
            if (!token) {
                this.isLoggedIn = false;
                this.imageCount = 0;
                this.currentUsername = '我';
                this.currentUserAccount = 'user@example.com';
                return;
            }
            // 有token，尝试获取用户信息
            this.isLoggedIn = true; // 先设置为已登录状态
            try {
                // 先获取用户基本信息
                console.log('开始获取用户信息');
                const userInfoResponse = await ApiService.getUserInfo();
                console.log('获取用户信息响应:', JSON.stringify(userInfoResponse, null, 2));
                if (userInfoResponse.code === 1 && userInfoResponse.data) {
                    // 设置真实用户信息
                    this.currentUsername = userInfoResponse.data.username || '我';
                    this.currentUserAccount = userInfoResponse.data.userAccount || 'user@example.com';
                    // 更新全局用户状态
                    UserState.setUserInfo(userInfoResponse.data);
                    // 如果服务器返回了头像URL且本地没有设置，则更新本地状态
                    if (userInfoResponse.data.headshotUrl && !this.userAvatarUrl) {
                        this.userAvatarUrl = userInfoResponse.data.headshotUrl;
                        console.log('从服务器获取到头像URL:', this.userAvatarUrl);
                    }
                    else if (userInfoResponse.data.headshotUrl) {
                        console.log('本地已有头像URL，保持当前设置:', this.userAvatarUrl);
                    }
                    console.log('用户信息获取成功:', this.currentUsername, this.currentUserAccount);
                }
                else {
                    // 如果获取用户信息失败，使用默认值
                    this.currentUsername = '我';
                    this.currentUserAccount = 'user@example.com';
                    console.log('使用默认用户信息');
                }
            }
            catch (userInfoError) {
                console.error('获取用户信息失败:', userInfoError);
                // 即使获取用户信息失败，也保持登录状态
                this.currentUsername = '我';
                this.currentUserAccount = 'user@example.com';
            }
            try {
                // 获取用户图片数量
                console.log('开始获取用户图片数量');
                const response = await ApiService.getMyImageCount();
                console.log('获取图片数量响应:', JSON.stringify(response, null, 2));
                if (response.code === 1) {
                    // 后端返回的数据结构是 {number: 2}，需要提取number字段
                    if (response.data && typeof response.data === 'object') {
                        const data = response.data as ImageCountData;
                        this.imageCount = data.number || 0;
                    }
                    else {
                        this.imageCount = 0;
                    }
                    console.log('用户已登录，图片数量:', this.imageCount);
                }
                else {
                    this.imageCount = 0;
                    console.error('获取图片数量失败，响应码:', response.code, '消息:', response.msg);
                }
            }
            catch (imageCountError) {
                console.error('获取图片数量失败:', imageCountError);
                this.imageCount = 0;
            }
        }
        catch (error) {
            console.error('加载用户信息失败:', error);
            // 只有在没有token的情况下才设置为未登录
            const token = await HttpService.getToken();
            if (!token) {
                this.isLoggedIn = false;
                this.imageCount = 0;
            }
        }
    }
    /**
     * 加载我的图片
     */
    async loadMyImages(refresh: boolean = false) {
        if (refresh) {
            this.currentPage = 1;
            this.myImages = [];
            this.hasMore = true;
        }
        this.isLoading = true;
        try {
            const request: PageRequest = {
                page: this.currentPage,
                size: 50
            };
            console.log('开始加载我的图片，请求参数:', request);
            const response = await ApiService.getMyImages(request);
            console.log('获取我的图片响应:', JSON.stringify(response, null, 2));
            if (response.code === 1) {
                // 后端返回的是直接数组，不是分页对象
                if (Array.isArray(response.data)) {
                    const imageList = response.data as ImageItem[];
                    console.log('图片数据:', JSON.stringify(imageList, null, 2));
                    console.log('图片记录数:', imageList?.length || 0);
                    if (refresh) {
                        this.myImages = imageList || [];
                    }
                    else {
                        this.myImages = [...this.myImages, ...(imageList || [])];
                    }
                    // 由于后端返回的是简单数组，没有分页信息，所以设置hasMore为false
                    this.hasMore = false;
                    console.log('最终图片列表长度:', this.myImages.length);
                    console.log('图片列表:', this.myImages.map(img => {
                        const summary: ImageSummary = { id: img.imageId, name: img.imageName };
                        return summary;
                    }));
                }
                else {
                    console.error('后端返回的数据不是数组格式:', response.data);
                    this.myImages = [];
                    this.hasMore = false;
                }
            }
            else {
                console.error('获取我的图片失败，响应码:', response.code, '消息:', response.msg);
                console.error('完整响应:', JSON.stringify(response, null, 2));
            }
        }
        catch (error) {
            console.error('加载我的图片失败:', error);
        }
        finally {
            this.isLoading = false;
        }
    }
    /**
     * 刷新数据
     */
    async refreshData() {
        this.isRefreshing = true;
        try {
            await this.loadUserBasicInfo(); // 使用正确的用户基本信息API
            if (this.currentTab === 'works') {
                await this.loadMyImages(true);
            }
            else if (this.currentTab === 'favorites') {
                await this.loadFavorites(true);
            }
            else if (this.currentTab === 'history') {
                await this.loadHistory(true);
            }
        }
        finally {
            this.isRefreshing = false;
        }
    }
    /**
     * 加载更多
     */
    loadMore() {
        if (this.hasMore && !this.isLoading) {
            this.currentPage++;
            if (this.currentTab === 'works') {
                this.loadMyImages();
            }
            else if (this.currentTab === 'favorites') {
                this.loadFavorites();
            }
            else if (this.currentTab === 'history') {
                this.loadHistory();
            }
        }
    }
    /**
     * 跳转到登录页�?
     */
    navigateToLogin() {
        router.pushUrl({ url: 'pages/LoginPage' });
    }
    /**
     * 跳转到上传页�?
     */
    navigateToUpload() {
        router.pushUrl({ url: 'pages/UploadPage' });
    }
    /**
     * 返回
     */
    goBack() {
        router.back();
    }
    /**
     * 点赞/取消点赞
     */
    async toggleLike(image: ImageItem) {
        try {
            const response = await ApiService.toggleLike(image.imageId);
            if (response.code === 1) {
                // 更新本地状态
                const index = this.myImages.findIndex((img: ImageItem) => img.imageId === image.imageId);
                if (index !== -1) {
                    // isLike 是数字类型：1=已点赞，0=未点赞
                    this.myImages[index].isLike = this.myImages[index].isLike === 1 ? 0 : 1;
                    this.myImages[index].imageLike = (this.myImages[index].imageLike || 0) + (this.myImages[index].isLike === 1 ? 1 : -1);
                }
            }
        }
        catch (error) {
            console.error('点赞失败:', error);
        }
    }
    /**
     * 加载收藏数量
     */
    async loadFavoriteCount() {
        try {
            // 使用收藏列表API获取真实的收藏数量
            const response = await ApiService.getBookmarkList();
            if (response.code === 1 && response.data) {
                this.favoriteCount = response.data.length || 0;
            }
            else {
                this.favoriteCount = 0;
            }
        }
        catch (error) {
            console.error('加载收藏数量失败:', error);
            this.favoriteCount = 0;
        }
    }
    /**
     * 加载浏览记录数量
     */
    async loadHistoryCount() {
        try {
            // 使用浏览记录API获取真实的浏览记录数量
            const response = await ApiService.getBrowsingHistoryList();
            if (response.code === 1 && response.data) {
                this.historyCount = response.data.length || 0;
            }
            else {
                this.historyCount = 0;
            }
        }
        catch (error) {
            console.error('加载浏览记录数量失败:', error);
            this.historyCount = 0;
        }
    }
    /**
     * 加载收藏列表
     */
    async loadFavorites(refresh: boolean = false) {
        if (refresh) {
            this.currentPage = 1;
            this.hasMore = true;
            this.myImages = [];
        }
        if (!this.hasMore || this.isLoading) {
            return;
        }
        this.isLoading = true;
        try {
            console.log('开始加载收藏列表...');
            const response = await ApiService.getBookmarkList();
            console.log('收藏列表API响应:', JSON.stringify(response, null, 2));
            if (response.code === 1 && response.data) {
                const newImages: ImageItem[] = response.data || [];
                console.log('收藏列表数据:', JSON.stringify(newImages, null, 2));
                // 检查每个图片的imageUrl
                newImages.forEach((image, index) => {
                    console.log(`收藏图片 ${index}:`, {
                        imageId: image.imageId,
                        imageName: image.imageName,
                        imageUrl: image.imageUrl,
                        hasImageUrl: !!image.imageUrl
                    });
                });
                if (refresh) {
                    this.myImages = newImages;
                }
                else {
                    this.myImages = this.myImages.concat(newImages);
                }
                // 更新收藏数量
                this.favoriteCount = newImages.length;
                this.hasMore = false; // 收藏列表通常不需要分页
                console.log('收藏列表加载完成，数量:', this.myImages.length);
            }
            else {
                console.error('收藏列表API失败，响应码:', response.code, '错误信息:', response.msg);
            }
        }
        catch (error) {
            console.error('加载收藏失败:', error);
        }
        finally {
            this.isLoading = false;
            this.isRefreshing = false;
        }
    }
    /**
     * 加载浏览记录列表
     */
    async loadHistory(refresh: boolean = false) {
        if (refresh) {
            this.currentPage = 1;
            this.hasMore = true;
            this.myImages = [];
        }
        if (!this.hasMore || this.isLoading) {
            return;
        }
        this.isLoading = true;
        try {
            const response = await ApiService.getBrowsingHistoryList();
            if (response.code === 1 && response.data) {
                const newImages: ImageItem[] = response.data || [];
                if (refresh) {
                    this.myImages = newImages;
                }
                else {
                    this.myImages = this.myImages.concat(newImages);
                }
                // 更新浏览记录数量
                this.historyCount = newImages.length;
                this.hasMore = false; // 浏览记录列表通常不需要分页
            }
        }
        catch (error) {
            console.error('加载浏览记录失败:', error);
        }
        finally {
            this.isLoading = false;
            this.isRefreshing = false;
        }
    }
    /**
     * 退出登�?
     */
    /**
     * 选择头像
     */
    async selectAvatar() {
        try {
            const photoSelectOptions = new picker.PhotoSelectOptions();
            photoSelectOptions.MIMEType = picker.PhotoViewMIMETypes.IMAGE_TYPE;
            photoSelectOptions.maxSelectNumber = 1;
            const photoPicker = new picker.PhotoViewPicker();
            const photoSelectResult = await photoPicker.select(photoSelectOptions);
            if (photoSelectResult.photoUris && photoSelectResult.photoUris.length > 0) {
                const selectedImagePath = photoSelectResult.photoUris[0];
                console.log('选择的头像路径:', selectedImagePath);
                // 加载预览图片
                await this.loadAvatarPreview(selectedImagePath);
                // 上传头像
                await this.uploadAvatar(selectedImagePath);
            }
        }
        catch (error) {
            console.error('选择头像失败:', error);
            promptAction.showToast({ message: '选择头像失败' });
        }
    }
    /**
     * 加载头像预览
     */
    async loadAvatarPreview(imagePath: string) {
        try {
            const file = fs.openSync(imagePath, fs.OpenMode.READ_ONLY);
            const imageSource = image.createImageSource(file.fd);
            this.userAvatar = await imageSource.createPixelMap();
            fs.closeSync(file);
        }
        catch (error) {
            console.error('加载头像预览失败:', error);
        }
    }
    /**
     * 上传头像
     */
    async uploadAvatar(imagePath: string) {
        this.isUploadingAvatar = true;
        try {
            // 提取文件名
            const fileName = imagePath.split('/').pop() || 'avatar.jpg';
            console.log('开始上传头像，文件路径:', imagePath, '文件名:', fileName);
            const response = await ApiService.uploadUserAvatar(imagePath, fileName);
            console.log('头像上传响应:', response);
            if (response.code === 1) {
                promptAction.showToast({ message: '头像上传成功' });
                console.log('头像上传成功');
                // 直接使用服务器返回的头像URL
                if (response.data && typeof response.data === 'string') {
                    this.userAvatarUrl = response.data;
                    console.log('使用服务器返回的头像URL:', this.userAvatarUrl);
                    // 更新全局用户状态中的头像URL
                    const userInfo = UserState.getUserInfo();
                    if (userInfo) {
                        userInfo.headshotUrl = response.data;
                        UserState.setUserInfo(userInfo);
                        console.log('更新全局用户状态中的头像URL');
                    }
                    // 更新本地用户基本信息中的头像URL
                    if (this.userBasicInfo) {
                        this.userBasicInfo.headshotUrl = response.data;
                        console.log('更新本地用户基本信息中的头像URL');
                    }
                }
                else {
                    console.log('服务器返回的数据格式不正确:', response.data);
                    // 如果服务器没有返回正确的头像URL，使用本地选择的头像作为临时显示
                    console.log('使用本地头像作为临时显示');
                }
            }
            else {
                console.error('头像上传失败，响应码:', response.code, '错误信息:', response.msg);
                promptAction.showToast({ message: response.msg || '头像上传失败' });
            }
        }
        catch (error) {
            console.error('头像上传异常:', error);
            if (error instanceof Error) {
                promptAction.showToast({ message: `头像上传失败: ${error.message}` });
            }
            else {
                promptAction.showToast({ message: '头像上传失败，请检查网络连接' });
            }
        }
        finally {
            this.isUploadingAvatar = false;
        }
    }
    /**
     * 删除图片
     */
    async deleteImage(image: ImageItem) {
        promptAction.showDialog({
            title: '确认删除',
            message: `确定要删除图片"${image.imageName}"吗？此操作不可撤销。`,
            buttons: [
                { text: '取消', color: '#999999' },
                { text: '删除', color: '#FF4444' }
            ]
        }).then(async (result) => {
            if (result.index === 1) {
                try {
                    console.log('图片对象:', JSON.stringify(image, null, 2));
                    // console.log('当前用户图片列表:', this.myImages.map(img => {
                    //   const item: ImageListItem = {id: img.imageId, name: img.imageName};
                    //   return item;
                    // }));
                    // console.log('要删除的图片是否在用户列表中:', this.myImages.some(img => img.imageId === image.imageId));
                    const response = await ApiService.deleteImage(image.imageId);
                    console.log('=== 删除图片响应 ===');
                    console.log('删除图片响应:', JSON.stringify(response, null, 2));
                    if (response.code === 1) {
                        // 从本地列表中移除图片
                        this.myImages = this.myImages.filter(img => img.imageId !== image.imageId);
                        // 更新图片数量
                        this.imageCount = Math.max(0, this.imageCount - 1);
                        promptAction.showToast({ message: '图片删除成功' });
                        console.log('图片删除成功，当前图片数量:', this.imageCount);
                    }
                    else {
                        console.error('删除图片失败，响应码:', response.code, '消息:', response.msg);
                        console.error('完整响应:', JSON.stringify(response, null, 2));
                        promptAction.showToast({ message: `删除失败: ${response.msg || '未知错误'}` });
                    }
                }
                catch (error) {
                    console.error('=== 删除图片异常 ===');
                    console.error('删除图片异常:', error);
                    console.error('错误类型:', typeof error);
                    console.error('错误构造函数:', error.constructor.name);
                    // 尝试获取错误的各种属性
                    if (error && typeof error === 'object') {
                        console.error('错误属性:', Object.keys(error));
                        console.error('错误消息属性:', error.message);
                        console.error('错误名称:', error.name);
                        console.error('错误堆栈:', error.stack);
                        // 尝试手动序列化错误对象
                        try {
                            const errorStr = JSON.stringify(error, Object.getOwnPropertyNames(error), 2);
                            console.error('序列化错误对象:', errorStr);
                        }
                        catch (stringifyError) {
                            console.error('无法序列化错误对象:', stringifyError);
                        }
                    }
                    // 显示更具体的错误信息
                    let errorMessage = '未知错误';
                    if (error && typeof error === 'object') {
                        const errorObj = error as Error;
                        if (errorObj.message) {
                            errorMessage = errorObj.message;
                        }
                        else if (errorObj.toString) {
                            errorMessage = errorObj.toString();
                        }
                    }
                    // 尝试使用String()转换
                    console.error('错误字符串表示:', String(error));
                    console.error('最终错误消息:', errorMessage);
                    promptAction.showToast({ message: `删除失败: ${errorMessage}` });
                }
            }
        });
    }
    async logout() {
        promptAction.showDialog({
            title: '确认退出',
            message: '确定要退出登录吗?',
            buttons: [
                { text: '取消', color: '#999999' },
                { text: '确定', color: '#FF4444' }
            ]
        }).then(async (result) => {
            if (result.index === 1) {
                // 清除本地存储的用户信息
                await HttpService.clearToken();
                this.isLoggedIn = false;
                this.myImages = [];
                this.imageCount = 0;
                promptAction.showToast({ message: '已退出登录' });
                // 跳转到登录页面
                router.replaceUrl({ url: 'pages/LoginPage' });
            }
        });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(763:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.linearGradient({
                direction: GradientDirection.Bottom,
                colors: [
                    ['#E8F5E8', 0.0],
                    ['#F0F8F0', 0.3],
                    ['#F8FCF8', 0.7],
                    ['#FFFFFF', 1.0]
                ]
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 顶部导航
            if (this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户信息卡片 - 更大更好看的样式
                        Column.create({ space: 20 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(767:9)", "entry");
                        // 用户信息卡片 - 更大更好看的样式
                        Column.width('100%');
                        // 用户信息卡片 - 更大更好看的样式
                        Column.padding({ left: 20, right: 20, top: 24, bottom: 24 });
                        // 用户信息卡片 - 更大更好看的样式
                        Column.backgroundColor(Color.White);
                        // 用户信息卡片 - 更大更好看的样式
                        Column.borderRadius(20);
                        // 用户信息卡片 - 更大更好看的样式
                        Column.margin({ left: 16, right: 16, top: 16, bottom: 16 });
                        // 用户信息卡片 - 更大更好看的样式
                        Column.shadow({ radius: 12, color: '#1A000000', offsetX: 0, offsetY: 4 });
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Row.create({ space: 20 });
                        Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(768:11)", "entry");
                        Row.width('100%');
                        Row.alignItems(VerticalAlign.Center);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户头像 - 更大
                        Stack.create();
                        Stack.debugLine("entry/src/main/ets/pages/ProfilePage.ets(770:13)", "entry");
                        // 用户头像 - 更大
                        Stack.width(80);
                        // 用户头像 - 更大
                        Stack.height(80);
                        // 用户头像 - 更大
                        Stack.onClick(() => {
                            if (!this.isUploadingAvatar) {
                                this.selectAvatar();
                            }
                        });
                    }, Stack);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.userAvatarUrl) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 优先显示服务器返回的头像URL
                                    Image.create(this.userAvatarUrl);
                                    Image.debugLine("entry/src/main/ets/pages/ProfilePage.ets(773:17)", "entry");
                                    // 优先显示服务器返回的头像URL
                                    Image.width(80);
                                    // 优先显示服务器返回的头像URL
                                    Image.height(80);
                                    // 优先显示服务器返回的头像URL
                                    Image.borderRadius(40);
                                    // 优先显示服务器返回的头像URL
                                    Image.objectFit(ImageFit.Cover);
                                    // 优先显示服务器返回的头像URL
                                    Image.shadow({ radius: 8, color: '#1A000000', offsetX: 0, offsetY: 2 });
                                }, Image);
                            });
                        }
                        else if (this.userAvatar) {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 显示本地选择的头像
                                    Image.create(this.userAvatar);
                                    Image.debugLine("entry/src/main/ets/pages/ProfilePage.ets(781:17)", "entry");
                                    // 显示本地选择的头像
                                    Image.width(80);
                                    // 显示本地选择的头像
                                    Image.height(80);
                                    // 显示本地选择的头像
                                    Image.borderRadius(40);
                                    // 显示本地选择的头像
                                    Image.objectFit(ImageFit.Cover);
                                    // 显示本地选择的头像
                                    Image.shadow({ radius: 8, color: '#1A000000', offsetX: 0, offsetY: 2 });
                                }, Image);
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(2, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 显示默认头像
                                    Image.create({ "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
                                    Image.debugLine("entry/src/main/ets/pages/ProfilePage.ets(789:17)", "entry");
                                    // 显示默认头像
                                    Image.width(80);
                                    // 显示默认头像
                                    Image.height(80);
                                    // 显示默认头像
                                    Image.borderRadius(40);
                                    // 显示默认头像
                                    Image.objectFit(ImageFit.Cover);
                                    // 显示默认头像
                                    Image.shadow({ radius: 8, color: '#1A000000', offsetX: 0, offsetY: 2 });
                                }, Image);
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 上传状态指示器
                        if (this.isUploadingAvatar) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Column.create();
                                    Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(799:17)", "entry");
                                    Column.width(80);
                                    Column.height(80);
                                    Column.borderRadius(40);
                                    Column.backgroundColor('#80000000');
                                    Column.justifyContent(FlexAlign.Center);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    LoadingProgress.create();
                                    LoadingProgress.debugLine("entry/src/main/ets/pages/ProfilePage.ets(800:19)", "entry");
                                    LoadingProgress.width(20);
                                    LoadingProgress.height(20);
                                    LoadingProgress.color(Color.White);
                                }, LoadingProgress);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Text.create('上传中...');
                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(805:19)", "entry");
                                    Text.fontSize(10);
                                    Text.fontColor(Color.White);
                                    Text.margin({ top: 4 });
                                }, Text);
                                Text.pop();
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    // 用户头像 - 更大
                    Stack.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户信息 - 更大字体
                        Column.create({ space: 8 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(826:13)", "entry");
                        // 用户信息 - 更大字体
                        Column.alignItems(HorizontalAlign.Start);
                        // 用户信息 - 更大字体
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.currentUsername);
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(827:15)", "entry");
                        Text.fontSize(24);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Color.Black);
                        Text.alignSelf(ItemAlign.Start);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(this.currentUserAccount || 'user@example.com');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(833:15)", "entry");
                        Text.fontSize(16);
                        Text.fontColor(Colors.Black60);
                        Text.alignSelf(ItemAlign.Start);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户状态
                        Row.create({ space: 8 });
                        Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(839:15)", "entry");
                        // 用户状态
                        Row.alignSelf(ItemAlign.Start);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('●');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(840:17)", "entry");
                        Text.fontSize(12);
                        Text.fontColor('#4CAF50');
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('在线');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(844:17)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    // 用户状态
                    Row.pop();
                    // 用户信息 - 更大字体
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 退出按钮 - 更大更好看
                        Button.createWithLabel('退出');
                        Button.debugLine("entry/src/main/ets/pages/ProfilePage.ets(854:13)", "entry");
                        // 退出按钮 - 更大更好看
                        Button.width(60);
                        // 退出按钮 - 更大更好看
                        Button.height(36);
                        // 退出按钮 - 更大更好看
                        Button.backgroundColor('#FF4444');
                        // 退出按钮 - 更大更好看
                        Button.borderRadius(18);
                        // 退出按钮 - 更大更好看
                        Button.fontSize(14);
                        // 退出按钮 - 更大更好看
                        Button.fontColor(Color.White);
                        // 退出按钮 - 更大更好看
                        Button.onClick(() => this.logout());
                    }, Button);
                    // 退出按钮 - 更大更好看
                    Button.pop();
                    Row.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户统计信息
                        Row.create({ space: 24 });
                        Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(867:11)", "entry");
                        // 用户统计信息
                        Row.width('100%');
                        // 用户统计信息
                        Row.justifyContent(FlexAlign.SpaceEvenly);
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 4 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(868:13)", "entry");
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('作品');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(869:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.imageCount}`);
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(873:15)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Color.Black);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 4 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(880:13)", "entry");
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('收藏');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(881:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.favoriteCount}`);
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(885:15)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Color.Black);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Column.create({ space: 4 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(892:13)", "entry");
                        Column.alignItems(HorizontalAlign.Center);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('浏览');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(893:15)", "entry");
                        Text.fontSize(12);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create(`${this.historyCount}`);
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(897:15)", "entry");
                        Text.fontSize(18);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Color.Black);
                    }, Text);
                    Text.pop();
                    Column.pop();
                    // 用户统计信息
                    Row.pop();
                    // 用户信息卡片 - 更大更好看的样式
                    Column.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 作品/收藏/浏览记录切换
                        Row.create({ space: 0 });
                        Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(915:9)", "entry");
                        // 作品/收藏/浏览记录切换
                        Row.justifyContent(FlexAlign.Center);
                        // 作品/收藏/浏览记录切换
                        Row.width('100%');
                        // 作品/收藏/浏览记录切换
                        Row.backgroundColor(Color.White);
                        // 作品/收藏/浏览记录切换
                        Row.borderRadius({ topLeft: 20, topRight: 20 });
                        // 作品/收藏/浏览记录切换
                        Row.shadow({ radius: 8, color: '#1A000000', offsetX: 0, offsetY: -2 });
                    }, Row);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('我的作品');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(916:11)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(this.currentTab === 'works' ? FontWeight.Bold : FontWeight.Normal);
                        Text.fontColor(this.currentTab === 'works' ? '#4CAF50' : Colors.Black60);
                        Text.padding({ top: 12, bottom: 12, left: 20, right: 20 });
                        Text.onClick(() => {
                            this.currentTab = 'works';
                            this.loadMyImages(true);
                        });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('我的收藏');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(926:11)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(this.currentTab === 'favorites' ? FontWeight.Bold : FontWeight.Normal);
                        Text.fontColor(this.currentTab === 'favorites' ? '#4CAF50' : Colors.Black60);
                        Text.padding({ top: 12, bottom: 12, left: 20, right: 20 });
                        Text.onClick(() => {
                            this.currentTab = 'favorites';
                            this.loadFavorites(true);
                            this.loadFavoriteCount();
                        });
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('浏览记录');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(937:11)", "entry");
                        Text.fontSize(16);
                        Text.fontWeight(this.currentTab === 'history' ? FontWeight.Bold : FontWeight.Normal);
                        Text.fontColor(this.currentTab === 'history' ? '#4CAF50' : Colors.Black60);
                        Text.padding({ top: 12, bottom: 12, left: 20, right: 20 });
                        Text.onClick(() => {
                            this.currentTab = 'history';
                            this.loadHistory(true);
                            this.loadHistoryCount();
                        });
                    }, Text);
                    Text.pop();
                    // 作品/收藏/浏览记录切换
                    Row.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!this.isLoggedIn) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 未登录状�?
                        Column.create({ space: 24 });
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(957:9)", "entry");
                        // 未登录状�?
                        Column.justifyContent(FlexAlign.Center);
                        // 未登录状�?
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 用户头像
                        Image.create({ "id": 16777250, "type": 20000, params: [], "bundleName": "com.example.photosharing", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/pages/ProfilePage.ets(959:11)", "entry");
                        // 用户头像
                        Image.width(80);
                        // 用户头像
                        Image.height(80);
                        // 用户头像
                        Image.margin({ top: 60 });
                    }, Image);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('未登录');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(964:11)", "entry");
                        Text.fontSize(20);
                        Text.fontWeight(FontWeight.Bold);
                        Text.fontColor(Color.Black);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Text.create('登录后查看你的作品和收藏');
                        Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(969:11)", "entry");
                        Text.fontSize(14);
                        Text.fontColor(Colors.Black60);
                    }, Text);
                    Text.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Button.createWithLabel('立即登录');
                        Button.debugLine("entry/src/main/ets/pages/ProfilePage.ets(973:11)", "entry");
                        Button.width(200);
                        Button.height(40);
                        Button.backgroundColor('#4CAF50');
                        Button.borderRadius(20);
                        Button.fontSize(16);
                        Button.fontColor(Color.Black);
                        Button.onClick(() => this.navigateToLogin());
                        Button.margin({ top: 24 });
                    }, Button);
                    Button.pop();
                    // 未登录状�?
                    Column.pop();
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        // 已登录状态 - 内容区域
                        Column.create();
                        Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(987:9)", "entry");
                        // 已登录状态 - 内容区域
                        Column.layoutWeight(1);
                    }, Column);
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        if (this.currentTab === 'works') {
                            this.ifElseBranchUpdateFunction(0, () => {
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                            });
                        }
                    }, If);
                    If.pop();
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        If.create();
                        // 我的作品列表
                        if (this.myImages.length === 0 && !this.isLoading) {
                            this.ifElseBranchUpdateFunction(0, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 空状�?
                                    Column.create({ space: 16 });
                                    Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(997:13)", "entry");
                                    // 空状�?
                                    Column.justifyContent(FlexAlign.Center);
                                    // 空状�?
                                    Column.layoutWeight(1);
                                }, Column);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    if (this.currentTab === 'works') {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                // 我的作品空状态 - 显示图标
                                                Text.create('📭');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1000:17)", "entry");
                                                // 我的作品空状态 - 显示图标
                                                Text.fontSize(80);
                                                // 我的作品空状态 - 显示图标
                                                Text.opacity(0.6);
                                            }, Text);
                                            // 我的作品空状态 - 显示图标
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                // 我的作品空状态
                                                Text.create('还没有作品');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1004:17)", "entry");
                                                // 我的作品空状态
                                                Text.fontSize(16);
                                                // 我的作品空状态
                                                Text.fontColor(Colors.Black60);
                                            }, Text);
                                            // 我的作品空状态
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('快去上传你的第一张图片吧');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1008:17)", "entry");
                                                Text.fontSize(14);
                                                Text.fontColor(Colors.Black40);
                                            }, Text);
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Button.createWithLabel('上传图片');
                                                Button.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1012:17)", "entry");
                                                Button.width(120);
                                                Button.height(36);
                                                Button.backgroundColor('#4CAF50');
                                                Button.borderRadius(18);
                                                Button.fontSize(14);
                                                Button.fontColor(Color.Black);
                                                Button.onClick(() => this.navigateToUpload());
                                            }, Button);
                                            Button.pop();
                                        });
                                    }
                                    else if (this.currentTab === 'favorites') {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                // 我的收藏空状态
                                                Text.create('💖');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1022:17)", "entry");
                                                // 我的收藏空状态
                                                Text.fontSize(48);
                                                // 我的收藏空状态
                                                Text.opacity(0.3);
                                                // 我的收藏空状态
                                                Text.margin({ bottom: 16 });
                                            }, Text);
                                            // 我的收藏空状态
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('暂无收藏作品');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1027:17)", "entry");
                                                Text.fontSize(16);
                                                Text.fontColor(Colors.Black60);
                                                Text.margin({ bottom: 8 });
                                            }, Text);
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('去首页发现更多精彩内容吧');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1032:17)", "entry");
                                                Text.fontSize(14);
                                                Text.fontColor(Colors.Black40);
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(2, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                // 浏览记录空状态
                                                Text.create('👁️');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1037:17)", "entry");
                                                // 浏览记录空状态
                                                Text.fontSize(48);
                                                // 浏览记录空状态
                                                Text.opacity(0.3);
                                                // 浏览记录空状态
                                                Text.margin({ bottom: 16 });
                                            }, Text);
                                            // 浏览记录空状态
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('暂无浏览记录');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1042:17)", "entry");
                                                Text.fontSize(16);
                                                Text.fontColor(Colors.Black60);
                                                Text.margin({ bottom: 8 });
                                            }, Text);
                                            Text.pop();
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('去首页看看有什么新鲜内容');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1047:17)", "entry");
                                                Text.fontSize(14);
                                                Text.fontColor(Colors.Black40);
                                            }, Text);
                                            Text.pop();
                                        });
                                    }
                                }, If);
                                If.pop();
                                // 空状�?
                                Column.pop();
                            });
                        }
                        else {
                            this.ifElseBranchUpdateFunction(1, () => {
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    // 图片网格 - 添加刷新功能（适用于所有标签页）
                                    Refresh.create({ refreshing: this.isRefreshing });
                                    Refresh.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1056:13)", "entry");
                                    // 图片网格 - 添加刷新功能（适用于所有标签页）
                                    Refresh.layoutWeight(1);
                                    // 图片网格 - 添加刷新功能（适用于所有标签页）
                                    Refresh.onRefreshing(() => {
                                        this.refreshData();
                                    });
                                }, Refresh);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    Grid.create();
                                    Grid.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1057:15)", "entry");
                                    Grid.columnsTemplate('1fr 1fr');
                                    Grid.rowsGap(12);
                                    Grid.columnsGap(12);
                                    Grid.padding(16);
                                    Grid.onScrollIndex(() => {
                                        this.loadMore();
                                    });
                                }, Grid);
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    ForEach.create();
                                    const forEachItemGenFunction = (_item, index: number) => {
                                        const image = _item;
                                        {
                                            const itemCreation2 = (elmtId, isInitialRender) => {
                                                GridItem.create(() => { }, false);
                                                GridItem.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1059:19)", "entry");
                                            };
                                            const observedDeepRender = () => {
                                                this.observeComponentCreation2(itemCreation2, GridItem);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Column.create();
                                                    Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1060:21)", "entry");
                                                    Column.width('100%');
                                                    Column.backgroundColor(Colors.White10);
                                                    Column.borderRadius(12);
                                                    Column.padding(8);
                                                    Column.onClick(() => {
                                                        console.log('个人页点击图片进入详情，图片ID:', image.imageId);
                                                        console.log('ProfilePage 传递的参数 - imageId:', image.imageId);
                                                        console.log('ProfilePage 传递的参数 - isOwner: true');
                                                        router.pushUrl({
                                                            url: 'pages/ImageDetailPage',
                                                            params: {
                                                                imageId: image.imageId,
                                                                imageData: JSON.stringify(image),
                                                                isOwner: true
                                                            }
                                                        });
                                                    });
                                                }, Column);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    If.create();
                                                    // 图片
                                                    if (image.imageUrl) {
                                                        this.ifElseBranchUpdateFunction(0, () => {
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Image.create(image.imageUrl);
                                                                Image.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1063:25)", "entry");
                                                                Image.width('100%');
                                                                Image.height(200);
                                                                Image.borderRadius(12);
                                                                Image.objectFit(ImageFit.Cover);
                                                                Image.onClick(() => {
                                                                    // 跳转到图片详情页面，传递完整的图片数据
                                                                    console.log('点击图片，准备跳转到详情页面，图片ID:', image.imageId);
                                                                    console.log('ProfilePage 传递的参数 - imageId:', image.imageId);
                                                                    console.log('ProfilePage 传递的参数 - isOwner: true');
                                                                    router.pushUrl({
                                                                        url: 'pages/ImageDetailPage',
                                                                        params: {
                                                                            imageId: image.imageId,
                                                                            imageData: JSON.stringify(image),
                                                                            isOwner: true
                                                                        }
                                                                    }).then(() => {
                                                                        console.log('跳转成功');
                                                                    }).catch((error: Error) => {
                                                                        console.error('跳转失败:', error);
                                                                    });
                                                                });
                                                            }, Image);
                                                        });
                                                    }
                                                    else {
                                                        this.ifElseBranchUpdateFunction(1, () => {
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                // 如果没有imageUrl，显示占位符
                                                                Column.create();
                                                                Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1088:25)", "entry");
                                                                // 如果没有imageUrl，显示占位符
                                                                Column.width('100%');
                                                                // 如果没有imageUrl，显示占位符
                                                                Column.height(200);
                                                                // 如果没有imageUrl，显示占位符
                                                                Column.justifyContent(FlexAlign.Center);
                                                                // 如果没有imageUrl，显示占位符
                                                                Column.backgroundColor(Colors.White10);
                                                                // 如果没有imageUrl，显示占位符
                                                                Column.borderRadius(12);
                                                                // 如果没有imageUrl，显示占位符
                                                                Column.onClick(() => {
                                                                    console.log('点击占位符图片，图片ID:', image.imageId, '图片名称:', image.imageName);
                                                                });
                                                            }, Column);
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create('📷');
                                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1089:27)", "entry");
                                                                Text.fontSize(48);
                                                                Text.opacity(0.5);
                                                            }, Text);
                                                            Text.pop();
                                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                                Text.create('图片加载中...');
                                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1092:27)", "entry");
                                                                Text.fontSize(12);
                                                                Text.fontColor(Colors.Black40);
                                                                Text.margin({ top: 8 });
                                                            }, Text);
                                                            Text.pop();
                                                            // 如果没有imageUrl，显示占位符
                                                            Column.pop();
                                                        });
                                                    }
                                                }, If);
                                                If.pop();
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    // 图片信息
                                                    Column.create({ space: 8 });
                                                    Column.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1108:23)", "entry");
                                                    // 图片信息
                                                    Column.width('100%');
                                                    // 图片信息
                                                    Column.padding({ top: 8, left: 8, right: 8, bottom: 8 });
                                                }, Column);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create(this.getDisplayImageName(image.imageName));
                                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1109:25)", "entry");
                                                    Text.fontSize(14);
                                                    Text.fontWeight(FontWeight.Medium);
                                                    Text.fontColor(Color.Black);
                                                    Text.maxLines(1);
                                                    Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                                                }, Text);
                                                Text.pop();
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Row.create();
                                                    Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1116:25)", "entry");
                                                }, Row);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create(this.currentUsername);
                                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1117:27)", "entry");
                                                    Text.fontSize(12);
                                                    Text.fontColor(Colors.Black60);
                                                }, Text);
                                                Text.pop();
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Blank.create();
                                                    Blank.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1121:27)", "entry");
                                                }, Blank);
                                                Blank.pop();
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Row.create({ space: 4 });
                                                    Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1123:27)", "entry");
                                                }, Row);
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create(image.isLike === 1 ? '❤️' : '🤍');
                                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1124:29)", "entry");
                                                    Text.fontSize(16);
                                                    Text.onClick(() => this.toggleLike(image));
                                                }, Text);
                                                Text.pop();
                                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                    Text.create((image.imageLike || 0).toString());
                                                    Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1128:29)", "entry");
                                                    Text.fontSize(12);
                                                    Text.fontColor(Colors.Black60);
                                                }, Text);
                                                Text.pop();
                                                Row.pop();
                                                Row.pop();
                                                // 图片信息
                                                Column.pop();
                                                Column.pop();
                                                GridItem.pop();
                                            };
                                            observedDeepRender();
                                        }
                                    };
                                    this.forEachUpdateFunction(elmtId, this.myImages, forEachItemGenFunction, undefined, true, false);
                                }, ForEach);
                                ForEach.pop();
                                Grid.pop();
                                // 图片网格 - 添加刷新功能（适用于所有标签页）
                                Refresh.pop();
                                this.observeComponentCreation2((elmtId, isInitialRender) => {
                                    If.create();
                                    // 加载更多指示器
                                    if (this.isLoading) {
                                        this.ifElseBranchUpdateFunction(0, () => {
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Row.create();
                                                Row.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1173:15)", "entry");
                                                Row.justifyContent(FlexAlign.Center);
                                                Row.width('100%');
                                                Row.height(40);
                                            }, Row);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                LoadingProgress.create();
                                                LoadingProgress.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1174:17)", "entry");
                                                LoadingProgress.width(20);
                                                LoadingProgress.height(20);
                                                LoadingProgress.color(Color.White);
                                            }, LoadingProgress);
                                            this.observeComponentCreation2((elmtId, isInitialRender) => {
                                                Text.create('加载中...');
                                                Text.debugLine("entry/src/main/ets/pages/ProfilePage.ets(1179:17)", "entry");
                                                Text.fontSize(12);
                                                Text.fontColor(Colors.Black60);
                                                Text.margin({ left: 8 });
                                            }, Text);
                                            Text.pop();
                                            Row.pop();
                                        });
                                    }
                                    else {
                                        this.ifElseBranchUpdateFunction(1, () => {
                                        });
                                    }
                                }, If);
                                If.pop();
                            });
                        }
                    }, If);
                    If.pop();
                    // 已登录状态 - 内容区域
                    Column.pop();
                });
            }
        }, If);
        If.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    // 底部导航栏
                    BottomNavBar(this, { currentPage: 'profile' }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/ProfilePage.ets", line: 1194, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            currentPage: 'profile'
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {
                        currentPage: 'profile'
                    });
                }
            }, { name: "BottomNavBar" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ProfilePage";
    }
}
registerNamedRoute(() => new ProfilePage(undefined, {}), "", { bundleName: "com.example.photosharing", moduleName: "entry", pagePath: "pages/ProfilePage", pageFullPath: "entry/src/main/ets/pages/ProfilePage", integratedHsp: "false", moduleType: "followWithHap" });
